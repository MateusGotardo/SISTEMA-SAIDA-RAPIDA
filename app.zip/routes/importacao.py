import os

import pandas as pd
from flask import Blueprint, request, jsonify

from models.banco import (
    ler_banco,
    ler_itens_processados,
    marcar_itens_processados,
    gerar_chave_item_importado,
    ajustar_estoque_produto,
)
from utils.helpers import to_float_seguro, encontrar_coluna

importacao_bp = Blueprint('importacao', __name__)


@importacao_bp.route('/api/processar_notas_multiplas', methods=['POST'])
def processar_notas_multiplas():
    arquivos = request.files.getlist('pdfs')  # (o input HTML pode mandar excel ou pdf)
    itens_consolidados = []
    erros = []

    for arquivo in arquivos:
        extensao = os.path.splitext(arquivo.filename)[1].lower()

        if extensao not in ['.xlsx', '.xls']:
            continue  # PDFs são tratados em outro trecho/rota; aqui só Excel

        try:
            df = pd.read_excel(arquivo)
        except ImportError as e:
            # Normalmente falta a lib 'openpyxl' (para .xlsx) ou 'xlrd' (para .xls antigo)
            erros.append(f"{arquivo.filename}: dependência ausente para ler Excel ({e}). "
                         f"Rode: pip install openpyxl xlrd")
            continue
        except Exception as e:
            erros.append(f"{arquivo.filename}: não foi possível abrir o arquivo ({e})")
            continue

        colunas_data = encontrar_coluna(df.columns, 'Data Saída') or encontrar_coluna(df.columns, 'Data')
        colunas_desc = encontrar_coluna(df.columns, 'Descrição') or encontrar_coluna(df.columns, 'Descricao')
        colunas_qtde = encontrar_coluna(df.columns, 'Qtde')
        colunas_unidade = encontrar_coluna(df.columns, 'Unidade')

        col_data = colunas_data[0] if colunas_data else None
        col_desc = colunas_desc[0] if colunas_desc else None

        if not col_desc:
            erros.append(f"{arquivo.filename}: não encontrei nenhuma coluna de 'Descrição'. "
                         f"Colunas disponíveis: {list(df.columns)}")
            continue

        # Varre cada linha da planilha do sistema
        for idx, linha in df.iterrows():
            try:
                data_bruta = str(linha.get(col_data, '')).split(' ')[0] if col_data else ''
                # Formata a data se estiver no padrão DD/MM/AAAA para AAAA-MM-DD
                if '/' in data_bruta:
                    p = data_bruta.split('/')
                    data_iso = f"{p[2]}-{p[1]}-{p[0]}" if len(p) == 3 else ''
                else:
                    data_iso = data_bruta

                nome_prod = str(linha.get(col_desc, '')).strip()
                if not nome_prod or nome_prod.lower() == 'nan':
                    continue  # linha sem produto, ignora silenciosamente (não é erro)

                # --- LÓGICA DOS DOIS CAMPOS DE QUANTIDADE (planilhas com colunas repetidas) ---
                quantidade_final = 0.0
                if len(colunas_qtde) > 0:
                    q1 = to_float_seguro(linha.get(colunas_qtde[0]))
                    if q1 > 0:
                        quantidade_final = q1
                if quantidade_final == 0 and len(colunas_qtde) > 1:
                    q2 = to_float_seguro(linha.get(colunas_qtde[1]))
                    if q2 > 0:
                        quantidade_final = q2
                if quantidade_final == 0:
                    quantidade_final = 1.0  # fallback de segurança

                unidade = str(linha.get(colunas_unidade[0], '')).strip() if colunas_unidade else ''

                chave_item = gerar_chave_item_importado(data_iso, nome_prod, quantidade_final, unidade)

                itens_consolidados.append({
                    "id": chave_item,
                    "data": data_iso,
                    "nome": nome_prod,
                    "quantidade": quantidade_final,
                    "unidade": unidade
                })
            except Exception as e:
                # Um erro nesta linha NÃO derruba as demais linhas do arquivo
                erros.append(f"{arquivo.filename}, linha {idx + 2}: {e}")
                continue

    # Remove os itens que já foram vinculados em uma sessão anterior — assim,
    # reimportar a mesma planilha grande mostra só o que ainda falta processar.
    ja_processados = ler_itens_processados()
    itens_consolidados = [i for i in itens_consolidados if i["id"] not in ja_processados]

    return jsonify({"sucesso": True, "itens": itens_consolidados, "erros": erros})


def _montar_registro_vinculo(dados, banco):
    """
    Valida um único 'vínculo' (produto oficial + quantidade real + itens da
    planilha) — SEM gravar nada em disco. Usado tanto pela rota de vínculo
    único quanto pela rota em lote.

    Retorna (produto_encontrado, quantidade_real, itens_selecionados, None)
    em caso de sucesso, ou (None, None, None, mensagem_de_erro) em caso de falha.
    """
    if not dados:
        return None, None, None, "Dados inválidos."

    produto_oficial_id = str(dados.get('produtoOficialId', '')).strip()
    quantidade_real = dados.get('quantidadeReal')
    itens_selecionados = dados.get('itens', [])

    if not produto_oficial_id:
        return None, None, None, "Produto oficial não informado."

    try:
        quantidade_real = float(quantidade_real)
    except (TypeError, ValueError):
        return None, None, None, "Quantidade real inválida."

    if quantidade_real <= 0:
        return None, None, None, "Quantidade real deve ser maior que zero."

    produto_encontrado = None
    for p in banco.get('produtos', []):
        if str(p.get('codigo_barras')) == produto_oficial_id or p.get('nome') == produto_oficial_id:
            produto_encontrado = p
            break

    if not produto_encontrado:
        return None, None, None, "Produto oficial não encontrado no banco de produtos."

    return produto_encontrado, quantidade_real, itens_selecionados, None


@importacao_bp.route('/api/injetar_historico_media', methods=['POST'])
def injetar_historico_media():
    """
    Soma a quantidade real informada direto no estoque_atual do produto
    vinculado (rota mantida com o nome antigo por compatibilidade com o
    front-end, mas agora alimenta o estoque em vez do histórico de consumo).
    """
    dados = request.json

    banco = ler_banco()

    produto, quantidade_real, itens_selecionados, erro = _montar_registro_vinculo(dados, banco)
    if erro:
        return jsonify({"sucesso": False, "mensagem": erro})

    ajustar_estoque_produto(produto.get('codigo_barras'), quantidade_real)

    # Marca definitivamente estes itens como já vinculados, para que não
    # voltem a aparecer numa próxima importação da mesma planilha.
    marcar_itens_processados([i.get('itemId') for i in itens_selecionados])

    print(f"📦 [ESTOQUE] Produto Oficial: {produto.get('nome')}")
    print(f"📥 [ESTOQUE] Quantidade adicionada ao estoque: {quantidade_real}")
    print(f"🔗 [ESTOQUE] Itens divergentes vinculados: {len(itens_selecionados)}")

    return jsonify({
        "sucesso": True,
        "mensagem": "Estoque atualizado com sucesso!"
    })


@importacao_bp.route('/api/injetar_historico_media_lote', methods=['POST'])
def injetar_historico_media_lote():
    """
    Versão em lote de /api/injetar_historico_media: recebe uma LISTA de
    vínculos (um por semana) numa única requisição — útil quando o mesmo
    produto se repete em várias semanas de uma planilha grande. Cada vínculo
    soma sua quantidade ao estoque_atual do produto vinculado.
    """
    corpo = request.json
    if not corpo or not isinstance(corpo.get('vinculos'), list) or len(corpo.get('vinculos')) == 0:
        return jsonify({"sucesso": False, "mensagem": "Nenhum vínculo recebido."})

    vinculos_entrada = corpo['vinculos']

    banco = ler_banco()

    total_processado = 0
    todos_itens_selecionados = []
    erros = []

    for i, vinculo in enumerate(vinculos_entrada):
        produto, quantidade_real, itens_selecionados, erro = _montar_registro_vinculo(vinculo, banco)
        if erro:
            erros.append(f"Vínculo {i + 1}: {erro}")
            continue
        ajustar_estoque_produto(produto.get('codigo_barras'), quantidade_real)
        total_processado += 1
        todos_itens_selecionados.extend(itens_selecionados)

    if total_processado == 0:
        return jsonify({"sucesso": False, "mensagem": "Nenhum vínculo válido para processar.", "erros": erros})

    # Marca todos os itens de todos os vínculos processados com sucesso, de uma vez.
    marcar_itens_processados([i.get('itemId') for i in todos_itens_selecionados])

    print(f"📦 [ESTOQUE EM LOTE] {total_processado} vínculo(s) somado(s) ao estoque de uma vez")
    if erros:
        print(f"⚠️ [ESTOQUE EM LOTE] {len(erros)} vínculo(s) com erro: {erros}")

    return jsonify({
        "sucesso": True,
        "total_processado": total_processado,
        "mensagem": f"{total_processado} vínculo(s) somado(s) ao estoque com sucesso!",
        "erros": erros
    })
