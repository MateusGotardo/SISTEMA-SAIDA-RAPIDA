from flask import Blueprint, request, jsonify

from models.banco import ler_banco, salvar_banco

profissionais_bp = Blueprint('profissionais', __name__)


@profissionais_bp.route('/api/buscar_profissional', methods=['GET'])
def buscar_profissional():
    funcao = request.args.get('funcao', '').strip().lower()
    termo = request.args.get('termo', '').strip().lower()
    banco = ler_banco()

    profissionais = banco.get('profissionais', [])
    if funcao:
        profissionais = [p for p in profissionais if p.get('funcao', '').lower() == funcao]
    if termo:
        profissionais = [p for p in profissionais if termo in p['nome'].lower()]

    return jsonify({"sucesso": True, "profissionais": profissionais})


@profissionais_bp.route('/api/cadastrar_profissional', methods=['POST'])
def cadastrar_profissional():
    dados = request.get_json()
    nome = dados.get('nome', '').strip()
    funcao = dados.get('funcao', '').strip().lower()

    if not nome or not funcao:
        return jsonify({"sucesso": False, "mensagem": "Nome e Função são obrigatórios!"}), 400

    banco = ler_banco()
    novo_id = len(banco.get('profissionais', [])) + 1
    novo_prof = {"id": novo_id, "nome": nome, "funcao": funcao}

    banco.setdefault('profissionais', []).append(novo_prof)
    salvar_banco(banco)
    return jsonify({"sucesso": True, "mensagem": "Profissional cadastrado!", "profissional": novo_prof})


# ==========================================
# GERENCIAMENTO DE PROFISSIONAIS (Manicure / Cabeleireiro)
# Nota: Assumindo que no seu banco.json os profissionais podem ser salvos
# em uma estrutura como: "profissionais": [{"nome": "...", "setor": "manicure"}, ...]
# ==========================================

@profissionais_bp.route('/api/listar_profissionais', methods=['GET'])
def listar_profissionais():
    setor = request.args.get('setor', '').strip().lower()  # 'manicure' ou 'cabeleireiro'
    dados = ler_banco()
    todos_profissionais = dados.get("profissionais", [])

    # Filtra pela função correspondente (campo real usado em todo o banco.json)
    if setor:
        filtrados = [p for p in todos_profissionais if p.get('funcao', '').lower() == setor]
    else:
        filtrados = todos_profissionais
    return jsonify({"sucesso": True, "profissionais": filtrados})


@profissionais_bp.route('/api/salvar_profissional', methods=['POST'])
def salvar_profissional():
    req = request.json
    setor = req.get('setor', '').strip().lower()
    nome_antigo = req.get('nome_antigo', '').strip()
    novo_nome = req.get('novo_nome', '').strip()

    if not novo_nome or not setor:
        return jsonify({"sucesso": False, "mensagem": "Nome e setor são obrigatórios."})

    dados = ler_banco()

    if nome_antigo:
        # Modo Edição
        encontrou = False
        for p in dados["profissionais"]:
            if p.get("funcao", "").lower() == setor and p.get("nome", "").lower() == nome_antigo.lower():
                p["nome"] = novo_nome
                encontrou = True
                break
        if not encontrou:
            return jsonify({"sucesso": False, "mensagem": "Profissional não encontrado para edição."})
    else:
        # Modo Criação de Novo
        novo_id = (max([p.get('id', 0) for p in dados["profissionais"]]) + 1) if dados["profissionais"] else 1
        dados["profissionais"].append({
            "id": novo_id,
            "nome": novo_nome,
            "funcao": setor
        })

    salvar_banco(dados)
    return jsonify({"sucesso": True, "mensagem": "Profissional salvo com sucesso!"})


@profissionais_bp.route('/api/excluir_profissional', methods=['POST'])
def excluir_profissional():
    req = request.json
    nome_alvo = req.get('nome', '').strip().lower()

    dados = ler_banco()
    tamanho_inicial = len(dados.get("profissionais", []))

    # Filtra removendo o profissional cujo nome coincida (ignorando maiúsculas/minúsculas)
    dados["profissionais"] = [
        p for p in dados["profissionais"]
        if p.get("nome", "").strip().lower() != nome_alvo
    ]

    if len(dados["profissionais"]) == tamanho_inicial:
        return jsonify({"sucesso": False, "mensagem": "Profissional não encontrado."})

    salvar_banco(dados)
    return jsonify({"sucesso": True, "mensagem": "Profissional excluído com sucesso!"})
