from datetime import datetime

from flask import Blueprint, request, jsonify

from models.banco import (
    ler_banco,
    salvar_banco,
    ler_historico_consumo,
    salvar_historico_consumo,
    ajustar_estoque_produto,
)

saidas_bp = Blueprint('saidas', __name__)


@saidas_bp.route('/api/confirmar_saida', methods=['POST'])
def confirmar_saida():
    dados = request.get_json()
    itens = dados.get('itens', [])
    profissional = dados.get('profissional', '').strip()
    setor = dados.get('setor', 'manicure')
    cliente = dados.get('cliente', '').strip()

    if not itens or not profissional:
        return jsonify({"sucesso": False, "mensagem": "Preencha o profissional e adicione itens."}), 400

    # No setor cabeleireiro o nome da cliente é obrigatório: é ele que permite
    # vincular automaticamente os lançamentos futuros dessa cliente à
    # profissional que a atendeu pela primeira vez (ver /api/buscar_cliente).
    if setor == 'cabeleireiro' and not cliente:
        return jsonify({"sucesso": False, "mensagem": "Informe o nome da cliente para lançamentos de Cabeleireiro."}), 400

    banco = ler_banco()
    data_hora = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    data_hoje = datetime.now().strftime("%Y-%m-%d")  # Formato ideal para calcular as semanas no JS

    # Usa max(id)+1 em vez de contar o tamanho das listas: como itens saem de
    # saidas_pendentes (exclusão, confirmação) o tamanho da lista diminui, e um
    # id baseado em len() podia colidir com um id já existente.
    todos_ids = [s.get('id', 0) for s in banco.get('saidas_pendentes', [])] + \
                [s.get('id', 0) for s in banco.get('saidas_confirmadas', [])]
    proximo_id = (max(todos_ids) + 1) if todos_ids else 1

    nova_saida = {
        "id": proximo_id,
        "data_hora": data_hora,
        "profissional": profissional,
        "setor": setor,
        "cliente": cliente if cliente else "SEM CLIENTE REGISTRADA",
        "itens": itens
    }

    # Salva normalmente no fluxo do dia (banco.json)
    banco.setdefault('saidas_pendentes', []).append(nova_saida)
    salvar_banco(banco)

    # Baixa automática do estoque: assim que a saída é lançada (ainda pendente),
    # já abate a quantidade de cada item do estoque_atual do produto — não
    # espera aprovação/confirmação pro PDF do dia. Se este lançamento for
    # excluído antes de ser aprovado, o estoque volta (ver excluir_bloco_profissional).
    for item in itens:
        cod = item.get('codigo_barras')
        qtd = item.get('quantidade')
        try:
            qtd = float(qtd)
        except (TypeError, ValueError):
            qtd = 0
        if cod and qtd:
            ajustar_estoque_produto(cod, -qtd)

    # --- SALVA TAMBÉM NO ARQUIVO ACUMULADO PARA A MÉDIA DE COMPRAS ---
    registro_consumo = {
        "data": data_hoje,
        "data_hora": data_hora,
        "profissional": profissional,
        "setor": setor,
        "cliente": cliente if cliente else "SEM CLIENTE",
        "itens": itens
    }

    try:
        consumo_lista = ler_historico_consumo()
    except Exception:
        consumo_lista = []

    consumo_lista.append(registro_consumo)
    salvar_historico_consumo(consumo_lista)
    # -----------------------------------------------------------------

    return jsonify({"sucesso": True, "mensagem": "Lançamento adicionado à fila do dia!"})


@saidas_bp.route('/api/buscar_cliente', methods=['GET'])
def buscar_cliente():
    """
    Autocomplete de clientes já atendidas: busca no histórico de consumo geral
    (que nunca é resetado, ao contrário de saidas_confirmadas) todas as clientes
    já lançadas para o setor informado e retorna, junto com o nome, a
    profissional que a atendeu na primeira vez (histórico já vem ordenado por
    id crescente = ordem cronológica de lançamento).
    """
    setor = request.args.get('setor', '').strip().lower()
    termo = request.args.get('termo', '').strip().lower()

    NOMES_IGNORADOS = {'', 'sem cliente', 'sem cliente registrada'}

    primeira_profissional_por_cliente = {}
    for registro in ler_historico_consumo():
        if setor and registro.get('setor', '').strip().lower() != setor:
            continue
        cliente = (registro.get('cliente') or '').strip()
        if cliente.lower() in NOMES_IGNORADOS:
            continue
        if cliente not in primeira_profissional_por_cliente:
            primeira_profissional_por_cliente[cliente] = registro.get('profissional', '').strip()

    resultado = [
        {"cliente": cliente, "profissional_original": profissional}
        for cliente, profissional in primeira_profissional_por_cliente.items()
        if not termo or termo in cliente.lower()
    ]
    resultado.sort(key=lambda c: c['cliente'].lower())

    return jsonify({"sucesso": True, "clientes": resultado[:8]})


@saidas_bp.route('/api/historico_agrupado_pendente', methods=['GET'])
def historico_agrupado_pendente():
    banco = ler_banco()
    saidas = banco.get('saidas_pendentes', [])

    # Cria um dicionário de consulta rápida para o código de barras pelo nome do produto
    mapa_produtos = {}
    for p in banco.get('produtos', []):
        nome_p = p.get('nome', '').strip().upper()
        cod_p = p.get('codigo_barras', '').strip()
        if nome_p:
            mapa_produtos[nome_p] = cod_p or 'S/COD'

    agrupado = {}
    for s in saidas:
        prof = s.get('profissional', 'Não Identificado').strip()
        setor = s.get('setor', 'manicure')
        cliente = s.get('cliente', '').strip() or "SEM CLIENTE REGISTRADA"

        chave = f"{prof.upper()}___{setor}___{cliente.upper()}"

        if chave not in agrupado:
            agrupado[chave] = {
                "chave": chave,
                "profissional": prof,
                "setor": setor,
                "cliente": cliente,
                "total_lancamentos": 0,
                "ids_lancamentos": [],
                "itens": {}
            }

        agrupado[chave]["total_lancamentos"] += 1
        agrupado[chave]["ids_lancamentos"].append(s["id"])

        for item in s["itens"]:
            nome_item = item.get("nome", "").strip()

            # Pega o código do item ou busca no cadastro geral de produtos pelo nome
            cod = item.get("codigo_barras", "").strip()
            if not cod or cod == "S/COD":
                cod = mapa_produtos.get(nome_item.upper(), "S/COD")

            # Salva de volta no item para garantir
            item["codigo_barras"] = cod

            qtd = item["quantidade"]
            medida = item.get("tipo_medida", "un")

            chave_item = f"{cod}_{nome_item}"

            if chave_item not in agrupado[chave]["itens"]:
                agrupado[chave]["itens"][chave_item] = {
                    "codigo_barras": cod,
                    "nome_produto": nome_item,
                    "quantidade": 0,
                    "tipo_medida": medida,
                    "ids_lancamentos": []
                }
            agrupado[chave]["itens"][chave_item]["quantidade"] += qtd
            # Guarda quais lançamentos (saídas pendentes) originaram esse produto,
            # para permitir a confirmação seletiva por checkbox no front-end
            if s["id"] not in agrupado[chave]["itens"][chave_item]["ids_lancamentos"]:
                agrupado[chave]["itens"][chave_item]["ids_lancamentos"].append(s["id"])

    resultado = []
    for k, v in agrupado.items():
        resultado.append({
            "chave": v["chave"],
            "profissional": v["profissional"],
            "setor": v["setor"],
            "cliente": v["cliente"],
            "total_lancamentos": v["total_lancamentos"],
            "ids_lancamentos": v["ids_lancamentos"],
            "itens": list(v["itens"].values())
        })

    return jsonify({"sucesso": True, "agrupado": resultado, "saidas_brutas": saidas})


@saidas_bp.route('/api/confirmar_itens_selecionados', methods=['POST'])
def confirmar_itens_selecionados():
    """
    Confirma apenas os produtos marcados pelo usuário, mesmo que estejam
    misturados com outros produtos não selecionados dentro do mesmo lançamento.
    Fraciona o lançamento quando necessário: os itens selecionados vão para
    saidas_confirmadas, e os itens restantes continuam em saidas_pendentes.
    """
    dados = request.get_json()
    selecoes = dados.get('selecoes', [])

    if not selecoes:
        return jsonify({"sucesso": False, "mensagem": "Nenhum produto selecionado."}), 400

    # Agrupa as seleções por lançamento de origem para facilitar a checagem
    selecoes_por_lancamento = {}
    for sel in selecoes:
        idl = sel.get('id_lancamento')
        selecoes_por_lancamento.setdefault(idl, []).append(sel)

    banco = ler_banco()
    pendentes = banco.get('saidas_pendentes', [])

    novos_pendentes = []
    novos_confirmados = []

    for s in pendentes:
        sels_deste_lancamento = selecoes_por_lancamento.get(s['id'])

        if not sels_deste_lancamento:
            # Nenhum produto deste lançamento foi selecionado: continua pendente sem alterações
            novos_pendentes.append(s)
            continue

        itens_confirmar = []
        itens_restantes = []

        for item in s.get('itens', []):
            cod_item = (item.get('codigo_barras') or item.get('codigo') or '').strip()
            nome_item = (item.get('nome') or item.get('nome_produto') or '').strip().upper()

            selecionado = any(
                (sel.get('codigo_barras', '').strip() == cod_item) and
                (sel.get('nome_produto', '').strip().upper() == nome_item)
                for sel in sels_deste_lancamento
            )

            if selecionado:
                itens_confirmar.append(item)
            else:
                itens_restantes.append(item)

        if itens_confirmar:
            registro_confirmado = dict(s)
            registro_confirmado['itens'] = itens_confirmar
            novos_confirmados.append(registro_confirmado)

        if itens_restantes:
            registro_restante = dict(s)
            registro_restante['itens'] = itens_restantes
            novos_pendentes.append(registro_restante)
        # Se não sobrou nenhum item, o lançamento inteiro foi confirmado e não volta para pendentes

    banco['saidas_pendentes'] = novos_pendentes
    banco.setdefault('saidas_confirmadas', []).extend(novos_confirmados)
    salvar_banco(banco)

    return jsonify({"sucesso": True, "mensagem": "Produtos selecionados confirmados e gravados para o PDF do final do dia!"})


@saidas_bp.route('/api/aprovar_bloco_profissional', methods=['POST'])
def aprovar_bloco_profissional():
    dados = request.get_json()
    ids_lancamentos = dados.get('ids', [])

    banco = ler_banco()
    pendentes = banco.get('saidas_pendentes', [])

    a_transferir = [s for s in pendentes if s['id'] in ids_lancamentos]
    banco['saidas_pendentes'] = [s for s in pendentes if s['id'] not in ids_lancamentos]

    banco.setdefault('saidas_confirmadas', []).extend(a_transferir)
    salvar_banco(banco)
    return jsonify({"sucesso": True, "mensagem": "Bloco aprovado e gravado para o PDF do final do dia!"})


@saidas_bp.route('/api/excluir_bloco_profissional', methods=['POST'])
def excluir_bloco_profissional():
    dados = request.get_json()
    ids_lancamentos = dados.get('ids', [])

    banco = ler_banco()
    pendentes = banco.get('saidas_pendentes', [])

    a_excluir = [s for s in pendentes if s['id'] in ids_lancamentos]
    banco['saidas_pendentes'] = [s for s in pendentes if s['id'] not in ids_lancamentos]
    salvar_banco(banco)

    # Como a saída ainda não vai acontecer de verdade, devolve ao estoque
    # tudo o que tinha sido abatido no momento do lançamento (confirmar_saida).
    for s in a_excluir:
        for item in s.get('itens', []):
            cod = item.get('codigo_barras')
            qtd = item.get('quantidade')
            try:
                qtd = float(qtd)
            except (TypeError, ValueError):
                qtd = 0
            if cod and qtd:
                ajustar_estoque_produto(cod, qtd)

    return jsonify({"sucesso": True, "mensagem": "Bloco excluído e estoque devolvido!"})


@saidas_bp.route('/api/historico_confirmado_pdf', methods=['GET'])
def historico_confirmado_pdf():
    banco = ler_banco()

    # Cria mapa de produtos para injetar o código caso esteja faltando
    mapa_produtos = {}
    for p in banco.get('produtos', []):
        nome_p = p.get('nome', '').strip().upper()
        cod_p = p.get('codigo_barras', '').strip()
        if nome_p:
            mapa_produtos[nome_p] = cod_p or 'S/COD'

    confirmados = banco.get('saidas_confirmadas', [])

    # Normaliza os dados para garantir que todo item tenha 'codigo_barras' e 'nome'
    for c in confirmados:
        for item in c.get('itens', []):
            # Garante o nome padronizado
            if 'nome' not in item and 'nome_produto' in item:
                item['nome'] = item['nome_produto']
            elif 'nome_produto' not in item and 'nome' in item:
                item['nome_produto'] = item['nome']

            nome_item = item.get('nome', '').strip()

            # Garante o código de barras
            cod = item.get('codigo_barras', '').strip()
            if not cod or cod == 'S/COD':
                cod = mapa_produtos.get(nome_item.upper(), 'S/COD')
            item['codigo_barras'] = cod

    return jsonify({"sucesso": True, "confirmados": confirmados})


@saidas_bp.route('/api/resetar_historico', methods=['POST'])
def resetar_historico():
    banco = ler_banco()
    banco['saidas_confirmadas'] = []
    salvar_banco(banco)
    return jsonify({"sucesso": True, "mensagem": "Pronto para o novo dia!"})
