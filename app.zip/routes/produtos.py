from flask import Blueprint, request, jsonify

from models.banco import ler_banco, salvar_banco, definir_estoque_produto

produtos_bp = Blueprint('produtos', __name__)


@produtos_bp.route('/api/buscar_produto', methods=['GET'])
def buscar_produto():
    termo = request.args.get('termo', '').strip().lower()
    if not termo:
        return jsonify({"sucesso": False, "produtos": []})

    banco = ler_banco()
    encontrados = [
        p for p in banco.get('produtos', [])
        if termo in p['nome'].lower() or termo in p['codigo_barras'].lower()
    ]
    return jsonify({"sucesso": True, "produtos": encontrados})


@produtos_bp.route('/api/cadastrar_produto', methods=['POST'])
def cadastrar_produto():
    dados = request.get_json()
    nome = dados.get('nome', '').strip()
    codigo_barras = dados.get('codigo_barras', '').strip()
    tipo_medida = dados.get('tipo_medida', 'un').strip().lower()

    tamanho_embalagem = dados.get('tamanho_embalagem', 1)
    try:
        tamanho_embalagem = float(tamanho_embalagem) if tamanho_embalagem else 1
    except (ValueError, TypeError):
        tamanho_embalagem = 1

    estoque_atual = dados.get('estoque_atual', 0)
    try:
        estoque_atual = float(estoque_atual) if estoque_atual else 0
    except (ValueError, TypeError):
        estoque_atual = 0

    if not nome:
        return jsonify({"sucesso": False, "mensagem": "Nome obrigatório!"}), 400

    if not codigo_barras:
        import time
        codigo_barras = "789" + str(int(time.time()))[-7:]

    banco = ler_banco()

    for p in banco.get('produtos', []):
        if p.get('codigo_barras') == codigo_barras:
            return jsonify({"sucesso": False, "mensagem": "Já existe um produto com este código de barras!"}), 400

    novo_prod = {
        "codigo_barras": codigo_barras,
        "nome": nome,
        "tipo_medida": tipo_medida,
        "tamanho_embalagem": tamanho_embalagem,
        "estoque_atual": estoque_atual
    }

    banco.setdefault('produtos', []).append(novo_prod)
    salvar_banco(banco)
    return jsonify({"sucesso": True, "mensagem": "Produto cadastrado com sucesso!", "produto": novo_prod})


# 1. Listar ou Buscar Produtos
@produtos_bp.route('/api/buscar_produto_editar', methods=['GET'])
def buscar_produto_editar():
    termo = request.args.get('termo', '').strip().lower()
    dados = ler_banco()
    produtos = dados.get("produtos", [])

    if termo:
        filtrados = [p for p in produtos if termo in p.get('nome', '').lower() or termo in p.get('codigo_barras', '')]
    else:
        filtrados = produtos

    return jsonify({"sucesso": True, "produtos": filtrados})


# 2. Salvar ou Criar Novo Produto
@produtos_bp.route('/api/salvar_produto', methods=['POST'])
def salvar_produto():
    req = request.json
    nome = req.get('nome', '').strip()
    codigo_barras = req.get('codigo_barras', '').strip()

    if not nome or not codigo_barras:
        return jsonify({"sucesso": False, "mensagem": "Nome e código são obrigatórios."})

    dados = ler_banco()

    # Verifica se já existe um produto com o mesmo código de barras
    for p in dados["produtos"]:
        if p.get("codigo_barras") == codigo_barras:
            return jsonify({"sucesso": False, "mensagem": "Já existe um produto com este código de barras!"})

    dados["produtos"].append({
        "nome": nome,
        "codigo_barras": codigo_barras,
        "tipo_medida": "un"
    })

    salvar_banco(dados)
    return jsonify({"sucesso": True, "mensagem": "Produto cadastrado com sucesso!"})


# 3. Atualizar Produto Existente
@produtos_bp.route('/api/atualizar_produto', methods=['POST'])
def atualizar_produto():
    req = request.json
    codigo_original = req.get('codigo_original')
    novo_nome = req.get('nome', '').strip()
    novo_codigo = req.get('codigo_barras', '').strip()

    dados = ler_banco()
    encontrou = False

    for p in dados["produtos"]:
        if p.get("codigo_barras") == codigo_original:
            p["nome"] = novo_nome
            p["codigo_barras"] = novo_codigo
            encontrou = True
            break

    if not encontrou:
        return jsonify({"sucesso": False, "mensagem": "Produto não encontrado para atualização."})

    salvar_banco(dados)
    return jsonify({"sucesso": True, "mensagem": "Produto atualizado com sucesso!"})


# 4. Excluir Produto
@produtos_bp.route('/api/excluir_produto', methods=['POST'])
def excluir_produto():
    req = request.json
    codigo_barras = req.get('codigo_barras')

    dados = ler_banco()
    tamanho_inicial = len(dados["produtos"])
    dados["produtos"] = [p for p in dados["produtos"] if p.get("codigo_barras") != codigo_barras]

    if len(dados["produtos"]) == tamanho_inicial:
        return jsonify({"sucesso": False, "mensagem": "Produto não encontrado."})

    salvar_banco(dados)
    return jsonify({"sucesso": True, "mensagem": "Produto excluído com sucesso!"})


@produtos_bp.route('/api/informar_estoque_atual', methods=['POST'])
def informar_estoque_atual():
    """
    Define (sobrescreve) o estoque_atual de um produto, informado manualmente
    pelo botão 📦 na tela de saída. Não interfere na quantidade que estiver
    sendo lançada de saída naquele momento.
    """
    dados = request.get_json()
    codigo_barras = str(dados.get('codigo_barras', '')).strip()
    estoque_atual = dados.get('estoque_atual')

    if not codigo_barras:
        return jsonify({"sucesso": False, "mensagem": "Produto não informado."}), 400

    try:
        estoque_atual = float(estoque_atual)
    except (TypeError, ValueError):
        return jsonify({"sucesso": False, "mensagem": "Informe um valor de estoque válido."}), 400

    if estoque_atual < 0:
        return jsonify({"sucesso": False, "mensagem": "O estoque não pode ser negativo."}), 400

    banco = ler_banco()
    existe = any(p.get('codigo_barras') == codigo_barras for p in banco.get('produtos', []))
    if not existe:
        return jsonify({"sucesso": False, "mensagem": "Produto não encontrado no banco."}), 404

    definir_estoque_produto(codigo_barras, estoque_atual)
    return jsonify({"sucesso": True, "mensagem": "Estoque atual atualizado com sucesso!", "estoque_atual": estoque_atual})


@produtos_bp.route('/api/atualizar_item', methods=['POST'])
def atualizar_item():
    """
    Atualiza um produto OU um profissional existente, dependendo do campo
    'tipo' recebido — mantido como uma única rota compartilhada, exatamente
    como no projeto original, para não alterar o contrato usado pelo
    front-end (dashboard.js).
    """
    dados_requisicao = request.get_json()
    tipo = dados_requisicao.get('tipo')
    id_original = dados_requisicao.get('id_original')
    novo_nome = dados_requisicao.get('nome')

    dados_banco = ler_banco()

    if tipo == 'produto':
        novo_codigo = dados_requisicao.get('codigo_barras')
        nova_medida = dados_requisicao.get('tipo_medida')

        nova_embalagem = dados_requisicao.get('tamanho_embalagem', 1)
        try:
            nova_embalagem = float(nova_embalagem) if nova_embalagem else 1
        except (ValueError, TypeError):
            nova_embalagem = 1

        encontrou = False
        for prod in dados_banco.get("produtos", []):
            # Compara pelo código de barras original
            if str(prod.get('codigo_barras')) == str(id_original):
                # Se o código de barras está sendo alterado, garante que o novo
                # valor não colida com o de outro produto já existente.
                if str(novo_codigo) != str(id_original):
                    for outro in dados_banco.get("produtos", []):
                        if outro is not prod and outro.get('codigo_barras') == novo_codigo:
                            return jsonify({"sucesso": False, "mensagem": "Já existe outro produto com este código de barras!"}), 400
                prod['nome'] = novo_nome
                prod['codigo_barras'] = novo_codigo
                prod['tipo_medida'] = nova_medida
                prod['tamanho_embalagem'] = nova_embalagem
                encontrou = True
                break

        if not encontrou:
            return jsonify({"sucesso": False, "mensagem": "Produto não encontrado no banco."})

    elif tipo == 'profissional':
        novo_setor = dados_requisicao.get('setor')

        encontrou = False
        for prof in dados_banco.get("profissionais", []):
            # Compara pelo ID ou pelo Nome original
            if str(prof.get('id')) == str(id_original) or prof.get('nome') == str(id_original):
                prof['nome'] = novo_nome
                prof['funcao'] = novo_setor
                encontrou = True
                break

        if not encontrou:
            return jsonify({"sucesso": False, "mensagem": "Profissional não encontrado no banco."})

    # Salva de volta no banco.json (utilize sua função de salvar existente)
    salvar_banco(dados_banco)
    return jsonify({"sucesso": True})
