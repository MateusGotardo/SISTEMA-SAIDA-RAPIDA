import threading
import tkinter as tk
import webview
from app import app  # Importa a sua aplicacao do app.py

# Defina o tamanho ideal (Proporcao da Foto 2)
LARGURA = 1020
ALTURA = 1080


def calcular_posicao_central(largura, altura):
    """Calcula as coordenadas X e Y para centralizar a janela em qualquer monitor."""
    root = tk.Tk()
    root.withdraw()  # Esconde a janela fantasma do tkinter

    largura_tela = root.winfo_screenwidth()
    altura_tela = root.winfo_screenheight()

    pos_x = (largura_tela - largura) // 2
    pos_y = (altura_tela - altura) // 2

    root.destroy()
    return pos_x, pos_y


def rodar_flask():
    app.run(port=5000, debug=False, use_reloader=False)


class Api:
    """
    Ponte entre o JavaScript do dashboard e o Python.

    O motivo de existir: dentro da janela do pywebview (e, principalmente,
    depois de compilado com o PyInstaller) o truque de "criar um <a
    download> e clicar nele" para baixar o PDF gerado pelo Flask nao
    funciona de forma confiavel - o webview embutido nao tem um gerenciador
    de downloads como um navegador de verdade. Por isso, aqui o PDF e
    gerado internamente e salvo com uma janela NATIVA "Salvar como".
    """

    def salvar_pdf(self, nome_sugerido, data_param):
        try:
            with app.test_client() as client:
                resposta = client.get(f'/api/gerar_pdf_servidor?data={data_param}')

            if resposta.status_code != 200:
                return {'ok': False, 'erro': f'Falha ao gerar o PDF (status {resposta.status_code}).'}

            pdf_bytes = resposta.data

            janela = webview.windows[0]
            resultado = janela.create_file_dialog(
                webview.SAVE_DIALOG,
                save_filename=nome_sugerido,
                file_types=('Arquivo PDF (*.pdf)',)
            )

            if not resultado:
                return {'ok': False, 'cancelado': True}

            destino = resultado if isinstance(resultado, str) else resultado[0]
            if not destino.lower().endswith('.pdf'):
                destino += '.pdf'

            with open(destino, 'wb') as f:
                f.write(pdf_bytes)

            return {'ok': True, 'caminho': destino}
        except Exception as e:
            return {'ok': False, 'erro': str(e)}

    def salvar_excel_media(self, nome_sugerido, payload):
        """
        Mesma ideia do salvar_pdf: gera o .xlsx internamente (via test_client,
        sem precisar abrir uma porta HTTP de verdade) e salva com o diálogo
        nativo "Salvar como", já que o webview embutido não baixa arquivos
        sozinho.
        """
        try:
            with app.test_client() as client:
                resposta = client.post('/api/exportar_media_excel', json=payload)

            if resposta.status_code != 200:
                return {'ok': False, 'erro': f'Falha ao gerar o Excel (status {resposta.status_code}).'}

            excel_bytes = resposta.data

            janela = webview.windows[0]
            resultado = janela.create_file_dialog(
                webview.SAVE_DIALOG,
                save_filename=nome_sugerido,
                file_types=('Planilha Excel (*.xlsx)',)
            )

            if not resultado:
                return {'ok': False, 'cancelado': True}

            destino = resultado if isinstance(resultado, str) else resultado[0]
            if not destino.lower().endswith('.xlsx'):
                destino += '.xlsx'

            with open(destino, 'wb') as f:
                f.write(excel_bytes)

            return {'ok': True, 'caminho': destino}
        except Exception as e:
            return {'ok': False, 'erro': str(e)}


if __name__ == '__main__':
    # 1. Roda o Flask em segundo plano
    t = threading.Thread(target=rodar_flask)
    t.daemon = True
    t.start()

    # 2. Calcula o centro exato da tela
    pos_x, pos_y = calcular_posicao_central(LARGURA, ALTURA)

    # 3. Cria a janela informando o tamanho, a posicao x/y calculada e a
    #    ponte (js_api) usada pelo botao de exportar PDF
    api = Api()
    webview.create_window(
        'Sistema de Saida Rapida',
        'http://127.0.0.1:5000',
        width=LARGURA,
        height=ALTURA,
        x=pos_x,
        y=pos_y,
        resizable=True,
        js_api=api
    )

    # 4. Inicia o webview
    webview.start()
