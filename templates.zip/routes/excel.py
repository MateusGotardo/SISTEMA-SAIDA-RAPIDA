import io
from datetime import datetime

from flask import Blueprint, request, send_file
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

excel_bp = Blueprint('excel', __name__)

# Paleta usada para casar com o visual do PDF/dashboard (mesmos tons de azul/cinza)
COR_TITULO = "1A365D"
COR_CABECALHO_FUNDO = "1A365D"
COR_CABECALHO_TEXTO = "FFFFFF"
COR_FAIXA = "EDF2F7"
COR_BORDA = "CBD5E0"
COR_SUBTITULO = "4A5568"
COR_DESTAQUE = "2B6CB0"


@excel_bp.route('/api/exportar_media_excel', methods=['POST'])
def exportar_media_excel():
    """
    Recebe a lista já calculada de 'Controle e Média de Saída Semanal' (a mesma
    exibida no modal do dashboard, sem os detalhes de cada lançamento individual)
    e devolve um .xlsx formatado, pronto para planejamento de compras.
    """
    dados = request.get_json(silent=True) or {}
    itens = dados.get('itens', []) or []

    # Ordena alfabeticamente pelo nome do produto para ficar organizado na planilha
    itens_ordenados = sorted(itens, key=lambda p: str(p.get('nome', '')).upper())

    wb = Workbook()
    ws = wb.active
    ws.title = "Média Semanal"

    total_colunas = 6  # Código, Produto, Medida, Total Saído, Média Semanal, Sugestão de Compra

    # ---------- Cabeçalho do relatório (título + subtítulo) ----------
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=total_colunas)
    titulo = ws.cell(row=1, column=1, value="CONTROLE E MÉDIA DE SAÍDA SEMANAL")
    titulo.font = Font(name='Calibri', size=16, bold=True, color=COR_TITULO)
    titulo.alignment = Alignment(horizontal='center', vertical='center')
    ws.row_dimensions[1].height = 26

    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=total_colunas)
    subtitulo = ws.cell(
        row=2, column=1,
        value=f"Análise de consumo para planejamento de compras  •  Gerado em {datetime.now().strftime('%d/%m/%Y %H:%M')}"
    )
    subtitulo.font = Font(name='Calibri', size=10, italic=True, color=COR_SUBTITULO)
    subtitulo.alignment = Alignment(horizontal='center')
    ws.row_dimensions[2].height = 18

    linha_cabecalho = 4
    cabecalhos = ["Código", "Produto", "Medida", "Total Saído", "Média Semanal (Estimada)", "Sugestão de Compra"]

    borda_fina = Border(
        left=Side(style='thin', color=COR_BORDA),
        right=Side(style='thin', color=COR_BORDA),
        top=Side(style='thin', color=COR_BORDA),
        bottom=Side(style='thin', color=COR_BORDA),
    )

    for col_idx, texto in enumerate(cabecalhos, start=1):
        c = ws.cell(row=linha_cabecalho, column=col_idx, value=texto)
        c.font = Font(name='Calibri', size=10, bold=True, color=COR_CABECALHO_TEXTO)
        c.fill = PatternFill(start_color=COR_CABECALHO_FUNDO, end_color=COR_CABECALHO_FUNDO, fill_type='solid')
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        c.border = borda_fina
    ws.row_dimensions[linha_cabecalho].height = 30

    # ---------- Linhas de dados ----------
    linha_atual = linha_cabecalho + 1
    for i, p in enumerate(itens_ordenados):
        medida = p.get('medida', 'un')
        preenchimento = PatternFill(start_color=COR_FAIXA, end_color=COR_FAIXA, fill_type='solid') if i % 2 == 1 else None

        valores = [
            p.get('codigo', '-'),
            str(p.get('nome', '')).upper(),
            medida,
            p.get('totalSaido', 0),
            p.get('mediaSemanal', 0),
            f"{p.get('pacotesSugeridos', 0)} {medida}",
        ]

        for col_idx, valor in enumerate(valores, start=1):
            c = ws.cell(row=linha_atual, column=col_idx, value=valor)
            c.border = borda_fina
            c.font = Font(name='Calibri', size=10, color="2D3748")
            if preenchimento:
                c.fill = preenchimento
            if col_idx == 2:
                c.alignment = Alignment(horizontal='left', vertical='center')
                c.font = Font(name='Calibri', size=10, bold=True, color="1A202C")
            elif col_idx in (4, 5):
                c.alignment = Alignment(horizontal='center', vertical='center')
                if col_idx == 5:
                    c.font = Font(name='Calibri', size=10, bold=True, color=COR_DESTAQUE)
            else:
                c.alignment = Alignment(horizontal='center', vertical='center')

        linha_atual += 1

    if not itens_ordenados:
        ws.merge_cells(start_row=linha_atual, start_column=1, end_row=linha_atual, end_column=total_colunas)
        vazio = ws.cell(row=linha_atual, column=1, value="Nenhum dado de consumo disponível.")
        vazio.alignment = Alignment(horizontal='center')
        vazio.font = Font(name='Calibri', size=10, italic=True, color=COR_SUBTITULO)
        linha_atual += 1

    # ---------- Rodapé com total de produtos ----------
    linha_atual += 1
    ws.cell(row=linha_atual, column=1, value=f"Total de produtos: {len(itens_ordenados)}").font = Font(
        name='Calibri', size=9, italic=True, color=COR_SUBTITULO
    )

    # ---------- Larguras de coluna e ajustes finais ----------
    larguras = {1: 16, 2: 34, 3: 10, 4: 16, 5: 24, 6: 20}
    for col_idx, largura in larguras.items():
        ws.column_dimensions[get_column_letter(col_idx)].width = largura

    ws.freeze_panes = ws.cell(row=linha_cabecalho + 1, column=1)
    ws.sheet_view.showGridLines = False

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    nome_arquivo = f"Media_Saida_Semanal_{datetime.now().strftime('%Y-%m-%d')}.xlsx"

    return send_file(
        buffer,
        as_attachment=True,
        download_name=nome_arquivo,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
