import os
import sys


def caminho_recurso(caminho_relativo):
    """
    Retorna o caminho correto para arquivos EMPACOTADOS e somente-leitura
    (ex: a pasta templates/ ou static/) tanto rodando com 'python app.py'
    quanto dentro do .exe gerado pelo PyInstaller (que extrai tudo para uma
    pasta temporária apontada por sys._MEIPASS).
    """
    base_path = getattr(sys, '_MEIPASS', os.path.abspath(os.path.dirname(__file__)))
    return os.path.join(base_path, caminho_relativo)


def caminho_dados(nome_arquivo):
    """
    Retorna o caminho correto para arquivos de DADOS que precisam ser
    lidos e GRAVADOS (banco.json, consumo_geral.json, etc). Esses arquivos
    ficam sempre dentro da pasta data/, ao lado do .exe (ou do projeto, em
    modo de desenvolvimento), nunca dentro da pasta temporária do
    PyInstaller — senão os dados salvos seriam perdidos ao fechar o programa.
    """
    if getattr(sys, 'frozen', False):
        base_path = os.path.dirname(sys.executable)
    else:
        base_path = os.path.abspath(os.path.dirname(__file__))
    pasta_dados = os.path.join(base_path, 'data')
    os.makedirs(pasta_dados, exist_ok=True)
    return os.path.join(pasta_dados, nome_arquivo)
