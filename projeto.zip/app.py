from flask import Flask

from config import caminho_recurso
from routes import TODOS_OS_BLUEPRINTS

app = Flask(
    __name__,
    template_folder=caminho_recurso('templates'),
    static_folder=caminho_recurso('static'),
)

for blueprint in TODOS_OS_BLUEPRINTS:
    app.register_blueprint(blueprint)


if __name__ == '__main__':
    app.run(debug=True, port=8000)
