import io
from datetime import datetime, date

from flask import Blueprint, request, send_file
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable

from models.banco import ler_banco

pdf_bp = Blueprint('pdf', __name__)


@pdf_bp.route('/api/gerar_pdf_servidor')
def gerar_pdf_servidor():
    data_str = request.args.get('data')
    if data_str:
        try:
            data_alvo_obj = datetime.strptime(data_str, '%Y-%m-%d')
            data_alvo_fmt = data_alvo_obj.strftime('%d/%m/%Y')
        except Exception:
            data_alvo_fmt = date.today().strftime('%d/%m/%Y')
            data_str = date.today().strftime('%Y-%m-%d')
    else:
        data_alvo_fmt = date.today().strftime('%d/%m/%Y')
        data_str = date.today().strftime('%Y-%m-%d')

    dados_para_imprimir = []
    try:
        conteudo = ler_banco()
        dados_para_imprimir = conteudo.get('saidas_confirmadas', [])
    except Exception as e:
        print(f"Erro ao ler o banco: {e}")

    # Cria o PDF
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)
    story = []
    styles = getSampleStyleSheet()

    # Estilos customizados para elegância
    estilo_titulo = ParagraphStyle(
        'TituloRelatorio',
        parent=styles['Heading1'],
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#1A365D'),
        spaceAfter=4
    )

    estilo_sub = ParagraphStyle(
        'SubRelatorio',
        parent=styles['Normal'],
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#4A5568'),
        spaceAfter=15
    )

    estilo_cabecalho_bloco = ParagraphStyle(
        'CabBloco',
        parent=styles['Normal'],
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#2D3748'),
        fontName='Helvetica-Bold'
    )

    estilo_item = ParagraphStyle(
        'ItemTabela',
        parent=styles['Normal'],
        fontSize=9,
        leading=12,
        textColor=colors.HexColor('#2D3748')
    )

    # Cabeçalho Principal do Documento
    story.append(Paragraph("RELATÓRIO DE SAÍDAS DO ESTOQUE", estilo_titulo))
    story.append(Paragraph(f"<b>Data de Emissão / Referência:</b> {data_alvo_fmt} &nbsp;|&nbsp; <b>Total de Registros:</b> {len(dados_para_imprimir)}", estilo_sub))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#1A365D'), spaceAfter=15))

    if dados_para_imprimir:
        for idx, registro in enumerate(dados_para_imprimir, 1):
            profissional = registro.get('profissional', 'Não informado')
            cliente = registro.get('cliente', 'SEM CLIENTE REGISTRADA')
            data_hora_reg = registro.get('data_hora', '')

            # Bloco de Informações do Lançamento
            info_texto = f"<b>#{idx} &nbsp;|&nbsp; Data/Hora:</b> {data_hora_reg}<br/><b>Profissional:</b> {profissional} &nbsp;&bull;&nbsp; <b>Cliente:</b> {cliente}"
            story.append(Paragraph(info_texto, estilo_cabecalho_bloco))
            story.append(Spacer(1, 5))

            # Monta os dados para a tabela de itens
            itens = registro.get('itens', [])
            tabela_dados = [["Produto", "Código de Barras", "Qtd"]]  # Cabeçalho da tabela interna

            for item in itens:
                nome_prod = item.get('nome', 'Item')
                codigo = item.get('codigo_barras', '-')
                qtd = f"{item.get('quantidade', 1)} {item.get('tipo_medida', 'un')}"
                tabela_dados.append([
                    Paragraph(nome_prod, estilo_item),
                    Paragraph(codigo, estilo_item),
                    Paragraph(qtd, estilo_item)
                ])

            # Criação da tabela estilizada para os itens
            tabela = Table(tabela_dados, colWidths=[250, 150, 100])
            tabela.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#EDF2F7')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor('#2D3748')),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 9),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
                ('TOPPADDING', (0, 0), (-1, -1), 5),
                ('ALIGN', (2, 0), (2, -1), 'CENTER'),  # Alinha quantidade ao centro
                ('LINEBELOW', (0, 0), (-1, 0), 1, colors.HexColor('#CBD5E0')),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E2E8F0')),
            ]))

            story.append(tabela)
            story.append(Spacer(1, 15))  # Espaço entre um bloco e outro
    else:
        story.append(Paragraph("Nenhum lançamento encontrado na lista de saídas confirmadas.", estilo_sub))

    doc.build(story)
    buffer.seek(0)

    return send_file(
        buffer,
        as_attachment=True,
        download_name="Relatorio_Estoque_Geral.pdf",
        mimetype='application/pdf'
    )
