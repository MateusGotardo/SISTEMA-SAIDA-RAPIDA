from flask import Blueprint, jsonify

from models.banco import ler_historico_consumo

historico_bp = Blueprint('historico', __name__)


@historico_bp.route('/api/historico_consumo_geral', methods=['GET'])
def historico_consumo_geral():
    try:
        dados = ler_historico_consumo()
        return jsonify({"sucesso": True, "registros": dados})
    except Exception as e:
        return jsonify({"sucesso": False, "registros": [], "mensagem": str(e)})
