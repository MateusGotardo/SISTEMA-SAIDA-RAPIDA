import unicodedata

import pandas as pd


def to_float_seguro(valor, default=0.0):
    """Converte valores vindos do Excel para float, aceitando também
    o formato brasileiro com vírgula decimal (ex: '0,750') e células vazias/NaN."""
    if valor is None:
        return default
    # NaN vindo do pandas (float) precisa ser tratado antes de virar string
    try:
        if isinstance(valor, float) and pd.isna(valor):
            return default
    except Exception:
        pass
    texto = str(valor).strip()
    if texto == '' or texto.lower() == 'nan':
        return default
    # Formato brasileiro: "1.234,56" -> remove separador de milhar e troca vírgula por ponto
    if ',' in texto:
        texto = texto.replace('.', '').replace(',', '.')
    try:
        return float(texto)
    except (ValueError, TypeError):
        return default


def encontrar_coluna(colunas_df, alvo):
    """Acha o nome real da coluna ignorando maiúsculas/acentos/espaços extras."""
    def normaliza(s):
        s = str(s).strip().lower()
        return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')
    alvo_norm = normaliza(alvo)
    candidatas = [c for c in colunas_df if alvo_norm in normaliza(c)]
    return candidatas
