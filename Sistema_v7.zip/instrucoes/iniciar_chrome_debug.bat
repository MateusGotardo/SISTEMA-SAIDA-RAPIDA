@echo off
REM ============================================================
REM Abre o Google Chrome com a depuracao remota ativada, para que a
REM automacao de lancamento na Graces consiga se conectar a ele.
REM
REM Usa um PERFIL SEPARADO (pasta ChromeDebugGraces dentro dos seus
REM Documentos), diferente do seu Chrome do dia a dia. Assim os dois podem
REM ficar abertos ao mesmo tempo sem conflito. Na primeira vez, sera
REM necessario fazer login na Graces normalmente dentro desta janela; nas
REM proximas vezes o login ja fica salvo neste perfil.
REM ============================================================

set PERFIL=%USERPROFILE%\Documents\ChromeDebugGraces
set PORTA=9222

start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" ^
    --remote-debugging-port=%PORTA% ^
    --user-data-dir="%PERFIL%" ^
    "https://www.gracesonline.com.br/sistema/operacao/recepcao"

echo.
echo Chrome aberto com depuracao remota na porta %PORTA%.
echo Faca login na Graces (se pedir), abra a comanda certa e o modal
echo "Repasse de Produto", e so entao clique em Lancar no seu dashboard.
echo.
pause
