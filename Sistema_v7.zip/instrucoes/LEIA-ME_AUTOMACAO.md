# Lançamento automático na Graces — como usar

## O que foi adicionado ao projeto

- `services/automacao_graces.py` — a automação em si (Playwright), controlando
  o modal "Repasse de Produto" da Graces.
- `routes/automacao.py` — endpoints Flask (`/api/automacao/iniciar`,
  `/status`, `/parar`, `/limpar_log`) que rodam a automação numa thread em
  segundo plano e expõem o progresso para o dashboard.
- Botão **🚀** em cada comanda pendente do painel de Histórico (ao lado dos
  botões ✓ e ✕ que já existiam), e um painel de progresso (`modalAutomacao`)
  com status por comanda e um botão **Parar**.
- `requirements.txt` com a dependência nova: `playwright`.
- Este guia e `iniciar_edge_debug.bat`.

## Sobre o navegador: Microsoft Edge

A automação usa o Playwright para se conectar a um navegador **já aberto**
via protocolo de depuração remota (CDP) — ela não abre um navegador
embutido próprio. O Edge é baseado em Chromium e fala exatamente esse
mesmo protocolo, então tudo funciona igual ao que funcionaria no Chrome:
não é preciso instalar nada além do Edge que você já usa.

## Passo a passo, toda vez que for usar

1. **Instale as dependências** (uma única vez):
   ```
   pip install -r requirements.txt
   ```
   Não é preciso rodar `playwright install` — a automação só se conecta a um
   navegador que você mesmo já abriu (não usa navegador embutido do Playwright).

2. **Abra o Edge com depuração remota**: dê duplo clique em
   `instrucoes/iniciar_edge_debug.bat`. Isso abre uma janela do Edge
   separada (perfil próprio, `EdgeDebugGraces`), já na Graces.
   - Na primeira vez, faça login normalmente. Nas próximas, o login já fica
     salvo nesse perfil.
   - **Importante**: use sempre essa janela (aberta pelo `.bat`) para a
     automação — não o seu Edge do dia a dia.
   - Se o `.bat` disser que não achou o `msedge.exe`, veja a nota dentro
     dele: dá pra descobrir o caminho certo pelo Gerenciador de Tarefas
     (botão direito no processo "Microsoft Edge" → "Abrir local do
     arquivo") e ajustar a linha `EDGE_EXE` do `.bat`.

3. **Na Graces**, abra a comanda certa e o modal "Repasse de Produto",
   exatamente como você já faz hoje. Deixe o modal aberto.

4. **No seu dashboard**, no Histórico de Pendentes, clique no botão **🚀** da
   comanda correspondente. Confirme no aviso que aparece.

5. Acompanhe o painel: cada produto é digitado, buscado e incluído um de
   cada vez, esperando a confirmação real na tabela do modal antes de seguir
   para o próximo. No fim, clica em "Salvar" uma única vez.

6. Se algo não puder ser confirmado (produto não encontrado, lentidão além
   do esperado), a automação **para completamente** e o painel mostra
   exatamente onde parou — o que já foi concluído com sucesso continua
   marcado com ✅, então dá pra saber o que falta fazer manualmente.

7. **Parar a qualquer momento**: botão "⏹️ Parar" no painel. Interrompe
   imediatamente, mesmo no meio de um campo preenchido sem confirmar — nesse
   caso, dê uma conferida visual no modal antes de continuar.

8. **O que continua manual, de propósito**: escolher/abrir a comanda certa
   na Graces, e marcar a saída como concluída no seu próprio sistema
   (botão verde que já existia, que gera o PDF).

## Se algum seletor não bater

Os seletores usados (`#select2-produtoSelect2-container`, `button.bt-salvar`,
etc.) foram escritos a partir da documentação do modal, não de uma inspeção
ao vivo do HTML da Graces. Se a automação não conseguir localizar algum
elemento, tudo que precisa ser ajustado está reunido no topo de
`services/automacao_graces.py`, na seção "SELETORES" — não deveria ser
necessário mexer no resto do código.

Para conferir o seletor certo: clique com o botão direito no elemento em
questão dentro do Edge (o mesmo aberto pelo `.bat`) → "Inspecionar".

## Empacotamento com PyInstaller

Se este projeto já é empacotado em um `.exe` (via `desktop.py`), o Playwright
usado aqui só precisa do pacote Python em si — nenhum navegador embutido.
Ainda assim, ao gerar o `.exe`, pode ser necessário incluir os arquivos de
driver internos do Playwright (o PyInstaller às vezes não detecta pacotes
que descompactam recursos em tempo de execução). Se o `.exe` gerado reclamar
de não achar o driver do Playwright, adicione ao `.spec`:
```python
from PyInstaller.utils.hooks import collect_all
datas, binaries, hiddenimports = collect_all('playwright')
```
e inclua `datas`, `binaries` e `hiddenimports` no `Analysis(...)` do seu
arquivo `.spec`. (Isso só é necessário se você compilar um `.exe` — rodando
com `python desktop.py` direto não precisa disso.)
