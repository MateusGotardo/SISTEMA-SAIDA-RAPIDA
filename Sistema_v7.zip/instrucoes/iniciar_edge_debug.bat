@echo off
REM ============================================================
REM Abre o Microsoft Edge com a depuracao remota ativada, para que a
REM automacao de lancamento na Graces consiga se conectar a ele.
REM (Edge e baseado em Chromium, entao fala o mesmo protocolo que o
REM Chrome — a automacao funciona identico.)
REM
REM Usa um PERFIL SEPARADO (pasta EdgeDebugGraces dentro dos seus
REM Documentos), diferente do seu Edge do dia a dia. Assim os dois podem
REM ficar abertos ao mesmo tempo sem conflito. Na primeira vez, sera
REM necessario fazer login na Graces normalmente dentro desta janela; nas
REM proximas vezes o login ja fica salvo neste perfil.
REM ============================================================

set PERFIL=%USERPROFILE%\Documents\EdgeDebugGraces
set PORTA=9222

set EDGE_EXE="C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if not exist %EDGE_EXE% set EDGE_EXE="C:\Program Files\Microsoft\Edge\Application\msedge.exe"

if not exist %EDGE_EXE% (
    echo Nao encontrei o msedge.exe nos caminhos padrao.
    echo Abra o Gerenciador de Tarefas, clique com o botao direito num
    echo processo "Microsoft Edge" e "Abrir local do arquivo" para achar o
    echo caminho certo, e ajuste a linha EDGE_EXE deste arquivo .bat.
    pause
    exit /b 1
)

start "" %EDGE_EXE% ^
    --remote-debugging-port=%PORTA% ^
    --user-data-dir="%PERFIL%" ^
    "https://www.gracesonline.com.br/sistema/operacao/recepcao"

echo.
echo Edge aberto com depuracao remota na porta %PORTA%.
echo Faca login na Graces (se pedir), abra a comanda certa e o modal
echo "Repasse de Produto", e so entao clique em Lancar no seu dashboard.
echo.
pause
