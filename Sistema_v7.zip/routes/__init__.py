from routes.dashboard import dashboard_bp
from routes.produtos import produtos_bp
from routes.profissionais import profissionais_bp
from routes.servicos import servicos_bp
from routes.saidas import saidas_bp
from routes.historico import historico_bp
from routes.importacao import importacao_bp
from routes.pdf import pdf_bp
from routes.excel import excel_bp
from routes.automacao import automacao_bp

TODOS_OS_BLUEPRINTS = [
    dashboard_bp,
    produtos_bp,
    profissionais_bp,
    servicos_bp,
    saidas_bp,
    historico_bp,
    importacao_bp,
    pdf_bp,
    excel_bp,
    automacao_bp,
]
