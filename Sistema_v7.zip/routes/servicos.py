from flask import Blueprint, request, jsonify

from models.banco import listar_servicos, criar_servico, excluir_servico

servicos_bp = Blueprint('servicos', __name__)


@servicos_bp.route('/api/buscar_servico', methods=['GET'])
def buscar_servico():
    """
    Busca rápida de serviços já cadastrados (Corte, Escova, Coloração...),
    igual ao padrão usado em /api/buscar_produto e /api/buscar_profissional.
    Sem 'termo' retorna todos, ordenados por nome (usado para listar/gerenciar).
    """
    termo = request.args.get('termo', '').strip()
    servicos = listar_servicos(termo or None)
    return jsonify({"sucesso": True, "servicos": servicos})


@servicos_bp.route('/api/cadastrar_servico', methods=['POST'])
def cadastrar_servico():
    dados = request.get_json() or {}
    nome = (dados.get('nome') or '').strip()

    servico, erro = criar_servico(nome)
    if erro:
        return jsonify({"sucesso": False, "mensagem": erro}), 400

    return jsonify({"sucesso": True, "mensagem": "Serviço cadastrado!", "servico": servico})


@servicos_bp.route('/api/excluir_servico', methods=['POST'])
def excluir_servico_rota():
    dados = request.get_json() or {}
    nome = (dados.get('nome') or '').strip()

    ok = excluir_servico(nome)
    if not ok:
        return jsonify({"sucesso": False, "mensagem": "Serviço não encontrado."}), 404

    return jsonify({"sucesso": True, "mensagem": "Serviço excluído com sucesso!"})
