from datetime import datetime

from flask import Blueprint, request, jsonify

from models.banco import (
    ler_banco,
    salvar_banco,
    ler_historico_consumo,
    salvar_historico_consumo,
    ajustar_estoque_produto,
)

saidas_bp = Blueprint('saidas', __name__)


def _proximo_id_saida(banco):
    """
    Usa max(id)+1 em vez de contar o tamanho das listas: como itens saem de
    saidas_pendentes (exclusão, confirmação) o tamanho da lista diminui, e um
    id baseado em len() podia colidir com um id já existente.
    """
    todos_ids = [s.get('id', 0) for s in banco.get('saidas_pendentes', [])] + \
                [s.get('id', 0) for s in banco.get('saidas_confirmadas', [])]
    return (max(todos_ids) + 1) if todos_ids else 1


@saidas_bp.route('/api/confirmar_saida', methods=['POST'])
def confirmar_saida():
    dados = request.get_json()
    itens = dados.get('itens', [])
    profissional = dados.get('profissional', '').strip()
    setor = dados.get('setor', 'manicure')
    cliente = dados.get('cliente', '').strip()

    if not itens or not profissional:
        return jsonify({"sucesso": False, "mensagem": "Preencha o profissional e adicione itens."}), 400

    # No setor cabeleireiro o nome da cliente é obrigatório: é ele que permite
    # vincular automaticamente os lançamentos futuros dessa cliente à
    # profissional que a atendeu pela primeira vez (ver /api/buscar_cliente).
    if setor == 'cabeleireiro' and not cliente:
        return jsonify({"sucesso": False, "mensagem": "Informe o nome da cliente para lançamentos de Cabeleireiro."}), 400

    banco = ler_banco()
    data_hora = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    data_hoje = datetime.now().strftime("%Y-%m-%d")  # Formato ideal para calcular as semanas no JS

    proximo_id = _proximo_id_saida(banco)

    nova_saida = {
        "id": proximo_id,
        "data_hora": data_hora,
        "profissional": profissional,
        "setor": setor,
        "cliente": cliente if cliente else "SEM CLIENTE REGISTRADA",
        "itens": itens
    }

    # Salva normalmente no fluxo do dia (banco.json)
    banco.setdefault('saidas_pendentes', []).append(nova_saida)
    salvar_banco(banco)

    # Baixa automática do estoque: assim que a saída é lançada (ainda pendente),
    # já abate a quantidade de cada item do estoque_atual do produto — não
    # espera aprovação/confirmação pro PDF do dia. Se este lançamento for
    # excluído antes de ser aprovado, o estoque volta (ver excluir_bloco_profissional).
    for item in itens:
        cod = item.get('codigo_barras')
        qtd = item.get('quantidade')
        try:
            qtd = float(qtd)
        except (TypeError, ValueError):
            qtd = 0
        if cod and qtd:
            ajustar_estoque_produto(cod, -qtd)

    # --- SALVA TAMBÉM NO ARQUIVO ACUMULADO PARA A MÉDIA DE COMPRAS ---
    # "id_saida" vincula este registro de consumo ao lançamento pendente que o
    # gerou, para que excluir_bloco_profissional consiga remover exatamente
    # este registro caso o lançamento seja excluído por engano (ver abaixo).
    registro_consumo = {
        "data": data_hoje,
        "data_hora": data_hora,
        "profissional": profissional,
        "setor": setor,
        "cliente": cliente if cliente else "SEM CLIENTE",
        "itens": itens,
        "id_saida": proximo_id,
    }

    try:
        consumo_lista = ler_historico_consumo()
    except Exception:
        consumo_lista = []

    consumo_lista.append(registro_consumo)
    salvar_historico_consumo(consumo_lista)
    # -----------------------------------------------------------------

    return jsonify({"sucesso": True, "mensagem": "Lançamento adicionado à fila do dia!"})


@saidas_bp.route('/api/buscar_cliente', methods=['GET'])
def buscar_cliente():
    """
    Autocomplete de clientes já atendidas: busca no histórico de consumo geral
    (que nunca é resetado, ao contrário de saidas_confirmadas) todas as clientes
    já lançadas para o setor informado e retorna, junto com o nome, a
    profissional que a atendeu na primeira vez (histórico já vem ordenado por
    id crescente = ordem cronológica de lançamento).
    """
    setor = request.args.get('setor', '').strip().lower()
    termo = request.args.get('termo', '').strip().lower()

    NOMES_IGNORADOS = {'', 'sem cliente', 'sem cliente registrada'}

    primeira_profissional_por_cliente = {}
    for registro in ler_historico_consumo():
        if setor and registro.get('setor', '').strip().lower() != setor:
            continue
        cliente = (registro.get('cliente') or '').strip()
        if cliente.lower() in NOMES_IGNORADOS:
            continue
        if cliente not in primeira_profissional_por_cliente:
            primeira_profissional_por_cliente[cliente] = registro.get('profissional', '').strip()

    resultado = [
        {"cliente": cliente, "profissional_original": profissional}
        for cliente, profissional in primeira_profissional_por_cliente.items()
        if not termo or termo in cliente.lower()
    ]
    resultado.sort(key=lambda c: c['cliente'].lower())

    return jsonify({"sucesso": True, "clientes": resultado[:8]})


@saidas_bp.route('/api/historico_agrupado_pendente', methods=['GET'])
def historico_agrupado_pendente():
    banco = ler_banco()
    saidas = banco.get('saidas_pendentes', [])

    # Cria um dicionário de consulta rápida para o código de barras pelo nome do produto
    mapa_produtos = {}
    for p in banco.get('produtos', []):
        nome_p = p.get('nome', '').strip().upper()
        cod_p = p.get('codigo_barras', '').strip()
        if nome_p:
            mapa_produtos[nome_p] = cod_p or 'S/COD'

    agrupado = {}
    for s in saidas:
        prof = s.get('profissional', 'Não Identificado').strip()
        setor = s.get('setor', 'manicure')
        cliente = s.get('cliente', '').strip() or "SEM CLIENTE REGISTRADA"

        chave = f"{prof.upper()}___{setor}___{cliente.upper()}"

        if chave not in agrupado:
            agrupado[chave] = {
                "chave": chave,
                "profissional": prof,
                "setor": setor,
                "cliente": cliente,
                "total_lancamentos": 0,
                "ids_lancamentos": [],
                "itens": {},
                # Mesma comanda (chave prof+setor+cliente), mas com os itens também
                # agrupados em sub-blocos por serviço (Corte, Escova, Coloração...),
                # já que na comanda real da Graces cada serviço é lançado à parte.
                # 'servico' fica None para itens sem serviço definido (ex.: manicure).
                "servicos": {}
            }

        agrupado[chave]["total_lancamentos"] += 1
        agrupado[chave]["ids_lancamentos"].append(s["id"])

        for item in s["itens"]:
            nome_item = item.get("nome", "").strip()
            servico = (item.get("servico") or "").strip() or None

            # Pega o código do item ou busca no cadastro geral de produtos pelo nome
            cod = item.get("codigo_barras", "").strip()
            if not cod or cod == "S/COD":
                cod = mapa_produtos.get(nome_item.upper(), "S/COD")

            # Salva de volta no item para garantir
            item["codigo_barras"] = cod

            qtd = item["quantidade"]
            medida = item.get("tipo_medida", "un")

            # A chave do item inclui o serviço: o mesmo produto usado em dois
            # serviços diferentes da mesma cliente (ex.: 1 luva na Escova e 1
            # luva na Coloração) não pode virar uma única linha somada — cada
            # serviço mantém sua própria quantidade, igual à comanda real.
            chave_item = f"{cod}_{nome_item}_{servico or ''}"

            if chave_item not in agrupado[chave]["itens"]:
                agrupado[chave]["itens"][chave_item] = {
                    "codigo_barras": cod,
                    "nome_produto": nome_item,
                    "quantidade": 0,
                    "tipo_medida": medida,
                    "servico": servico,
                    "ids_lancamentos": []
                }
            agrupado[chave]["itens"][chave_item]["quantidade"] += qtd
            # Guarda quais lançamentos (saídas pendentes) originaram esse produto,
            # para permitir a confirmação seletiva por checkbox no front-end
            if s["id"] not in agrupado[chave]["itens"][chave_item]["ids_lancamentos"]:
                agrupado[chave]["itens"][chave_item]["ids_lancamentos"].append(s["id"])

            servicos_do_bloco = agrupado[chave]["servicos"]
            if servico not in servicos_do_bloco:
                servicos_do_bloco[servico] = {"servico": servico, "itens": []}

    resultado = []
    for v in agrupado.values():
        # Distribui os itens (já somados por produto+serviço) dentro do
        # sub-bloco do serviço correspondente, na ordem em que os serviços
        # apareceram pela primeira vez nesta comanda.
        for item in v["itens"].values():
            v["servicos"][item["servico"]]["itens"].append(item)

        resultado.append({
            "chave": v["chave"],
            "profissional": v["profissional"],
            "setor": v["setor"],
            "cliente": v["cliente"],
            "total_lancamentos": v["total_lancamentos"],
            "ids_lancamentos": v["ids_lancamentos"],
            "itens": list(v["itens"].values()),
            "servicos": list(v["servicos"].values())
        })

    return jsonify({"sucesso": True, "agrupado": resultado, "saidas_brutas": saidas})


@saidas_bp.route('/api/confirmar_itens_selecionados', methods=['POST'])
def confirmar_itens_selecionados():
    """
    Confirma apenas os produtos marcados pelo usuário, mesmo que estejam
    misturados com outros produtos não selecionados dentro do mesmo lançamento.
    Fraciona o lançamento quando necessário: os itens selecionados vão para
    saidas_confirmadas, e os itens restantes continuam em saidas_pendentes.
    """
    dados = request.get_json()
    selecoes = dados.get('selecoes', [])

    if not selecoes:
        return jsonify({"sucesso": False, "mensagem": "Nenhum produto selecionado."}), 400

    # Agrupa as seleções por lançamento de origem para facilitar a checagem
    selecoes_por_lancamento = {}
    for sel in selecoes:
        idl = sel.get('id_lancamento')
        selecoes_por_lancamento.setdefault(idl, []).append(sel)

    banco = ler_banco()
    pendentes = banco.get('saidas_pendentes', [])

    novos_pendentes = []
    novos_confirmados = []
    proximo_id_disponivel = _proximo_id_saida(banco)

    for s in pendentes:
        sels_deste_lancamento = selecoes_por_lancamento.get(s['id'])

        if not sels_deste_lancamento:
            # Nenhum produto deste lançamento foi selecionado: continua pendente sem alterações
            novos_pendentes.append(s)
            continue

        itens_confirmar = []
        itens_restantes = []

        for item in s.get('itens', []):
            cod_item = (item.get('codigo_barras') or item.get('codigo') or '').strip()
            nome_item = (item.get('nome') or item.get('nome_produto') or '').strip().upper()

            selecionado = any(
                (sel.get('codigo_barras', '').strip() == cod_item) and
                (sel.get('nome_produto', '').strip().upper() == nome_item)
                for sel in sels_deste_lancamento
            )

            if selecionado:
                itens_confirmar.append(item)
            else:
                itens_restantes.append(item)

        # Só é fracionamento de verdade quando SOBRA e VAI parte do mesmo
        # lançamento — nesse caso o pedaço confirmado precisa de um id novo,
        # senão os dois pedaços (um em pendentes, outro em confirmadas) ficam
        # com o mesmo id do lançamento original.
        houve_fracionamento = bool(itens_confirmar) and bool(itens_restantes)

        if itens_confirmar:
            registro_confirmado = dict(s)
            registro_confirmado['itens'] = itens_confirmar
            if houve_fracionamento:
                registro_confirmado['id'] = proximo_id_disponivel
                proximo_id_disponivel += 1
            novos_confirmados.append(registro_confirmado)

        if itens_restantes:
            registro_restante = dict(s)
            registro_restante['itens'] = itens_restantes
            # Mantém o id original: é a continuação do mesmo lançamento pendente.
            novos_pendentes.append(registro_restante)
        # Se não sobrou nenhum item, o lançamento inteiro foi confirmado e não volta para pendentes

    banco['saidas_pendentes'] = novos_pendentes
    banco.setdefault('saidas_confirmadas', []).extend(novos_confirmados)
    salvar_banco(banco)

    return jsonify({"sucesso": True, "mensagem": "Produtos selecionados confirmados e gravados para o PDF do final do dia!"})


@saidas_bp.route('/api/aprovar_bloco_profissional', methods=['POST'])
def aprovar_bloco_profissional():
    dados = request.get_json()
    ids_lancamentos = dados.get('ids', [])

    banco = ler_banco()
    pendentes = banco.get('saidas_pendentes', [])

    a_transferir = [s for s in pendentes if s['id'] in ids_lancamentos]
    banco['saidas_pendentes'] = [s for s in pendentes if s['id'] not in ids_lancamentos]

    banco.setdefault('saidas_confirmadas', []).extend(a_transferir)
    salvar_banco(banco)
    return jsonify({"sucesso": True, "mensagem": "Bloco aprovado e gravado para o PDF do final do dia!"})


@saidas_bp.route('/api/excluir_bloco_profissional', methods=['POST'])
def excluir_bloco_profissional():
    dados = request.get_json()
    ids_lancamentos = dados.get('ids', [])

    banco = ler_banco()
    pendentes = banco.get('saidas_pendentes', [])

    a_excluir = [s for s in pendentes if s['id'] in ids_lancamentos]
    banco['saidas_pendentes'] = [s for s in pendentes if s['id'] not in ids_lancamentos]
    salvar_banco(banco)

    # Como a saída ainda não vai acontecer de verdade, devolve ao estoque
    # tudo o que tinha sido abatido no momento do lançamento (confirmar_saida).
    for s in a_excluir:
        for item in s.get('itens', []):
            cod = item.get('codigo_barras')
            qtd = item.get('quantidade')
            try:
                qtd = float(qtd)
            except (TypeError, ValueError):
                qtd = 0
            if cod and qtd:
                ajustar_estoque_produto(cod, qtd)

    # Remove também o(s) registro(s) de consumo criados em confirmar_saida para
    # estes mesmos lançamentos — senão o consumo excluído continua contando pra
    # sempre na média semanal, mesmo o estoque já tendo sido devolvido.
    try:
        consumo_lista = ler_historico_consumo()
    except Exception:
        consumo_lista = []
    consumo_lista_filtrada = [
        c for c in consumo_lista if c.get('id_saida') not in ids_lancamentos
    ]
    if len(consumo_lista_filtrada) != len(consumo_lista):
        salvar_historico_consumo(consumo_lista_filtrada)

    return jsonify({"sucesso": True, "mensagem": "Bloco excluído e estoque devolvido!"})


def _item_bate(item, cod_norm, nome_norm, servico_norm=None):
    cod_item = (item.get('codigo_barras') or item.get('codigo') or '').strip()
    nome_item = (item.get('nome') or item.get('nome_produto') or '').strip().upper()
    if cod_item != cod_norm or nome_item != nome_norm:
        return False
    if servico_norm is None:
        # Chamador não informou serviço (ex.: fluxos antigos/manicure) — não
        # filtra por serviço, mantém o comportamento de antes.
        return True
    servico_item = (item.get('servico') or '').strip().upper()
    return servico_item == servico_norm


def _ajustar_item_bloco(ids_lancamentos, codigo_barras, nome_produto, nova_quantidade, servico=None):
    """
    Edita (ou remove, se nova_quantidade <= 0) um produto específico dentro de
    uma comanda de Saídas Pendentes. O mesmo produto pode estar espalhado em
    mais de um lançamento pendente dentro do bloco (quando foi adicionado em
    momentos diferentes) — nesse caso o valor final fica todo no lançamento
    mais recente, e o produto é removido dos demais.

    'servico' identifica de qual sub-bloco (serviço) este produto veio — sem
    isso, o mesmo produto lançado em dois serviços diferentes da mesma
    cliente (ex.: luva na Escova e luva na Coloração) seria ambíguo.

    Sempre que a quantidade muda, devolve/retira a diferença do estoque_atual
    e espelha a MESMA alteração no histórico de consumo (via id_saida) —
    senão a média semanal continuaria contando o valor antigo para sempre.
    """
    ids_lancamentos = list(dict.fromkeys(ids_lancamentos or []))
    cod_norm = (codigo_barras or '').strip()
    nome_norm = (nome_produto or '').strip().upper()
    servico_norm = (servico or '').strip().upper() or None

    if not ids_lancamentos or not nome_norm:
        return False, "Dados insuficientes para localizar o produto."

    banco = ler_banco()
    pendentes = banco.get('saidas_pendentes', [])
    por_id = {s['id']: s for s in pendentes if s['id'] in ids_lancamentos}

    # Mantém a ordem em que os ids foram recebidos (cronológica), só filtrando
    # os lançamentos que de fato contêm este produto (neste serviço).
    lancamentos_com_item = [
        (sid, por_id[sid]) for sid in ids_lancamentos
        if sid in por_id and any(_item_bate(i, cod_norm, nome_norm, servico_norm) for i in por_id[sid].get('itens', []))
    ]
    if not lancamentos_com_item:
        return False, "Produto não encontrado no lançamento."

    quantidade_atual_total = 0.0
    unidade = 'un'
    for _, s in lancamentos_com_item:
        for item in s['itens']:
            if _item_bate(item, cod_norm, nome_norm, servico_norm):
                quantidade_atual_total += float(item.get('quantidade') or 0)
                unidade = item.get('tipo_medida', unidade)

    try:
        nova_quantidade = float(nova_quantidade)
    except (TypeError, ValueError):
        nova_quantidade = 0.0
    if nova_quantidade < 0:
        nova_quantidade = 0.0

    diferenca_estoque = quantidade_atual_total - nova_quantidade  # >0 = devolve estoque

    id_alvo = lancamentos_com_item[-1][0]  # lançamento mais recente do bloco

    for sid, s in lancamentos_com_item:
        s['itens'] = [i for i in s['itens'] if not _item_bate(i, cod_norm, nome_norm, servico_norm)]
        if sid == id_alvo and nova_quantidade > 0:
            s['itens'].append({
                "codigo_barras": cod_norm,
                "nome": nome_produto,
                "tipo_medida": unidade,
                "quantidade": nova_quantidade,
                "servico": servico,
            })

    # Remove da fila qualquer lançamento que tenha ficado sem nenhum item
    banco['saidas_pendentes'] = [s for s in pendentes if s.get('itens')]
    salvar_banco(banco)

    if cod_norm and diferenca_estoque:
        ajustar_estoque_produto(cod_norm, diferenca_estoque)

    # Espelha a mesma alteração no histórico de consumo (média semanal)
    try:
        consumo_lista = ler_historico_consumo()
    except Exception:
        consumo_lista = []

    ids_processados = {sid for sid, _ in lancamentos_com_item}
    for c in consumo_lista:
        if c.get('id_saida') not in ids_processados:
            continue
        c['itens'] = [i for i in c.get('itens', []) if not _item_bate(i, cod_norm, nome_norm, servico_norm)]
        if c.get('id_saida') == id_alvo and nova_quantidade > 0:
            c['itens'].append({
                "codigo_barras": cod_norm,
                "nome": nome_produto,
                "tipo_medida": unidade,
                "quantidade": nova_quantidade,
                "servico": servico,
            })

    salvar_historico_consumo(consumo_lista)

    if nova_quantidade <= 0:
        return True, "Produto removido da comanda."
    return True, "Quantidade atualizada."


def _trocar_codigo_item_bloco(ids_lancamentos, codigo_barras_atual, nome_produto, novo_codigo_barras, servico=None):
    """
    Troca o codigo_barras (o "retrato" congelado no momento do lançamento) de
    um produto já lançado em uma comanda de Saídas Pendentes, em todos os
    lançamentos do bloco onde ele aparece — sem mexer na quantidade.

    Necessário porque corrigir o código lá no cadastro de produtos
    (atualizar_item) NÃO reflete nos itens já lançados: cada item de
    saida_itens guarda sua própria cópia do código, não uma referência viva.

    'servico' identifica de qual sub-bloco (serviço) este produto veio — ver
    _ajustar_item_bloco.

    Também corrige o estoque: devolve a quantidade ao produto do código
    antigo (que foi baixado por engano) e debita do produto do código novo
    (o que de fato deveria ter sido baixado), e espelha a troca no histórico
    de consumo (média semanal) via id_saida.
    """
    ids_lancamentos = list(dict.fromkeys(ids_lancamentos or []))
    cod_norm = (codigo_barras_atual or '').strip()
    nome_norm = (nome_produto or '').strip().upper()
    novo_cod_norm = (novo_codigo_barras or '').strip()
    servico_norm = (servico or '').strip().upper() or None

    if not ids_lancamentos or not nome_norm:
        return False, "Dados insuficientes para localizar o produto."
    if not novo_cod_norm:
        return False, "Informe o novo código de barras."
    if novo_cod_norm == cod_norm:
        return False, "O novo código é igual ao atual."

    banco = ler_banco()
    pendentes = banco.get('saidas_pendentes', [])
    por_id = {s['id']: s for s in pendentes if s['id'] in ids_lancamentos}

    lancamentos_com_item = [
        (sid, por_id[sid]) for sid in ids_lancamentos
        if sid in por_id and any(_item_bate(i, cod_norm, nome_norm, servico_norm) for i in por_id[sid].get('itens', []))
    ]
    if not lancamentos_com_item:
        return False, "Produto não encontrado no lançamento."

    quantidade_atual_total = 0.0
    for _, s in lancamentos_com_item:
        for item in s['itens']:
            if _item_bate(item, cod_norm, nome_norm, servico_norm):
                quantidade_atual_total += float(item.get('quantidade') or 0)
                item['codigo_barras'] = novo_cod_norm

    salvar_banco(banco)

    # Devolve o estoque baixado (por engano) do código antigo e debita do novo
    if cod_norm and quantidade_atual_total:
        ajustar_estoque_produto(cod_norm, quantidade_atual_total)
    if novo_cod_norm and quantidade_atual_total:
        ajustar_estoque_produto(novo_cod_norm, -quantidade_atual_total)

    # Espelha a troca no histórico de consumo (média semanal)
    try:
        consumo_lista = ler_historico_consumo()
    except Exception:
        consumo_lista = []

    ids_processados = {sid for sid, _ in lancamentos_com_item}
    for c in consumo_lista:
        if c.get('id_saida') not in ids_processados:
            continue
        for item in c.get('itens', []):
            if _item_bate(item, cod_norm, nome_norm, servico_norm):
                item['codigo_barras'] = novo_cod_norm

    salvar_historico_consumo(consumo_lista)

    return True, "Código atualizado."


@saidas_bp.route('/api/trocar_codigo_item_pendente', methods=['POST'])
def trocar_codigo_item_pendente():
    dados = request.get_json()
    ids_lancamentos = dados.get('ids_lancamentos', [])
    codigo_barras = dados.get('codigo_barras', '')
    nome_produto = dados.get('nome_produto', '')
    novo_codigo_barras = dados.get('novo_codigo_barras', '')
    servico = dados.get('servico', '')

    ok, mensagem = _trocar_codigo_item_bloco(ids_lancamentos, codigo_barras, nome_produto, novo_codigo_barras, servico)
    return jsonify({"sucesso": ok, "mensagem": mensagem}), (200 if ok else 400)


@saidas_bp.route('/api/editar_quantidade_item_pendente', methods=['POST'])
def editar_quantidade_item_pendente():
    dados = request.get_json()
    ids_lancamentos = dados.get('ids_lancamentos', [])
    codigo_barras = dados.get('codigo_barras', '')
    nome_produto = dados.get('nome_produto', '')
    nova_quantidade = dados.get('nova_quantidade')
    servico = dados.get('servico', '')

    ok, mensagem = _ajustar_item_bloco(ids_lancamentos, codigo_barras, nome_produto, nova_quantidade, servico)
    return jsonify({"sucesso": ok, "mensagem": mensagem}), (200 if ok else 400)


@saidas_bp.route('/api/excluir_item_pendente', methods=['POST'])
def excluir_item_pendente():
    dados = request.get_json()
    ids_lancamentos = dados.get('ids_lancamentos', [])
    codigo_barras = dados.get('codigo_barras', '')
    nome_produto = dados.get('nome_produto', '')
    servico = dados.get('servico', '')

    ok, mensagem = _ajustar_item_bloco(ids_lancamentos, codigo_barras, nome_produto, 0, servico)
    return jsonify({"sucesso": ok, "mensagem": mensagem}), (200 if ok else 400)


@saidas_bp.route('/api/historico_confirmado_pdf', methods=['GET'])
def historico_confirmado_pdf():
    banco = ler_banco()

    # Cria mapa de produtos para injetar o código caso esteja faltando
    mapa_produtos = {}
    for p in banco.get('produtos', []):
        nome_p = p.get('nome', '').strip().upper()
        cod_p = p.get('codigo_barras', '').strip()
        if nome_p:
            mapa_produtos[nome_p] = cod_p or 'S/COD'

    confirmados = banco.get('saidas_confirmadas', [])

    # Normaliza os dados para garantir que todo item tenha 'codigo_barras' e 'nome'
    for c in confirmados:
        for item in c.get('itens', []):
            # Garante o nome padronizado
            if 'nome' not in item and 'nome_produto' in item:
                item['nome'] = item['nome_produto']
            elif 'nome_produto' not in item and 'nome' in item:
                item['nome_produto'] = item['nome']

            nome_item = item.get('nome', '').strip()

            # Garante o código de barras
            cod = item.get('codigo_barras', '').strip()
            if not cod or cod == 'S/COD':
                cod = mapa_produtos.get(nome_item.upper(), 'S/COD')
            item['codigo_barras'] = cod

    return jsonify({"sucesso": True, "confirmados": confirmados})


@saidas_bp.route('/api/resetar_historico', methods=['POST'])
def resetar_historico():
    banco = ler_banco()
    banco['saidas_confirmadas'] = []
    salvar_banco(banco)
    return jsonify({"sucesso": True, "mensagem": "Pronto para o novo dia!"})
