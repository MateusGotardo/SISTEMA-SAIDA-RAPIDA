import threading
import uuid

from flask import Blueprint, jsonify, request

from services.automacao_graces import executar_automacao

automacao_bp = Blueprint('automacao', __name__)

# Estado compartilhado entre a thread de automação e as requisições HTTP de
# status/parar. É intencionalmente global e em memória: este é um app
# desktop de um único usuário (ver desktop.py), então não há concorrência
# entre "sessões" a se preocupar — só entre a thread de automação e o
# polling feito pelo próprio dashboard.
_lock = threading.Lock()
_estado = {
    "rodando": False,
    "parar_solicitado": False,
    "item_atual": None,
    "erro": None,
    # Log acumulado de comandas lançadas durante a sessão atual do dashboard
    # (não reseta a cada clique em "🚀 Lançar" — cada novo lançamento é
    # adicionado à mesma lista, para o painel mostrar o histórico da sessão).
    "comandas": [],
}


def _estado_publico():
    return {
        "rodando": _estado["rodando"],
        "item_atual": _estado["item_atual"],
        "erro": _estado["erro"],
        "comandas": _estado["comandas"],
    }


def _rodar_em_thread(porta_debug):
    executar_automacao(_estado, porta_debug=porta_debug)


@automacao_bp.route('/api/automacao/iniciar', methods=['POST'])
def iniciar():
    dados = request.get_json() or {}
    profissional = (dados.get('profissional') or '').strip()
    cliente = (dados.get('cliente') or '').strip()
    setor = (dados.get('setor') or '').strip()
    itens = dados.get('itens') or []
    porta_debug = dados.get('porta_debug')

    if not itens:
        return jsonify({"sucesso": False, "mensagem": "Esta comanda não tem itens para lançar."}), 400

    with _lock:
        if _estado["rodando"]:
            return jsonify({
                "sucesso": False,
                "mensagem": "Já existe um lançamento em andamento. Aguarde terminar (ou clique em Parar) antes de iniciar outro."
            }), 409

        nova_comanda = {
            "id": str(uuid.uuid4()),
            "profissional": profissional,
            "cliente": cliente,
            "setor": setor,
            "itens": itens,
            "status": "pendente",
        }
        _estado["comandas"].append(nova_comanda)
        _estado["rodando"] = True
        _estado["parar_solicitado"] = False
        _estado["erro"] = None
        _estado["item_atual"] = None

        thread = threading.Thread(target=_rodar_em_thread, args=(porta_debug,), daemon=True)
        thread.start()

    return jsonify({"sucesso": True, "estado": _estado_publico()})


@automacao_bp.route('/api/automacao/status', methods=['GET'])
def status():
    return jsonify({"sucesso": True, "estado": _estado_publico()})


@automacao_bp.route('/api/automacao/parar', methods=['POST'])
def parar():
    _estado["parar_solicitado"] = True
    return jsonify({"sucesso": True})


@automacao_bp.route('/api/automacao/limpar_log', methods=['POST'])
def limpar_log():
    """Limpa o histórico do painel (só permitido fora de uma execução)."""
    with _lock:
        if _estado["rodando"]:
            return jsonify({"sucesso": False, "mensagem": "Não é possível limpar durante um lançamento em andamento."}), 409
        _estado["comandas"] = []
        _estado["erro"] = None
    return jsonify({"sucesso": True})
