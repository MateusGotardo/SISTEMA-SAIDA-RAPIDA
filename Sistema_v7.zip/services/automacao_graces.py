"""
Automação de lançamento de produtos na Plataforma Graces
(gracesonline.com.br), no modal "Repasse de Produto".

Não usa nenhuma API da Graces (não existe uma disponível) — controla o
próprio navegador do usuário (Microsoft Edge, que é baseado em Chromium)
via protocolo CDP (Chrome DevTools Protocol — o mesmo em qualquer
navegador Chromium, Edge incluso), através do Playwright. Por isso o Edge
precisa estar aberto com a porta de depuração remota ativada (ver
instrucoes/iniciar_edge_debug.bat e instrucoes/LEIA-ME_AUTOMACAO.md) e
com o modal "Repasse de Produto" já aberto na comanda certa — a escolha e
abertura da comanda continuam manuais, de propósito.

Os seletores na seção "SELETORES" abaixo foram confirmados via inspeção
ao vivo do HTML da Graces (não são mais um palpite a partir da
documentação). Se a Graces mudar algo no front-end deles, ou se algum
seletor não bater mais, ajuste as constantes ali — é o único lugar que
deveria precisar mudar.
"""

import contextlib
import time

from config import caminho_dados

try:
    from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
    _PLAYWRIGHT_DISPONIVEL = True
except ImportError:
    # Deixa o resto do app (dashboard, outras rotas) funcionar normalmente
    # mesmo se `pip install -r requirements.txt` ainda não tiver sido
    # rodado — o erro só aparece quando o usuário de fato tenta lançar
    # (ver executar_automacao), com uma mensagem clara do que fazer.
    sync_playwright = None
    PlaywrightTimeoutError = Exception
    _PLAYWRIGHT_DISPONIVEL = False

try:
    import ctypes
    import win32con
    import win32gui
    _WIN32_DISPONIVEL = True
except ImportError:
    # Sem pywin32 a automação continua funcionando (só sem o reforço de
    # foco abaixo) — ver ARQUIVO_LOG_TEMPOS e _forcar_foco_janela_graces.
    win32con = None
    win32gui = None
    _WIN32_DISPONIVEL = False


# ============================================================
# FOCO REAL DA JANELA — investigado em 05/09/2026
# ============================================================
#
# Comparando um clique manual (confirmação em ~1s, visto em vídeo) com a
# automação (log de tempos mostrando ~16s consistentes na mesma etapa,
# sempre o mesmo valor independente do produto) e o ícone do Edge
# piscando na barra de tarefas em vez de vir pra frente durante a
# automação, ficou confirmado: o Windows nunca dá foco de verdade pra
# janela do Edge/Graces durante a automação (ela fica em segundo plano
# o tempo todo, rodando em prioridade reduzida) — o "bring_to_front()"
# do Playwright só move a aba pra frente DENTRO do navegador, não força
# o Windows a trocar o foco quando são janelas separadas.
#
# _forcar_foco_janela_graces() usa o truque clássico de simular uma
# tecla ALT antes do SetForegroundWindow — o Windows bloqueia pedidos de
# foco vindos de processos que não estão em primeiro plano
# ("foreground lock"), e simular uma tecla é a forma padrão de destravar
# isso sem precisar mexer em nenhuma configuração do sistema.


def _forcar_foco_janela_graces(pagina):
    """
    Garante que a janela do Edge com a Graces tenha o foco real do
    Windows (não só o foco interno do navegador) antes de mexer nela.

    Testado em 05/09/2026: o truque de simular ALT (versão anterior desta
    função) funcionou de forma INCONSISTENTE — no log de tempos, os
    2 primeiros itens de uma rodada continuaram em ~16s e só o 3º caiu
    pra ~4s. Isso bate com relatos conhecidos de que esse truque de tecla
    é pouco confiável dependendo da versão do Windows.

    Troca de abordagem: em vez de tentar "arrombar" a trava do Windows
    (ForegroundLockTimeout, que por padrão é de 200 segundos), a gente
    desliga essa trava por um instante (SystemParametersInfoW com
    SPI_SETFOREGROUNDLOCKTIMEOUT=0), chama o SetForegroundWindow SEM
    bloqueio nenhum, e devolve a trava pro valor original logo em
    seguida — mesma técnica usada por bibliotecas de UI (ex.: GLFW) pra
    isso funcionar de forma confiável.

    Só uma melhoria de velocidade: se o pywin32 não estiver instalado,
    ou a janela não for encontrada, ou qualquer coisa der errado aqui,
    simplesmente não faz nada — a automação continua funcionando do
    jeito que já funcionava antes, só mais devagar.
    """
    if not _WIN32_DISPONIVEL:
        return
    try:
        titulo_pagina = (pagina.title() or "").strip().lower()
        if not titulo_pagina:
            return

        alvo_hwnd = []

        def _callback(hwnd, _):
            if win32gui.IsWindowVisible(hwnd) and titulo_pagina in win32gui.GetWindowText(hwnd).lower():
                alvo_hwnd.append(hwnd)

        win32gui.EnumWindows(_callback, None)
        if not alvo_hwnd:
            return
        hwnd = alvo_hwnd[0]

        SPI_GETFOREGROUNDLOCKTIMEOUT = 0x2000
        SPI_SETFOREGROUNDLOCKTIMEOUT = 0x2001
        SPIF_SENDCHANGE = 0x2

        user32 = ctypes.windll.user32
        valor_anterior = ctypes.c_uint(0)
        user32.SystemParametersInfoW(SPI_GETFOREGROUNDLOCKTIMEOUT, 0, ctypes.byref(valor_anterior), 0)
        try:
            # Desliga a trava (0 = sem espera) só pelo tempo desta chamada.
            user32.SystemParametersInfoW(SPI_SETFOREGROUNDLOCKTIMEOUT, 0, 0, SPIF_SENDCHANGE)
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            win32gui.SetForegroundWindow(hwnd)
        finally:
            # Devolve a trava pro valor original do sistema do usuário,
            # não mexe na configuração dele de forma permanente.
            user32.SystemParametersInfoW(SPI_SETFOREGROUNDLOCKTIMEOUT, 0, valor_anterior, SPIF_SENDCHANGE)
    except Exception:
        pass


# ============================================================
# LOG DE TEMPOS — só mede e grava, não muda nenhum comportamento
# ============================================================

# Arquivo onde cada etapa do lançamento de cada item fica registrada com
# sua duração, pra descobrir na prática onde o tempo está indo (em vez de
# chutar). Fica em data/, ao lado do banco.db.
ARQUIVO_LOG_TEMPOS = caminho_dados("tempos_automacao.log")


@contextlib.contextmanager
def _cronometro(estado, etapa):
    """
    Mede quanto tempo o bloco 'with' levou e acrescenta uma linha em
    ARQUIVO_LOG_TEMPOS (data\\tempos_automacao.log): data/hora, item atual,
    nome da etapa e duração em segundos. Não interfere em timeout, retry
    ou no resultado de nada — se não conseguir gravar o log por algum
    motivo, ignora e segue o lançamento normalmente.
    """
    inicio = time.perf_counter()
    try:
        yield
    finally:
        duracao = time.perf_counter() - inicio
        item = estado.get("item_atual") or "?"
        linha = f"{time.strftime('%Y-%m-%d %H:%M:%S')}\t{item}\t{etapa}\t{duracao:.2f}s\n"
        try:
            with open(ARQUIVO_LOG_TEMPOS, "a", encoding="utf-8") as f:
                f.write(linha)
        except Exception:
            pass


# ============================================================
# CONFIGURAÇÃO — ajuste aqui se necessário
# ============================================================

# Porta de depuração remota do Edge (ver instrucoes/iniciar_edge_debug.bat).
PORTA_DEBUG_PADRAO = 9222

# Trecho da URL usado para identificar, entre as abas abertas do Edge,
# qual delas é a da Graces.
URL_GRACES = "gracesonline.com.br"

# Tempo máximo de espera pela opção única aparecer na lista do Select2
# depois de digitar o código de barras (rede lenta = mais tempo, não erro).
TIMEOUT_BUSCA_PRODUTO_MS = 15_000

# Tempo máximo de espera pela nova linha aparecer na tabela do modal depois
# de clicar em "Incluir". Deliberadamente maior que o de busca: é o passo
# mais sensível a lentidão de rede (ver documentação: "buga tudo" se for
# um tempo fixo curto).
TIMEOUT_CONFIRMACAO_INCLUIR_S = 30
INTERVALO_VERIFICACAO_S = 0.4

# Quanto esperar pela linha nova antes de tentar reclicar em "Incluir".
# Investigado em 05/09/2026: pelos prints do DevTools (aba Network), toda
# requisição da Graces responde em bem menos de 1s quando o clique de fato
# dispara alguma coisa — e o log de tempos mostrou que o PRIMEIRO clique em
# "Incluir" normalmente não dispara nada (a linha só aparece depois do
# reclique, sempre ~15s + a resposta real do servidor). Ou seja, esperar
# metade do timeout total (15s) antes de reclicar era o próprio motivo do
# atraso de ~16s por item — não era lentidão de rede. Uma folga de poucos
# segundos já é generosa (bem acima de qualquer tempo visto no Network) e
# ainda funciona como rede de segurança pra picos de lentidão pontuais.
TEMPO_ESPERA_RECLIQUE_S = 3

# Investigado em 05/09/2026 (erro real, print do usuário): o clique em
# "Incluir" as vezes trava porque outro elemento fica sobreposto a ele na
# tela ("subtree intercepts pointer events") — suspeito nº1: um resíduo do
# dropdown do Select2 de produto que não fechou de verdade. Sem um timeout
# PRÓPRIO aqui, esse clique ficava usando o padrão do Playwright (30s) e,
# pior, sem tratamento nenhum — a exceção crua e verbosa dele (o log
# interno de retry) caía direto no except genérico de executar_automacao()
# e aparecia do jeito feio no painel. Bem mais curto que
# TIMEOUT_CONFIRMACAO_INCLUIR_S de propósito: aqui é só "o clique em si
# saiu do lugar", não "o servidor demorou pra responder" — não faz sentido
# esperar 30s pra constatar isso.
TIMEOUT_CLIQUE_INCLUIR_MS = 8_000


# ============================================================
# SELETORES — ajuste aqui se a Graces mudar o HTML
# ============================================================

# Confirmado ao vivo em 05/09/2026 (print do usuário) que o modal de
# lançamento direto na comanda da cliente usa o MESMO id "repasse-produto"
# do modal de uso interno — ou seja, é o mesmo modal/componente nos dois
# fluxos, não dois diferentes como se imaginava antes de checar. Mesmo
# assim os seletores abaixo continuam pegando sempre o campo Select2 que
# estiver VISÍVEL no momento (em vez de depender de algum id), o que
# segue correto e não precisa mudar.
SEL_SELECT2_CONTAINER = ".select2-selection:visible"
SEL_SELECT2_CAMPO_BUSCA = ".select2-container--open .select2-search__field"
SEL_SELECT2_OPCAO = ".select2-container--open .select2-results__option"
# Usado só pra detectar/fechar um dropdown que ficou aberto sem querer
# (ver _fechar_select2_residual) — não pra abrir/selecionar nada.
SEL_SELECT2_DROPDOWN_ABERTO = ".select2-container--open"
# 2ª camada de limpeza, adicionada em 05/09/2026 depois que o fix acima
# (fechar só ".select2-container--open" com Esc) NÃO resolveu o erro na
# prática (mesmo erro se repetiu). O Select2 normalmente anexa a listinha
# flutuante de verdade (".select2-dropdown") direto no <body>, separada do
# container original — se o Angular recriar/destruir o container do
# produto entre um item e outro (que é exatamente o caso aqui, vários
# itens seguidos na mesma comanda), a classe "--open" some do container,
# mas a ".select2-dropdown" pode ficar órfã no body, ainda sobrepondo o
# botão "Incluir" e bloqueando o clique, sem que o seletor acima detecte
# nada. Ver _fechar_select2_residual.
SEL_SELECT2_DROPDOWN_FLUTUANTE = ".select2-dropdown"
# Texto que aparece no campo já FECHADO, depois de escolher um produto
# (ou o placeholder "Pesquise o Produto" se nada foi escolhido ainda).
# Usado só para CONFIRMAR que a seleção realmente colou (ver
# _confirmar_produto_selecionado) — não para abrir/fechar o campo.
SEL_SELECT2_RENDERIZADO = ".select2-selection__rendered:visible"
TEXTO_PLACEHOLDER_PRODUTO = "PESQUISE O PRODUTO"


# A Graces mantém vários componentes/modais parecidos escondidos no DOM
# ao mesmo tempo (foi isso que quebrou o campo de quantidade: 3
# elementos batendo com o mesmo seletor, sendo 2 escondidos). Por
# segurança, todo seletor abaixo que pode se repetir em outro
# componente escondido usa ":visible", pra sempre pegar só o que está
# de fato na tela.
SEL_CAMPO_QUANTIDADE = "input[appinteger][type='number']:visible"
# Confirmado com o HTML real do botão em 05/09/2026 (print do usuário):
# <button class="btn btn-darkgray bt-salvar btn-block mt-2" role="button">Incluir</button>
# dentro de #repasse-produto > .modal-body > .row > .col-md-2...text-right.
# ".bt-salvar" sozinha já é só desse botão dentro desse modal (não é uma
# classe genérica tipo "mat-success", que causou confusão no botão
# Salvar — ver SEL_BOTAO_SALVAR_INTERNO/GENERICO), mas escopar em
# "#repasse-produto" de propósito, igual já é feito pro Salvar, elimina
# de vez qualquer ambiguidade com outro ".bt-salvar" escondido em outro
# modal parecido que a Graces mantenha no DOM ao mesmo tempo.
SEL_BOTAO_INCLUIR = "#repasse-produto button.bt-salvar:visible"
# Investigado em 05/09/2026 (print real do erro): a linha "Total: R$ ..."
# que fica destacada embaixo da tabela também é um <tr> dentro do mesmo
# <tbody>, e sempre fica depois de todos os produtos no DOM. Sem o
# :not(:has-text('Total')) abaixo, ".last" (ver _clicar_incluir_e_confirmar)
# pegava essa linha do Total em vez do produto recém-incluído — a
# comparação de quantidade nunca batia, e a automação sempre estourava o
# timeout achando que o produto não tinha sido confirmado, mesmo ele já
# estando certinho na tabela.
SEL_TABELA_MODAL_LINHAS = "table.table-hover tbody tr:visible:not(:has-text('Total'))"
# Botão "Salvar" do rodapé do modal (verde, Angular Material).
#
# Investigado em 05/09/2026: a suposição original abaixo — de que
# "mat-success" seria exclusiva desse botão — estava ERRADA. Um teste ao
# vivo (document.querySelectorAll('button.mat-success')) mostrou 5
# elementos diferentes na mesma página usando essa classe (que é só uma cor
# genérica de "sucesso", reaproveitada em vários lugares): um link de
# navegação, um menu (⋮) — esse sim DESABILITADO, batendo exatamente com o
# erro "element is not enabled" que a automação vinha recebendo —, um botão
# "Aplicar" de algum filtro, e só então o(s) botão(ões) "Salvar" de verdade.
# Ou seja, ".first" podia pegar o botão errado (o menu desabilitado) em vez
# do Salvar.
#
# Correção final: inspecionando o botão real (botão direito -> Inspecionar)
# confirmou que o modal "Repasse de Produto" (uso interno) tem um id ÚNICO
# e estável — id="repasse-produto" — algo que nenhum outro componente da
# página deveria ter. Por isso o seletor abaixo escopa a busca pra DENTRO
# desse id quando esse é o modal aberto, e o texto "Salvar" continua
# exigido como segurança extra (via .filter(has_text=...)).
#
# Ajustado em 05/09/2026: essa mesma automação também é usada no modal de
# lançamento direto na comanda da cliente, que NÃO tem o id "repasse-
# produto" — usar só SEL_BOTAO_SALVAR_INTERNO nesse caso não acha nada e
# reproduz o erro antigo (clique no botão errado / timeout). Ver
# _botao_salvar() logo abaixo: tenta primeiro dentro do id conhecido
# (uso interno) e, se não achar nada ali, cai para uma busca em toda a
# página que aplica a MESMA regra de segurança na mão — texto "Salvar" +
# visível + habilitado (exclui o menu ⋮ desabilitado e qualquer "Salvar"
# escondido de outro modal) — até confirmarmos em campo se o modal da
# cliente também tem algum id/atributo único que permita escopar do
# mesmo jeito que o de uso interno.
SEL_BOTAO_SALVAR_INTERNO = "#repasse-produto button.mat-success:visible"
# :not([disabled]) substitui a proteção que o id #repasse-produto dava de
# graça no caso de uso interno — sem ele, na busca genérica o menu ⋮
# desabilitado voltaria a bater com o filtro de texto (ver histórico do
# erro "element is not enabled" no comentário acima).
SEL_BOTAO_SALVAR_GENERICO = "button.mat-success:visible:not([disabled])"



class AutomacaoInterrompida(Exception):
    """Levantada internamente quando o usuário pede para parar (botão Parar)."""


class ErroLancamento(Exception):
    """Levantada quando uma etapa não pôde ser confirmada (ex.: produto não
    encontrado, linha não apareceu na tabela após Incluir)."""


def _checar_parar(estado):
    if estado.get("parar_solicitado"):
        raise AutomacaoInterrompida()


def _conectar_pagina_graces(playwright, porta_debug):
    """
    Conecta ao Edge já aberto pelo usuário via CDP (não abre um navegador
    novo) e localiza a aba que já está na Graces, com o modal "Repasse de
    Produto" aberto.
    """
    try:
        navegador = playwright.chromium.connect_over_cdp(f"http://localhost:{porta_debug}")
    except Exception as e:
        raise ErroLancamento(
            f"Não foi possível conectar ao Edge na porta {porta_debug}. "
            f"Confirme que o Edge foi aberto com a depuração remota ativada "
            f"(ver instrucoes/iniciar_edge_debug.bat). Detalhe: {e}"
        )

    pagina = None
    for contexto in navegador.contexts:
        for p in contexto.pages:
            if URL_GRACES in p.url:
                pagina = p
                break
        if pagina:
            break

    if pagina is None:
        raise ErroLancamento(
            f"Nenhuma aba aberta no Edge contém '{URL_GRACES}'. "
            f"Abra a Graces e deixe o modal 'Repasse de Produto' aberto antes de lançar."
        )

    pagina.bring_to_front()
    _forcar_foco_janela_graces(pagina)
    return navegador, pagina


def _texto_normalizado(txt):
    return (txt or "").strip().upper()


def _formatar_quantidade(qtd):
    """Normaliza a quantidade para uma string de comparação tolerante
    (2 e 2.0 e 2,0 devem bater)."""
    try:
        n = float(str(qtd).replace(",", "."))
    except (TypeError, ValueError):
        return str(qtd).strip()
    return str(int(n)) if n == int(n) else str(n)


def _linha_bate_com_item(texto_linha, quantidade):
    """
    Confere se a última linha da tabela do modal tem a quantidade
    recém-incluída.

    Não compara mais o NOME do produto contra a linha: o nome cadastrado
    na Graces pode (e costuma) ser diferente do nome usado no seu sistema
    — ex.: seu sistema chama de "Toalha de Pé", mas na Graces está
    cadastrado como "WIPER TOALHA PÉ 28CMX300M NR". Comparar nome causava
    falso negativo (lançamento funcionava, mas a confirmação achava que
    tinha falhado). A garantia de que é o produto certo já vem de ter sido
    selecionado pelo código de barras, que é único
    (ver _confirmar_produto_selecionado) — não precisa do nome de novo aqui.
    """
    qtd_norm = _formatar_quantidade(quantidade)
    # Quebra a linha em "palavras" (números/textos separados por espaço ou
    # tabulação, que é como Playwright costuma devolver células de tabela).
    partes = texto_linha.replace("\t", " ").split()
    return any(_formatar_quantidade(p.replace(",", ".")) == qtd_norm for p in partes if p.strip())


def _abrir_select2_produto(pagina, estado):
    """
    Clica no campo de produto (Select2) até o campo de busca interno
    aparecer. Depois de incluir um item, o Angular re-renderiza esse
    trecho do modal e o container fica escondido/instável por uma fração
    de segundo — por isso aqui esperamos ele ficar visível, rolamos a
    tela até ele (evita "element is not visible" quando fica atrás de
    outro elemento) e, se o primeiro clique não abrir a busca a tempo,
    tentamos mais uma vez em vez de estourar o erro na primeira falha.
    """
    container = pagina.locator(SEL_SELECT2_CONTAINER).first
    campo_busca = pagina.locator(SEL_SELECT2_CAMPO_BUSCA)

    tentativas_maximas = 3
    for tentativa in range(1, tentativas_maximas + 1):
        _checar_parar(estado)
        container.wait_for(state="visible", timeout=TIMEOUT_BUSCA_PRODUTO_MS)
        container.scroll_into_view_if_needed()
        container.click()

        try:
            campo_busca.wait_for(state="visible", timeout=5_000)
            return campo_busca
        except PlaywrightTimeoutError:
            if tentativa == tentativas_maximas:
                raise
            # Modal ainda se acomodando do item anterior: espera um
            # pouco e tenta clicar de novo em vez de desistir.
            time.sleep(0.6)


def _confirmar_produto_selecionado(pagina, codigo_barras, estado):
    """
    Depois de clicar na opção do Select2, confirma que o campo realmente
    fechou mostrando o produto escolhido (em vez de voltar sozinho pro
    placeholder "Pesquise o Produto"). Existe porque, na prática, a
    opção às vezes "pisca" na tela e some sem a seleção realmente colar
    — aí o resto do fluxo (quantidade, Incluir) seguia em frente sem
    produto nenhum escolhido, e o erro só aparecia depois, na própria
    Graces, sem indicar o motivo real.
    """
    renderizado = pagina.locator(SEL_SELECT2_RENDERIZADO).first
    prazo_final = time.monotonic() + 5
    while time.monotonic() < prazo_final:
        texto = _texto_normalizado(renderizado.inner_text())
        if texto and TEXTO_PLACEHOLDER_PRODUTO not in texto:
            return
        time.sleep(0.2)

    raise ErroLancamento(
        f"O produto com código '{codigo_barras}' não ficou selecionado no campo "
        f"da Graces depois do clique na opção (o campo voltou a mostrar "
        f"'Pesquise o Produto'). A lista de resultados pode ter fechado antes "
        f"da escolha ser confirmada — tente novamente."
    )


def _buscar_e_selecionar_produto(pagina, codigo_barras, estado):
    tentativas_maximas = 2
    ultimo_erro = None

    for tentativa in range(1, tentativas_maximas + 1):
        _checar_parar(estado)
        with _cronometro(estado, f"abrir_campo_produto(tent{tentativa})"):
            campo_busca = _abrir_select2_produto(pagina, estado)

        with _cronometro(estado, f"digitar_e_aguardar_opcao(tent{tentativa})"):
            # Digita caractere a caractere (em vez de colar tudo de uma vez com
            # fill()) para disparar os mesmos eventos de teclado que um usuário
            # de verdade dispararia — alguns desses campos de busca só reagem
            # de forma confiável assim, e colar tudo de uma vez foi o que causava
            # a lista de resultado aparecer/piscar de forma instável.
            campo_busca.fill("")  # garante que não sobrou nada de uma tentativa anterior
            campo_busca.press_sequentially(str(codigo_barras), delay=60)

            opcao = pagina.locator(SEL_SELECT2_OPCAO).first
            try:
                opcao.wait_for(state="visible", timeout=TIMEOUT_BUSCA_PRODUTO_MS)
            except PlaywrightTimeoutError:
                raise ErroLancamento(
                    f"Produto com código '{codigo_barras}' não foi encontrado na Graces "
                    f"(a lista de resultados do Select2 ficou vazia)."
                )

        _checar_parar(estado)
        with _cronometro(estado, f"clicar_e_confirmar_produto(tent{tentativa})"):
            opcao.click()

            try:
                _confirmar_produto_selecionado(pagina, codigo_barras, estado)
                return
            except ErroLancamento as e:
                ultimo_erro = e
                if tentativa < tentativas_maximas:
                    time.sleep(0.5)  # deixa o modal se acomodar antes de tentar de novo

    raise ultimo_erro


def _preencher_quantidade(pagina, quantidade, estado):
    """
    Preenche a quantidade e CONFERE se o valor realmente colou no campo —
    até agora só a seleção de produto tinha essa checagem
    (_confirmar_produto_selecionado); a quantidade era preenchida "às
    cegas". Isso importa porque SEL_CAMPO_QUANTIDADE é um seletor genérico
    (".first" sobre todo input numérico visível) e a Graces já mostrou,
    em outros pontos do modal, mais de um elemento parecido visível ao
    mesmo tempo — se isso acontecer aqui, o ".first" pode pegar um campo
    que não é o de quantidade, e sem essa conferência isso só ia estourar
    de forma confusa lá na frente, no clique do Incluir.
    """
    _checar_parar(estado)
    campo_qtd = pagina.locator(SEL_CAMPO_QUANTIDADE).first
    campo_qtd.wait_for(state="visible", timeout=TIMEOUT_BUSCA_PRODUTO_MS)

    valor_esperado = _formatar_quantidade(quantidade)
    tentativas_maximas = 3
    for tentativa in range(1, tentativas_maximas + 1):
        _checar_parar(estado)
        campo_qtd.fill("")
        campo_qtd.fill(str(quantidade))

        valor_atual = _formatar_quantidade(campo_qtd.input_value())
        if valor_atual == valor_esperado:
            return

        if tentativa < tentativas_maximas:
            time.sleep(0.3)

    raise ErroLancamento(
        f"Tentei digitar '{quantidade}' no campo de quantidade, mas ele "
        f"ficou mostrando '{campo_qtd.input_value()}'. Ou a Graces "
        "rejeitou o valor, ou o seletor genérico de quantidade pegou o "
        "campo errado (mais de um input numérico visível ao mesmo tempo)."
    )


def _fechar_select2_residual(pagina):
    """
    Fecha/remove qualquer resíduo do Select2 de produto que possa estar
    sobreposto ao botão "Incluir" bem na hora do clique. Investigado em
    05/09/2026 a partir de um erro real: o clique em "Incluir" travava com
    "subtree intercepts pointer events" repetido até estourar o timeout —
    ou seja, algo ficou sobreposto ao botão bloqueando o clique.

    Duas camadas, porque a 1ª sozinha NÃO resolveu o erro na prática (o
    mesmo erro se repetiu depois de implementada):

    1) Esc se o container ainda estiver marcado como aberto
       (.select2-container--open) — atalho nativo do Select2, não deveria
       afetar mais nada na tela.
    2) Remoção direta de qualquer ".select2-dropdown" que sobrou no
       <body> — o Select2 normalmente anexa a listinha flutuante de
       verdade ali, separada do container. Se o Angular recriar/destruir
       o container do produto entre um item e outro (comum lançando vários
       itens seguidos na mesma comanda), a classe "--open" some do
       container e a camada 1 não detecta nada, mas a ".select2-dropdown"
       pode ficar órfã no body — ainda visível/sobreposta o bastante pra
       roubar o clique, mesmo sem nenhum container marcado como aberto.
    """
    if pagina.locator(SEL_SELECT2_DROPDOWN_ABERTO).count() > 0:
        pagina.keyboard.press("Escape")
        time.sleep(0.3)

    if pagina.locator(SEL_SELECT2_DROPDOWN_FLUTUANTE).count() > 0:
        pagina.evaluate(
            "() => document.querySelectorAll('.select2-dropdown')"
            ".forEach(el => el.remove())"
        )
        time.sleep(0.1)


def _elemento_bloqueando_clique(pagina, alvo):
    """
    Descobre, via JS (document.elementFromPoint), qual elemento está
    realmente no topo da pilha visual bem no centro do elemento `alvo` —
    usado só como DIAGNÓSTICO quando o clique falha por "outro elemento
    sobreposto", em vez de continuar só chutando que é sempre o mesmo
    suspeito (resíduo do Select2). Devolve uma descrição curta
    (tag/classe/id) do elemento encontrado, ou None se não conseguir
    calcular (ex.: o alvo não tem bounding box no momento).

    Formatada com COLCHETES ("[tag ...]"), nunca "< >": a 1ª versão disso
    usava "<tag class=... id=...>" e, como o dashboard.js (linha ~304)
    joga estado.erro.mensagem direto num innerHTML sem escapar, o
    navegador interpretava aquele texto como uma tag HTML de verdade
    (inválida) e simplesmente sumia com ela — sobrava só o ponto final da
    frase no painel, sem nenhuma pista visível. Bug real, visto ao vivo
    em 05/09/2026, na própria correção anterior.
    """
    try:
        caixa = alvo.bounding_box()
        if not caixa:
            return None
        x = caixa["x"] + caixa["width"] / 2
        y = caixa["y"] + caixa["height"] / 2
        return pagina.evaluate(
            """([x, y]) => {
                const el = document.elementFromPoint(x, y);
                if (!el) return null;
                const cls = (el.className && el.className.toString) ? el.className.toString() : el.className;
                return `[${el.tagName.toLowerCase()} class="${cls || ''}" id="${el.id || ''}"]`;
            }""",
            [x, y],
        )
    except Exception:
        return None


def _clicar_incluir(pagina, botao_incluir, estado, ja_recliquei):
    """
    Clica em "Incluir" com timeout e mensagem PRÓPRIOS, em vez de deixar
    estourar o timeout padrão do Playwright (30s) sem tratamento nenhum —
    era exatamente isso que fazia aparecer no painel o log interno cru do
    Playwright ("subtree intercepts pointer events - retrying click
    action..." repetido dezenas de vezes), porque essa exceção caía direto
    no `except Exception` genérico de executar_automacao(). Bem mais curto
    que TIMEOUT_CONFIRMACAO_INCLUIR_S de propósito: aqui é só "o clique em
    si não saiu do lugar", não "o servidor demorou pra responder".
    Antes de tentar clicar, fecha/remove qualquer resíduo de dropdown que
    possa estar sobreposto ao botão (ver _fechar_select2_residual).

    Histórico da investigação em 05/09/2026 (com diagnóstico real via
    _elemento_bloqueando_clique, não mais chute):
    1) O elemento que fica por cima do botão é um <div class="row">
       genérico — sobreposição de LAYOUT do modal, não um dropdown do
       Select2.
    2) Tentar `click(force=True)` NÃO resolveu — e o motivo, testado ao
       vivo, é que force=True só pula a CHECAGEM do Playwright de "tem
       algo por cima", mas o clique continua sendo um clique de mouse
       nas coordenadas da tela: se o <div class="row"> está mesmo por
       cima visualmente, é ELE quem recebe o clique de verdade, não o
       botão. Resultado: o Playwright "conseguia clicar" sem erro, mas
       nenhuma linha nova aparecia na tabela (o clique caiu no lugar
       errado, silenciosamente).
    3) Correção: chamar `elemento.click()` via JavaScript
       (page.evaluate), que dispara o handler do próprio elemento
       independente de quem está visualmente sobreposto — não depende
       de coordenada nem de hit-test nenhum. É o mesmo tipo de "clique"
       que o próprio Angular dispara internamente em vários lugares.

    A confirmação de que o clique realmente funcionou continua sendo só
    uma: a linha nova aparecer na tabela do modal (ver
    _clicar_incluir_e_confirmar) — se o clique via JS também não disparar
    nada de verdade, a confirmação falha do mesmo jeito e o erro aparece
    normalmente, então não tem risco de "mascarar" uma falha real.
    """
    _fechar_select2_residual(pagina)
    try:
        botao_incluir.click(timeout=TIMEOUT_CLIQUE_INCLUIR_MS)
        return
    except PlaywrightTimeoutError:
        bloqueando = _elemento_bloqueando_clique(pagina, botao_incluir)

    try:
        botao_incluir.evaluate("(el) => el.click()")
        return
    except Exception:
        pass

    pista_elemento = (
        f" Elemento encontrado bem em cima do botão nesse instante: {bloqueando}."
        if bloqueando
        else ""
    )
    raise ErroLancamento(
        f"O botão 'Incluir'{' (na 2ª tentativa)' if ja_recliquei else ''} "
        f"não aceitou o clique em até {TIMEOUT_CLIQUE_INCLUIR_MS // 1000}s, "
        "nem mesmo disparando o clique via JavaScript direto no elemento "
        f"— algum outro elemento ficou sobreposto a ele na tela.{pista_elemento}"
    )


def _clicar_incluir_e_confirmar(pagina, nome_produto, quantidade, estado):
    linhas_antes = pagina.locator(SEL_TABELA_MODAL_LINHAS).count()

    _checar_parar(estado)
    botao_incluir = pagina.locator(SEL_BOTAO_INCLUIR).first
    _clicar_incluir(pagina, botao_incluir, estado, ja_recliquei=False)

    prazo_final = time.monotonic() + TIMEOUT_CONFIRMACAO_INCLUIR_S
    prazo_reclique = time.monotonic() + TEMPO_ESPERA_RECLIQUE_S
    ja_recliquei = False
    ultima_linha_vista = None

    while time.monotonic() < prazo_final:
        _checar_parar(estado)
        linhas = pagina.locator(SEL_TABELA_MODAL_LINHAS)
        if linhas.count() > linhas_antes:
            texto_ultima = linhas.last.inner_text()
            ultima_linha_vista = texto_ultima
            if _linha_bate_com_item(texto_ultima, quantidade):
                time.sleep(0.5)  # da um respiro pro Angular acomodar o modal antes do proximo item
                return
        elif not ja_recliquei and time.monotonic() > prazo_reclique:
            # Passaram TEMPO_ESPERA_RECLIQUE_S e nenhuma linha nova apareceu:
            # o cenário mais comum aqui é o PRIMEIRO clique ter sido perdido
            # (ex.: o handler do Angular ainda não tinha religado depois do
            # preenchimento da quantidade). Tenta clicar em Incluir mais uma
            # vez antes de desistir de vez.
            ja_recliquei = True
            _clicar_incluir(pagina, botao_incluir, estado, ja_recliquei=True)
        time.sleep(INTERVALO_VERIFICACAO_S)

    valor_qtd_no_erro = "?"
    try:
        valor_qtd_no_erro = pagina.locator(SEL_CAMPO_QUANTIDADE).first.input_value()
    except Exception:
        pass

    if ultima_linha_vista is not None:
        pista_linha = f"Última linha que apareceu na tabela (não bateu com o esperado): {ultima_linha_vista!r}."
    else:
        pista_linha = "Nenhuma linha nova chegou a aparecer na tabela."

    raise ErroLancamento(
        f"Depois de clicar em 'Incluir'{' (2x)' if ja_recliquei else ''}, o "
        f"produto '{nome_produto}' (qtd. {quantidade}) não apareceu "
        f"confirmado na tabela do modal em até {TIMEOUT_CONFIRMACAO_INCLUIR_S}s. "
        f"{pista_linha} Campo de quantidade no momento do erro: '{valor_qtd_no_erro}'."
    )

def _lancar_item(pagina, item, estado):
    codigo = str(item.get("codigo_barras") or "").strip()
    nome = item.get("nome_produto") or item.get("nome") or "PRODUTO"
    quantidade = item.get("quantidade")

    if not codigo:
        raise ErroLancamento(f"Produto '{nome}' não tem código de barras cadastrado.")

    with _cronometro(estado, "TOTAL_ITEM"):
        with _cronometro(estado, "forcar_foco_janela"):
            _forcar_foco_janela_graces(pagina)
        _buscar_e_selecionar_produto(pagina, codigo, estado)
        with _cronometro(estado, "preencher_quantidade"):
            _preencher_quantidade(pagina, quantidade, estado)
        with _cronometro(estado, "incluir_e_confirmar"):
            _clicar_incluir_e_confirmar(pagina, nome, quantidade, estado)


def _botao_salvar(pagina):
    """Locator do botão "Salvar" de verdade: cor + texto exato, não só a
    cor (ver comentário de SEL_BOTAO_SALVAR_INTERNO/GENERICO acima —
    "mat-success" sozinha pega outros botões da página, incluindo um menu
    que fica desabilitado).

    Tenta primeiro escopado ao id do modal de uso interno (#repasse-produto,
    testado em campo). Se não achar nada ali, é sinal de que o modal aberto
    agora é o de lançamento direto na comanda da cliente — nesse caso cai
    para a busca genérica em toda a página, que aplica a mesma segurança na
    mão (texto "Salvar" + visível + habilitado, ver SEL_BOTAO_SALVAR_GENERICO)
    em vez de depender de um id que esse modal não tem."""
    dentro_uso_interno = pagina.locator(SEL_BOTAO_SALVAR_INTERNO).filter(has_text="Salvar")
    if dentro_uso_interno.count() > 0:
        return dentro_uso_interno
    return pagina.locator(SEL_BOTAO_SALVAR_GENERICO).filter(has_text="Salvar")


def _clicar_salvar_modal(pagina, estado):
    """
    Investigado em 05/09/2026: até aqui essa função só clicava em "Salvar"
    e retornava, sem checar nada — diferente de _clicar_incluir_e_confirmar,
    que já tinha espera + reclique. Isso causava dois problemas ao mesmo
    tempo: (1) quando o clique automatizado não "pegava" no Angular (mesmo
    tipo de falha silenciosa já vista no botão "Incluir"), não existia
    reclique nenhum pra compensar; e (2) como nenhuma exceção era lançada
    nesse caso, `executar_automacao` marcava a comanda como "concluida" e
    `estado['erro']` nunca era preenchido — ou seja, a mensagem de erro não
    "sumia" por causa do dashboard.js, ela nunca chegava a ser criada.

    Critério de sucesso confirmado com o usuário: quando "Salvar" funciona
    de verdade, o modal FECHA (o botão desaparece da tela) — vale tanto
    para o modal "Repasse de Produto" (uso interno) quanto para o modal de
    lançamento direto na comanda da cliente, ver _botao_salvar(). Por isso
    a confirmação abaixo é: clicar, esperar o botão sumir (contagem do
    seletor ir a zero), se não sumir em TEMPO_ESPERA_RECLIQUE_S, reclicar
    uma vez; se ainda assim não fechar até TIMEOUT_CONFIRMACAO_INCLUIR_S,
    desiste e lança ErroLancamento (que agora sim populará estado['erro']).
    """
    _checar_parar(estado)
    _forcar_foco_janela_graces(pagina)
    botao_salvar = _botao_salvar(pagina).first
    botao_salvar.wait_for(state="visible", timeout=TIMEOUT_BUSCA_PRODUTO_MS)
    botao_salvar.click()

    prazo_final = time.monotonic() + TIMEOUT_CONFIRMACAO_INCLUIR_S
    prazo_reclique = time.monotonic() + TEMPO_ESPERA_RECLIQUE_S
    ja_recliquei = False

    while time.monotonic() < prazo_final:
        _checar_parar(estado)
        if _botao_salvar(pagina).count() == 0:
            # Botão sumiu da tela -> modal fechou -> Salvar funcionou.
            return
        if not ja_recliquei and time.monotonic() > prazo_reclique:
            # Mesmo padrão do "Incluir": provável clique perdido, tenta
            # de novo antes de desistir.
            ja_recliquei = True
            botao_salvar.click()
        time.sleep(INTERVALO_VERIFICACAO_S)

    raise ErroLancamento(
        f"Depois de clicar em 'Salvar'{' (2x)' if ja_recliquei else ''}, o "
        f"modal não fechou em até "
        f"{TIMEOUT_CONFIRMACAO_INCLUIR_S}s. Ou a Graces travou ao salvar, "
        "ou o clique não surtiu efeito."
    )


def processar_comanda(pagina, comanda, estado):
    """Lança todos os itens de uma comanda (bloco profissional/cliente) e,
    ao final, clica em 'Salvar' uma única vez."""
    for item in comanda.get("itens", []):
        estado["item_atual"] = item.get("nome_produto") or item.get("nome")
        _lancar_item(pagina, item, estado)

    # Investigado em 05/09/2026: NÃO zera item_atual pra None antes do
    # Salvar. O painel (dashboard.js) só mostra a mensagem de erro quando
    # estado.erro.produto tem algum valor — se zerássemos aqui e o Salvar
    # falhasse, o erro seria registrado corretamente no Python mas ficaria
    # mudo na tela (só o ❌ genérico, sem texto), porque 'produto' chegaria
    # vazio no front. Por isso o item_atual segue apontando pra etapa de
    # Salvar até ela terminar (com sucesso ou erro).
    estado["item_atual"] = "Salvar (finalização da comanda)"
    _clicar_salvar_modal(pagina, estado)
    estado["item_atual"] = None


def executar_automacao(estado, porta_debug=None):
    """
    Ponto de entrada chamado pela thread de automação (ver routes/automacao.py).
    Percorre estado['comandas'] processando as que ainda estão com status
    'pendente', atualizando o status de cada uma em tempo real para que o
    painel no dashboard (via polling de /api/automacao/status) reflita o
    progresso. Para imediatamente diante de erro ou pedido de parada,
    marcando exatamente onde parou.
    """
    porta_debug = porta_debug or PORTA_DEBUG_PADRAO

    if not _PLAYWRIGHT_DISPONIVEL:
        estado["erro"] = {
            "mensagem": "O pacote 'playwright' não está instalado. Rode: pip install -r requirements.txt"
        }
        estado["rodando"] = False
        return

    with sync_playwright() as playwright:
        try:
            navegador, pagina = _conectar_pagina_graces(playwright, porta_debug)
        except ErroLancamento as e:
            estado["erro"] = {"mensagem": str(e)}
            estado["rodando"] = False
            return

        try:
            for comanda in estado["comandas"]:
                if comanda.get("status") != "pendente":
                    continue  # já processada em uma chamada anterior desta mesma execução

                _checar_parar(estado)
                comanda["status"] = "em_andamento"
                try:
                    processar_comanda(pagina, comanda, estado)
                    comanda["status"] = "concluida"
                except AutomacaoInterrompida:
                    comanda["status"] = "parada"
                    raise
                except Exception as e:
                    comanda["status"] = "erro"
                    estado["erro"] = {
                        "profissional": comanda.get("profissional"),
                        "cliente": comanda.get("cliente"),
                        "produto": estado.get("item_atual"),
                        "mensagem": str(e),
                    }
                    raise
        except AutomacaoInterrompida:
            pass
        except Exception:
            # Já registrado em estado['erro'] (ou é um erro de conexão,
            # já tratado acima). A automação simplesmente para aqui.
            pass
        finally:
            estado["item_atual"] = None
            estado["rodando"] = False
