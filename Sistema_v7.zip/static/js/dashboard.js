        // =====================================================
        // ALERTAS DO SISTEMA (toasts) — substitui os alert() nativos.
        // Toda mensagem de ERRO/ATENÇÃO aparece em VERMELHO. Os tipos
        // diferenciam a CAUSA (pra facilitar o entendimento), mas nunca a cor:
        //   'aviso' -> falta de informação / validação do formulário (⚠️, vermelho)
        //   'erro'  -> erro real de processamento, servidor ou conexão (❌, vermelho)
        //   'sucesso' -> confirmação de que algo foi salvo/lançado (✅, verde)
        function mostrarAlerta(mensagem, tipo = 'erro') {
            const container = document.getElementById('toastContainer');
            if (!container) { alert(mensagem); return; }

            const config = {
                aviso: { classe: 'toast-aviso', icone: '⚠️', titulo: 'Falta de informação' },
                erro: { classe: 'toast-erro', icone: '❌', titulo: 'Erro' },
                sucesso: { classe: 'toast-sucesso', icone: '✅', titulo: 'Sucesso' }
            }[tipo] || { classe: 'toast-erro', icone: '❌', titulo: 'Erro' };

            const toast = document.createElement('div');
            toast.className = `app-toast ${config.classe}`;
            toast.innerHTML = `
                <span class="toast-icone">${config.icone}</span>
                <div class="toast-corpo">
                    <div class="toast-titulo">${config.titulo}</div>
                    <div class="toast-mensagem"></div>
                </div>
                <button type="button" class="toast-fechar" aria-label="Fechar">✕</button>
            `;
            // Mensagem via textContent (evita problemas de HTML/segurança na string dinâmica)
            toast.querySelector('.toast-mensagem').textContent = String(mensagem || '').replace(/^[❌⚠️🚨✅🚀]\s*/, '');

            const remover = () => {
                toast.classList.add('toast-saindo');
                setTimeout(() => toast.remove(), 200);
            };
            toast.querySelector('.toast-fechar').addEventListener('click', remover);

            container.appendChild(toast);

            const duracao = (tipo === 'sucesso') ? 3200 : 5500;
            setTimeout(remover, duracao);
        }

        // =====================================================
        // ATALHOS DE TECLADO
        // F1 a F9 abrem os principais painéis/modais do sistema.
        // ESC fecha o modal/painel que estiver aberto no momento
        // (do mais "por cima" pro mais "de baixo", um de cada vez).
        // =====================================================
        const ATALHOS_F_TECLAS = {
            'F1': () => abrirModalHistorico(),
            'F2': () => abrirModalGerenciamento(),
            'F3': () => abrirModalControleEstoque(),
            'F4': () => abrirModalAlertaEstoque(),
            'F6': () => abrirModalNovoProduto(),
            'F7': () => abrirModalNovoProfissional(setorAtual),
            'F8': () => abrirModalMediaSaida(),
            'F9': () => abrirModalResumoDiario()
        };

        // Ordem de prioridade pra fechar com ESC: do painel mais "de cima"
        // (submodais/detalhes) pro mais "de baixo". Fecha só um por vez.
        const PAINEIS_ESC = [
            { id: 'modalAutomacao', fechar: () => fecharModal('modalAutomacao') },
            { id: 'painelLoteGlobal', fechar: () => fecharPainelLoteGlobal() },
            { id: 'submodalEdicao', fechar: () => fecharSubmodalEdicao() },
            { id: 'modalEstoqueAtual', fechar: () => fecharModal('modalEstoqueAtual') },
            { id: 'modalDetalhePessoa', fechar: () => fecharModal('modalDetalhePessoa') },
            { id: 'modalResumoDiario', fechar: () => fecharModal('modalResumoDiario') },
            { id: 'modalDetalheProduto', fechar: () => fecharModal('modalDetalheProduto') },
            { id: 'modalSaidasProduto', fechar: () => fecharModal('modalSaidasProduto') },
            { id: 'submodalMenuProduto', fechar: () => fecharModal('submodalMenuProduto') },
            { id: 'submodalPDF', fechar: () => fecharModal('submodalPDF') },
            { id: 'modalControleEstoque', fechar: () => fecharModal('modalControleEstoque') },
            { id: 'modalMediaSaida', fechar: () => fecharModal('modalMediaSaida') },
            { id: 'modalNotasLote', fechar: () => fecharModalNotasLote() },
            { id: 'modalGerenciamento', fechar: () => fecharModalGerenciamento() },
            { id: 'modalHistorico', fechar: () => fecharModal('modalHistorico') },
            { id: 'modalNovoProfissional', fechar: () => fecharModal('modalNovoProfissional') },
            { id: 'modalAlertaEstoque', fechar: () => fecharModal('modalAlertaEstoque') },
            { id: 'modalNovoProduto', fechar: () => fecharModal('modalNovoProduto') }
        ];

        function elementoVisivel(id) {
            const el = document.getElementById(id);
            return !!el && !el.classList.contains('hidden');
        }

        document.addEventListener('keydown', function (e) {
            // ESC fecha o painel/modal mais "de cima" que estiver aberto no momento.
            if (e.key === 'Escape') {
                const painel = PAINEIS_ESC.find(p => elementoVisivel(p.id));
                if (painel) {
                    e.preventDefault();
                    painel.fechar();
                }
                return;
            }

            // F1–F9 abrem os painéis/modais principais (ignora se o navegador
            // já estiver reservando a tecla, ex.: nenhuma ação encontrada).
            const acao = ATALHOS_F_TECLAS[e.key];
            if (acao) {
                e.preventDefault();
                acao();
            }
        });

        let listaItensParaSaida = [];
        let produtoSelecionadoAtual = null;
        let setorAtual = 'manicure';
        let modoAbaAtual = 'cronologica';
        let dataSelecionadaGlobal = new Date().toISOString().split('T')[0];
        // Guarda de onde o modal "Cadastrar Novo Produto" foi aberto: quando é null,
        // é o fluxo normal (lançamento de saída); quando vem do fluxo de vincular
        // itens importados, guarda o índice da semana pra já selecionar o produto
        // recém-criado automaticamente depois de salvar.
        let _origemModalNovoProduto = null;
        // Mesma lógica, mas para o modal de EDITAR um produto já existente: quando
        // aberto a partir do fluxo de vincular, guarda o índice da semana pra
        // atualizar a seleção com os dados (possivelmente corrigidos) ao salvar.
        let _origemModalEdicao = null;

        const PRODUTOS_CHAVE = {
            toalha_mao: 'TOALHA DE MÃO',
            toalha_pe: 'TOALHA DE PÉ',
            lixa_unha: 'LIXA DE UNHA',
            lixa_pe: 'LIXA DE PÉ',
            luva: 'LUVA'
        };

        // Nome fixo (sempre igual) usado para os itens marcados como "🧷 Uso interno" na
        // tabela de itens. Por ser sempre o MESMO texto, todos os lançamentos de uso
        // interno de uma mesma profissional caem sempre no mesmo bloco/comanda (mesma
        // chave prof+setor+cliente), em vez de virarem um lançamento avulso cada vez — e
        // nunca se mistura com a comanda real de nenhuma cliente. Ver confirmarSaida().
        const CLIENTE_USO_INTERNO = 'USO INTERNO (SALÃO)';

        // Define se um item deve entrar marcado como "🧷 Uso interno" ou "👤 Da cliente"
        // por padrão, de acordo com o setor e o nome do produto:
        //  - Cabeleireiro: tudo é "Da cliente", só a LUVA é uso interno.
        //  - Manicure: tudo é uso interno, só o HOMEOPAST é "Da cliente".
        // O selo em cada item na tabela continua editável manualmente para os casos fora
        // da regra (ver toggleItemUsoInterno).
        function usoInternoPadrao(nomeProduto, setor) {
            const nome = String(nomeProduto || '').toUpperCase();
            if (setor === 'cabeleireiro') {
                return nome.includes('LUVA');
            }
            return !nome.includes('HOMEOPAST');
        }
        
        // Função chamada pelo botão para aprovar o bloco de lançamentos pendentes
        async function aprovarBlocoProfissional(idsArray) {
            if (!idsArray || idsArray.length === 0) return;

            try {
                const res = await fetch('/api/aprovar_bloco_profissional', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ ids: idsArray })
                });
                
                const resposta = await res.json();

                if (resposta.sucesso) {
                    if (typeof carregarSaidasPendentes === 'function') {
                        carregarSaidasPendentes();
                    } else if (typeof carregarHistorico === 'function') {
                        carregarHistorico();
                    }
                }
            } catch (e) {
                console.error(e);
            }
        }

        // Função chamada pelo botão (✕) para excluir um bloco de lançamentos pendentes.
        // Estava faltando esta função — o botão existia no HTML mas não fazia nada.
        async function excluirBlocoProfissional(idsArray) {
            if (!idsArray || idsArray.length === 0) return;

            if (!confirm('Tem certeza que deseja excluir este(s) lançamento(s)? O estoque retirado será devolvido.')) {
                return;
            }

            try {
                const res = await fetch('/api/excluir_bloco_profissional', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ ids: idsArray })
                });

                const resposta = await res.json();

                if (resposta.sucesso) {
                    if (typeof carregarSaidasPendentes === 'function') {
                        carregarSaidasPendentes();
                    } else if (typeof carregarHistorico === 'function') {
                        carregarHistorico();
                    }
                } else {
                    mostrarAlerta(resposta.mensagem || 'Não foi possível excluir o lançamento.', 'erro');
                }
            } catch (e) {
                console.error(e);
                mostrarAlerta('Erro de conexão ao excluir o lançamento.', 'erro');
            }
        }

        // =====================================================
        // AUTOMAÇÃO GRACES (lançamento automático via navegador)
        // Pré-condição, sempre manual: o modal "Repasse de Produto" já está
        // aberto na comanda certa da Graces. A automação só digita/clica
        // dentro dele. Ver services/automacao_graces.py.
        // =====================================================
        let _intervaloPollingAutomacao = null;

        async function lancarComandaNaGraces(botao, profissional, cliente, setor, itens) {
            if (!itens || itens.length === 0) {
                mostrarAlerta('Esta comanda não tem itens para lançar.', 'aviso');
                return;
            }
            if (!confirm(`Confirma que o modal "Repasse de Produto" já está aberto na comanda de ${cliente || profissional} na Graces?\n\nA automação vai digitar e clicar dentro dele.`)) {
                return;
            }

            try {
                const res = await fetch('/api/automacao/iniciar', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ profissional, cliente, setor, itens })
                });
                const resposta = await res.json();

                if (!resposta.sucesso) {
                    mostrarAlerta(resposta.mensagem || 'Não foi possível iniciar o lançamento.', 'erro');
                    return;
                }

                abrirModal('modalAutomacao');
                renderPainelAutomacao(resposta.estado);
                iniciarPollingAutomacao();
            } catch (e) {
                console.error(e);
                mostrarAlerta('Erro de conexão ao iniciar o lançamento automático.', 'erro');
            }
        }

        function iniciarPollingAutomacao() {
            if (_intervaloPollingAutomacao) return;
            _intervaloPollingAutomacao = setInterval(async () => {
                try {
                    const res = await fetch('/api/automacao/status');
                    const resposta = await res.json();
                    if (resposta.sucesso) {
                        renderPainelAutomacao(resposta.estado);
                        if (!resposta.estado.rodando) {
                            clearInterval(_intervaloPollingAutomacao);
                            _intervaloPollingAutomacao = null;
                            // Uma comanda pode ter sido concluída — atualiza a lista de pendentes
                            if (typeof carregarHistorico === 'function') carregarHistorico();
                        }
                    }
                } catch (e) {
                    console.error(e);
                }
            }, 1200);
        }

        async function pararAutomacaoGraces() {
            try {
                await fetch('/api/automacao/parar', { method: 'POST' });
            } catch (e) {
                console.error(e);
            }
        }

        // Escapa texto antes de jogar em innerHTML — investigado em 05/09/2026:
        // o painel de automação montava `detalheErro`/`detalheAndamento` por
        // concatenação direta de string (sem escapar), e uma mensagem de erro
        // contendo "<...>" (ex.: um diagnóstico técnico tipo "<button
        // class=...>") era interpretada pelo navegador como uma tag HTML de
        // verdade e simplesmente sumia da tela, sem nenhum aviso. Usada em
        // qualquer valor dinâmico (mensagem de erro, nome de profissional/
        // cliente/setor, item atual) que entra em template literal de HTML.
        function escapeHtml(valor) {
            const div = document.createElement('div');
            div.textContent = String(valor ?? '');
            return div.innerHTML;
        }

        const ICONES_STATUS_AUTOMACAO = {
            pendente: '⏳',
            em_andamento: '⏳',
            concluida: '✅',
            erro: '❌',
            parada: '⏹️'
        };

        function renderPainelAutomacao(estado) {
            const btnParar = document.getElementById('btnPararAutomacao');
            if (btnParar) btnParar.disabled = !estado.rodando;

            const lista = document.getElementById('listaAutomacao');
            if (!lista) return;

            if (!estado.comandas || estado.comandas.length === 0) {
                lista.innerHTML = `<p class="text-center text-slate-400 italic py-6">Nenhum lançamento nesta sessão ainda.</p>`;
                return;
            }

            lista.innerHTML = estado.comandas.slice().reverse().map(c => {
                const icone = ICONES_STATUS_AUTOMACAO[c.status] || '•';
                const detalheAndamento = (c.status === 'em_andamento' && estado.item_atual)
                    ? `<p class="text-[11px] text-indigo-500 mt-1">Lançando: ${escapeHtml(String(estado.item_atual).toUpperCase())}</p>`
                    : '';
                const detalheErro = (c.status === 'erro' && estado.erro && estado.erro.produto)
                    ? `<p class="text-[11px] text-rose-600 mt-1">Parou em: ${escapeHtml(String(estado.erro.produto).toUpperCase())} — ${escapeHtml(estado.erro.mensagem || '')}</p>`
                    : '';
                return `
                    <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex items-start gap-2">
                        <span class="text-lg leading-none">${icone}</span>
                        <div class="min-w-0 flex-1">
                            <p class="text-xs font-black text-slate-800 uppercase truncate">${escapeHtml(c.profissional || '')} ${c.cliente ? '— ' + escapeHtml(c.cliente) : ''}</p>
                            <p class="text-[11px] text-slate-400 font-bold uppercase">${escapeHtml(c.setor || '')}</p>
                            ${detalheAndamento}
                            ${detalheErro}
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Marca/desmarca todos os checkboxes de produto de um bloco (usado pelo checkbox mestre "Selecionar Todos")
        function toggleTodosItensBloco(idxBloco) {
            const master = document.getElementById(`masterBloco_${idxBloco}`);
            const checkboxes = document.querySelectorAll(`.chk-item-bloco-${idxBloco}`);
            checkboxes.forEach(cb => { cb.checked = master.checked; });
        }

        // Mantém o checkbox mestre em sincronia quando o usuário marca/desmarca itens individualmente
        function atualizarMasterBloco(idxBloco) {
            const master = document.getElementById(`masterBloco_${idxBloco}`);
            if (!master) return;
            const checkboxes = document.querySelectorAll(`.chk-item-bloco-${idxBloco}`);
            const marcados = Array.from(checkboxes).filter(cb => cb.checked).length;
            master.checked = checkboxes.length > 0 && marcados === checkboxes.length;
            master.indeterminate = marcados > 0 && marcados < checkboxes.length;
        }

        // Reúne os produtos marcados (com seus respectivos lançamentos de origem) e confirma
        // apenas esses itens, mesmo que estejam misturados com produtos não marcados no mesmo lançamento.
        // Usa o mesmo botão de confirmação de saída que já existia na tela.
        function confirmarSelecaoBloco(idxBloco, todosIdsDoBloco) {
            const checkboxes = document.querySelectorAll(`.chk-item-bloco-${idxBloco}`);

            if (checkboxes.length === 0) {
                // Fallback: nenhum checkbox de item encontrado, confirma o bloco inteiro como antes
                aprovarBlocoProfissional(todosIdsDoBloco);
                return;
            }

            const marcados = Array.from(checkboxes).filter(cb => cb.checked);

            if (marcados.length === 0) {
                mostrarAlerta('Selecione ao menos um produto para confirmar a saída.', 'aviso');
                return;
            }

            // Se tudo está marcado, mantém o fluxo original (confirma o bloco inteiro)
            if (marcados.length === checkboxes.length) {
                aprovarBlocoProfissional(todosIdsDoBloco);
                return;
            }

            // Seleção parcial: monta a lista de {id_lancamento, codigo_barras, nome_produto}
            // para que o backend confirme somente esses produtos, fracionando o lançamento se preciso.
            const selecoes = [];
            marcados.forEach(cb => {
                let ids = [];
                try { ids = JSON.parse(cb.dataset.ids || '[]'); } catch (e) { ids = []; }
                const cod = cb.dataset.cod || '';
                const nome = cb.dataset.nome || '';
                ids.forEach(id => {
                    selecoes.push({ id_lancamento: id, codigo_barras: cod, nome_produto: nome });
                });
            });

            confirmarProdutosSelecionados(selecoes);
        }

        async function confirmarProdutosSelecionados(selecoes) {
            if (!selecoes || selecoes.length === 0) return;

            try {
                const res = await fetch('/api/confirmar_itens_selecionados', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ selecoes: selecoes })
                });

                const resposta = await res.json();

                if (resposta.sucesso) {
                    if (typeof carregarSaidasPendentes === 'function') {
                        carregarSaidasPendentes();
                    } else if (typeof carregarHistorico === 'function') {
                        carregarHistorico();
                    }
                } else {
                    mostrarAlerta(resposta.mensagem || 'Não foi possível confirmar os produtos selecionados.', 'erro');
                }
            } catch (e) {
                console.error(e);
            }
        }

        async function adicionarComposicaoKit(tipoKit) {
            let itensParaAdicionar = [];
            if (tipoKit === 'kit_mao') {
                itensParaAdicionar = [{ nome: PRODUTOS_CHAVE.toalha_mao, qtd: 1 }, { nome: PRODUTOS_CHAVE.lixa_unha, qtd: 1 }];
            } else if (tipoKit === 'kit_pe') {
                itensParaAdicionar = [{ nome: PRODUTOS_CHAVE.toalha_pe, qtd: 1 }, { nome: PRODUTOS_CHAVE.lixa_unha, qtd: 1 }, { nome: PRODUTOS_CHAVE.lixa_pe, qtd: 1 }];
            } else if (tipoKit === 'meio_kit') {
                itensParaAdicionar = [{ nome: PRODUTOS_CHAVE.toalha_pe, qtd: 1 }, { nome: PRODUTOS_CHAVE.lixa_unha, qtd: 1 }];
            } else if (tipoKit === 'kit_podologia') {
                itensParaAdicionar = [{ nome: PRODUTOS_CHAVE.toalha_pe, qtd: 2 }];
            } else if (tipoKit === 'kit_sem_lixa') {
                itensParaAdicionar = [{ nome: PRODUTOS_CHAVE.toalha_mao, qtd: 1 }];
            } else if (tipoKit === 'kit_sem_lixa_pe') {
                itensParaAdicionar = [{ nome: PRODUTOS_CHAVE.toalha_pe, qtd: 1 }];
            } else if (tipoKit === 'kit_casadinho') {
                itensParaAdicionar = [{ nome: PRODUTOS_CHAVE.toalha_mao, qtd: 1 }, { nome: PRODUTOS_CHAVE.toalha_pe, qtd: 1 }, { nome: PRODUTOS_CHAVE.lixa_unha, qtd: 1 }];
            } else if (tipoKit === 'lixa_pe') {
                itensParaAdicionar = [{ nome: PRODUTOS_CHAVE.lixa_pe, qtd: 1 }];
            }

            for (const itemCombo of itensParaAdicionar) {
                await buscarEInserirItemItemDoKit(itemCombo.nome, itemCombo.qtd);
            }
        }

        function adicionarLuvaRapida(tamanho) {
            // Luva é sempre uso interno, nos dois setores.
            buscarEInserirItemItemDoKit(`${PRODUTOS_CHAVE.luva} ${tamanho}`, 2, true);
        }

        // =====================================================
        // LUVA PADRÃO POR PROFISSIONAL
        // Quando a profissional selecionada tem um tamanho de luva padrão
        // cadastrado, o painel de luva rápida vira um botão único (já com o
        // tamanho dela). Um botão "↺" ao lado deixa ver todos os tamanhos de
        // novo, caso ela precise de outra luva naquele dia.
        // =====================================================
        let _luvaPadraoAtual = null;

        function aplicarLuvaPadraoProfissional(tamanhoPadrao) {
            tamanhoPadrao = (tamanhoPadrao || '').toString().trim().toUpperCase() || null;
            _luvaPadraoAtual = tamanhoPadrao;

            if (!tamanhoPadrao) {
                mostrarTodasOpcoesLuva();
                return;
            }

            const label = document.getElementById('luvaPadraoColapsadaTamanho');
            if (label) label.textContent = tamanhoPadrao;

            const grupoTodos = document.getElementById('luvaTodasOpcoes');
            const grupoColapsado = document.getElementById('luvaPadraoColapsada');
            if (grupoTodos) grupoTodos.classList.add('hidden');
            if (grupoColapsado) grupoColapsado.classList.remove('hidden');
        }

        // Lança a luva no tamanho padrão da profissional atualmente selecionada
        function adicionarLuvaRapidaPadrao() {
            if (_luvaPadraoAtual) adicionarLuvaRapida(_luvaPadraoAtual);
        }

        // Volta a mostrar todos os tamanhos de luva (PP/P/M/G) — usado quando a
        // profissional não tem padrão, ou quando ela clica em "↺" pra pegar
        // outro tamanho diferente do de costume.
        function mostrarTodasOpcoesLuva() {
            const grupoTodos = document.getElementById('luvaTodasOpcoes');
            const grupoColapsado = document.getElementById('luvaPadraoColapsada');
            if (grupoTodos) grupoTodos.classList.remove('hidden');
            if (grupoColapsado) grupoColapsado.classList.add('hidden');
        }

        // usoInternoForcado: passe true/false para forçar (ex: luva sempre true); deixe
        // undefined para usar a regra padrão do setor atual (ver usoInternoPadrao).
        function buscarEInserirItemItemDoKit(nomeProduto, quantidade, usoInternoForcado) {
            return fetch(`/api/buscar_produto?termo=${encodeURIComponent(nomeProduto)}`)
                .then(r => r.json())
                .then(dados => {
                    const usoInterno = (typeof usoInternoForcado === 'boolean') ? usoInternoForcado : usoInternoPadrao(nomeProduto, setorAtual);
                    const servicoDoItem = setorAtual === 'cabeleireiro' ? servicoAtualSelecionado : null;
                    if (dados.sucesso && dados.produtos.length > 0) {
                        const prodReal = dados.produtos[0];
                        const itemExistente = listaItensParaSaida.find(item =>
                            item.codigo_barras === prodReal.codigo_barras &&
                            item.usoInterno === usoInterno &&
                            (item.servico || null) === servicoDoItem
                        );
                        if (itemExistente) {
                            itemExistente.quantidade += quantidade;
                        } else {
                            listaItensParaSaida.push({
                                codigo_barras: prodReal.codigo_barras,
                                nome: prodReal.nome,
                                tipo_medida: prodReal.tipo_medida,
                                quantidade: quantidade,
                                usoInterno: usoInterno,
                                servico: servicoDoItem
                            });
                        }
                    } else {
                        listaItensParaSaida.push({
                            codigo_barras: "7895461261",
                            nome: nomeProduto,
                            tipo_medida: "un",
                            quantidade: quantidade,
                            usoInterno: usoInterno,
                            servico: servicoDoItem
                        });
                    }
                    renderizarTabela();
                });
        }

        async function escutarBuscaProduto(termo) {
            const lista = document.getElementById('listaSugestoesProduto');
            const feedback = document.getElementById('feedbackProduto');
            
            if (!termo.trim() || termo.trim().length < 2) {
                lista.innerHTML = "";
                lista.classList.add('hidden');
                return;
            }
            
            try {
                const resposta = await fetch(`/api/buscar_produto?termo=${encodeURIComponent(termo)}`);
                const dados = await resposta.json();
                lista.innerHTML = "";
                
                if (!dados.sucesso || !dados.produtos || dados.produtos.length === 0) {
                    lista.classList.add('hidden');
                    feedback.innerText = "Nenhum produto encontrado. Clique em + para cadastrar.";
                    produtoSelecionadoAtual = null;
                } else {
                    lista.classList.remove('hidden');
                    feedback.innerText = "Escolha um produto abaixo:";
                    dados.produtos.forEach(p => {
                        const item = document.createElement('button');
                        item.type = "button";
                        item.className = "w-full text-left p-2.5 hover:bg-indigo-600 hover:text-white text-xs font-bold block border-b last:border-0";
                        item.innerText = `${p.nome} (COD: ${p.codigo_barras})`;
                        item.onclick = () => selecionarProduto(p);
                        lista.appendChild(item);
                    });
                }
            } catch (erro) { console.error(erro); }
        }

        function selecionarProduto(prod) {
            produtoSelecionadoAtual = prod;
            document.getElementById('campoBuscaProduto').value = prod.nome;
            document.getElementById('listaSugestoesProduto').classList.add('hidden');
            
            document.getElementById('feedbackProduto').innerText = `✅ Selecionado: ${prod.nome} (COD: ${prod.codigo_barras})`;
            document.getElementById('feedbackProduto').className = "text-xs mt-1 text-emerald-600 font-bold";
            document.getElementById('sufixoMedida').innerText = (prod.tipo_medida || 'un').toLowerCase();

            const btnEstoque = document.getElementById('btnInformarEstoqueAtual');
            if (btnEstoque) {
                btnEstoque.disabled = false;
                btnEstoque.title = "Informar estoque atual deste produto";
                btnEstoque.className = "bg-slate-800 text-white font-bold px-3 py-2 rounded-xl hover:bg-slate-900 text-base shadow transition-all";
            }
        }

        async function escutarBuscaProfissional(termo, funcao) {
            const idLista = funcao === 'manicure' ? 'listaSugestoesManicure' : 'listaSugestoesCabeleireiro';
            const lista = document.getElementById(idLista);

            // Qualquer edição manual no nome invalida a luva padrão aplicada antes
            // (ela só volta a valer se a profissional for selecionada de novo na lista).
            mostrarTodasOpcoesLuva();
            
            try {
                const resposta = await fetch(`/api/buscar_profissional?funcao=${funcao}&termo=${encodeURIComponent(termo)}`);
                const dados = await resposta.json();
                lista.innerHTML = "";
                
                if (dados.sucesso && dados.profissionais.length > 0) {
                    lista.classList.remove('hidden');
                    dados.profissionais.forEach(p => {
                        const item = document.createElement('button');
                        item.type = "button";
                        item.className = "w-full text-left p-2 hover:bg-indigo-600 hover:text-white text-xs font-bold block border-b";
                        item.innerText = p.nome;
                        item.onclick = () => {
                            const campoId = funcao === 'manicure' ? 'campoBuscaManicure' : 'campoBuscaCabeleireiro';
                            document.getElementById(campoId).value = p.nome;
                            lista.classList.add('hidden');
                            aplicarLuvaPadraoProfissional(p.luva_padrao);
                        };
                        lista.appendChild(item);
                    });
                } else {
                    lista.classList.add('hidden');
                }
            } catch (err) { console.error(err); }
        }

        // Autocomplete do campo "Cliente" no setor Cabeleireiro: ao digitar, sugere
        // clientes já cadastradas (que já tiveram algum lançamento antes) e, ao
        // escolher uma, preenche automaticamente também a profissional original
        // (a primeira que atendeu aquela cliente), sem precisar digitar de novo.
        async function escutarBuscaCliente(termo) {
            const lista = document.getElementById('listaSugestoesClienteCabelo');
            if (!termo || termo.trim().length === 0) {
                lista.classList.add('hidden');
                lista.innerHTML = '';
                return;
            }

            try {
                const resposta = await fetch(`/api/buscar_cliente?setor=cabeleireiro&termo=${encodeURIComponent(termo)}`);
                const dados = await resposta.json();
                lista.innerHTML = "";

                if (dados.sucesso && dados.clientes.length > 0) {
                    lista.classList.remove('hidden');
                    dados.clientes.forEach(c => {
                        const item = document.createElement('button');
                        item.type = "button";
                        item.className = "w-full text-left p-2 hover:bg-indigo-600 hover:text-white text-xs font-bold block border-b";
                        item.innerHTML = `${c.cliente}<span class="block font-normal opacity-70 text-[10px]">Cabeleireira: ${c.profissional_original}</span>`;
                        item.onclick = () => {
                            document.getElementById('campoClienteCabelo').value = c.cliente;
                            document.getElementById('campoBuscaCabeleireiro').value = c.profissional_original;
                            lista.classList.add('hidden');
                        };
                        lista.appendChild(item);
                    });
                } else {
                    lista.classList.add('hidden');
                }
            } catch (err) { console.error(err); }
        }

        function adicionarItemNaLista() {
            if (!produtoSelecionadoAtual) { mostrarAlerta("Selecione um produto primeiro!", 'aviso'); return; }
            const inputQtd = document.getElementById('campoQuantidade');
            const quantidade = parseFloat(inputQtd.value);
            if (isNaN(quantidade) || quantidade <= 0) { mostrarAlerta("Insira uma quantidade válida.", 'aviso'); return; }

            const usoInternoDefault = usoInternoPadrao(produtoSelecionadoAtual.nome, setorAtual);
            // O serviço só se aplica ao Cabeleireiro (ver blocoServicoCabelo); itens de
            // serviços diferentes NUNCA se juntam num só, mesmo sendo o mesmo produto.
            const servicoDoItem = setorAtual === 'cabeleireiro' ? servicoAtualSelecionado : null;
            const itemExistente = listaItensParaSaida.find(item =>
                item.codigo_barras === produtoSelecionadoAtual.codigo_barras &&
                item.usoInterno === usoInternoDefault &&
                (item.servico || null) === servicoDoItem
            );
            if (itemExistente) {
                itemExistente.quantidade += quantidade;
            } else {
                listaItensParaSaida.push({
                    codigo_barras: produtoSelecionadoAtual.codigo_barras,
                    nome: produtoSelecionadoAtual.nome,
                    tipo_medida: produtoSelecionadoAtual.tipo_medida || "un",
                    quantidade: quantidade,
                    usoInterno: usoInternoDefault,
                    servico: servicoDoItem
                });
            }
            limparCamposBuscaProduto();
            renderizarTabela();
        }

        function limparCamposBuscaProduto() {
            produtoSelecionadoAtual = null;
            document.getElementById('campoBuscaProduto').value = "";
            document.getElementById('campoQuantidade').value = "1";
            document.getElementById('sufixoMedida').innerText = "un";
            document.getElementById('feedbackProduto').innerText = "Nenhum produto selecionado.";
            document.getElementById('feedbackProduto').className = "text-xs mt-1 text-slate-400 italic";

            const btnEstoque = document.getElementById('btnInformarEstoqueAtual');
            if (btnEstoque) {
                btnEstoque.disabled = true;
                btnEstoque.title = "Selecione um produto para informar o estoque atual";
                btnEstoque.className = "bg-slate-200 text-slate-400 font-bold px-3 py-2 rounded-xl text-base shadow cursor-not-allowed transition-all";
            }
        }

        // Abre o modal para informar o estoque atual de um produto. Usado tanto pelo
        // fluxo de saída (produto já selecionado na tela) quanto pelo Controle de
        // Estoque (produto passado como argumento). Não interfere na quantidade
        // sendo lançada de saída no momento.
        function abrirModalEstoqueAtual(produto) {
            const alvo = produto || produtoSelecionadoAtual;
            if (!alvo) {
                mostrarAlerta("Selecione um produto primeiro!", 'aviso');
                return;
            }
            produtoEmEdicaoEstoque = alvo;
            document.getElementById('estoqueAtualNomeProduto').innerText =
                `${alvo.nome} (COD: ${alvo.codigo_barras})`;
            const valorAtual = alvo.estoque_atual;
            document.getElementById('campoEstoqueAtualValor').value =
                (valorAtual === undefined || valorAtual === null) ? '' : valorAtual;
            abrirModal('modalEstoqueAtual');
        }

        async function salvarEstoqueAtual() {
            if (!produtoEmEdicaoEstoque) { return; }
            const valor = parseFloat(document.getElementById('campoEstoqueAtualValor').value);
            if (isNaN(valor) || valor < 0) {
                mostrarAlerta("Informe um valor de estoque válido.", 'aviso');
                return;
            }

            try {
                const res = await fetch('/api/informar_estoque_atual', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        codigo_barras: produtoEmEdicaoEstoque.codigo_barras,
                        estoque_atual: valor
                    })
                });
                const resposta = await res.json();
                if (resposta.sucesso) {
                    produtoEmEdicaoEstoque.estoque_atual = valor;
                    fecharModal('modalEstoqueAtual');
                    if (typeof carregarAlertaEstoque === 'function') carregarAlertaEstoque();
                    // Se o produto também existir na lista do Controle de Estoque, atualiza ali sem refazer o fetch inteiro
                    atualizarEstoqueNaListaControle(produtoEmEdicaoEstoque.codigo_barras, valor);
                } else {
                    mostrarAlerta("❌ " + (resposta.mensagem || 'Não foi possível salvar o estoque.'), 'erro');
                }
            } catch (e) {
                console.error(e);
                mostrarAlerta("Erro de conexão ao salvar o estoque.", 'erro');
            }
        }

        function alterarQuantidade(index, valorDelta) {
            // Altera a quantidade com base no botão clicado (+1 ou -1)
            listaItensParaSaida[index].quantidade += valorDelta;

            // Se a quantidade zerar ou ficar negativa, remove o item automaticamente da lista
            if (listaItensParaSaida[index].quantidade <= 0) {
                listaItensParaSaida.splice(index, 1);
            }

            // Atualiza a tabela na tela
            renderizarTabela();
        }

        function renderizarTabela() {
            const corpoTabela = document.getElementById('corpoTabelaItens');
            if (!corpoTabela) return;
            corpoTabela.innerHTML = ""; 

            if (listaItensParaSaida.length === 0) {
                corpoTabela.innerHTML = `<tr><td colspan="4" class="p-4 text-center text-slate-400 italic">Nenhum item adicionado à lista.</td></tr>`;
                atualizarResumoSoma();
                return;
            }

            listaItensParaSaida.forEach((item, index) => {
                const tr = document.createElement('tr');
                tr.className = "hover:bg-slate-50 border-b last:border-0";
                const marcado = item.incluirNaSoma !== false;
                const usoInterno = item.usoInterno === true;

                tr.innerHTML = `
                    <td class="p-3 text-center">
                        <input type="checkbox" class="chk-soma-item w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer" ${marcado ? 'checked' : ''} onchange="toggleItemSoma(${index}, this.checked)" title="Incluir na soma">
                    </td>
                    <td class="p-3 font-bold text-slate-800">
                        • ${item.nome.toUpperCase()} 
                        ${item.servico ? `<span class="ml-1 text-[10px] font-black px-2 py-0.5 rounded-full bg-violet-100 text-violet-700 border border-violet-200">✂️ ${item.servico}</span>` : ''}
                        <button type="button" onclick="toggleItemUsoInterno(${index})"
                            class="ml-2 text-[10px] font-black px-2 py-0.5 rounded-full border transition-all ${usoInterno ? 'bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-200' : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'}"
                            title="Clique para alternar: item vai para a comanda da cliente ou para o uso interno do salão (sem cliente)">
                            ${usoInterno ? '🧷 Uso interno' : '👤 Da cliente'}
                        </button>
                    </td>
                    <td class="p-3 text-center font-black text-indigo-700">${item.quantidade}${(item.tipo_medida || 'un').toLowerCase()}</td>
                    <td class="p-3 text-center">
                        <div class="inline-flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
                            <button type="button" onclick="alterarQuantidade(${index}, -1)" class="w-6 h-6 bg-white hover:bg-rose-100 text-slate-700 hover:text-rose-600 rounded font-bold text-xs flex items-center justify-center transition-all shadow-sm" title="Diminuir 1">-</button>
                            
                            <button type="button" onclick="alterarQuantidade(${index}, 1)" class="w-6 h-6 bg-white hover:bg-emerald-100 text-slate-700 hover:text-emerald-600 rounded font-bold text-xs flex items-center justify-center transition-all shadow-sm" title="Adicionar 1">+</button>
                        </div>
                        
                        <button type="button" onclick="removerItemDaLista(${index})" class="text-rose-600 hover:text-rose-800 font-black text-base px-2 ml-1" title="Remover item">✕</button>
                    </td>
                `;
                corpoTabela.appendChild(tr);
            });

            atualizarResumoSoma();
        }

        // Alterna se um item específico está marcado como "uso interno" (não vai para a
        // comanda da cliente digitada; vai para o bloco fixo "USO INTERNO (SALÃO)" que
        // acumula com os demais lançamentos de uso interno do dia). Permite misturar, num
        // único lançamento, itens da cliente com itens de uso interno — ver confirmarSaida().
        function toggleItemUsoInterno(index) {
            if (!listaItensParaSaida[index]) return;
            listaItensParaSaida[index].usoInterno = !listaItensParaSaida[index].usoInterno;
            renderizarTabela();
        }

        function removerItemDaLista(index) {
            listaItensParaSaida.splice(index, 1); 
            renderizarTabela(); 
        }

        // Marca/desmarca se um item específico entra na soma seletiva exibida abaixo da tabela
        function toggleItemSoma(index, marcado) {
            if (!listaItensParaSaida[index]) return;
            listaItensParaSaida[index].incluirNaSoma = marcado;
            atualizarMasterCheckSoma();
            atualizarResumoSoma();
        }

        // Marca/desmarca todos os itens de uma vez (checkbox mestre no cabeçalho da tabela)
        function toggleTodosItensSoma(marcado) {
            listaItensParaSaida.forEach(item => { item.incluirNaSoma = marcado; });
            renderizarTabela();
        }

        // Mantém o checkbox mestre do cabeçalho em sincronia com a seleção individual
        function atualizarMasterCheckSoma() {
            const master = document.getElementById('masterCheckSoma');
            if (!master) return;
            const total = listaItensParaSaida.length;
            const marcados = listaItensParaSaida.filter(i => i.incluirNaSoma !== false).length;
            master.checked = total > 0 && marcados === total;
            master.indeterminate = marcados > 0 && marcados < total;
        }

        // Formata um número sem casas decimais desnecessárias (ex.: 20 em vez de 20.0)
        function formatarNumeroSoma(valor) {
            const arredondado = Math.round(valor * 100) / 100;
            return Number.isInteger(arredondado) ? String(arredondado) : String(arredondado).replace('.', ',');
        }

        // Calcula e exibe a soma das quantidades dos itens marcados, agrupada por unidade de medida
        // (não faz sentido somar gramas com mililitros, por exemplo)
        function atualizarResumoSoma() {
            const resumoEl = document.getElementById('resumoSomaSelecionada');
            if (!resumoEl) return;

            atualizarMasterCheckSoma();

            const somaPorUnidade = {};
            listaItensParaSaida.forEach(item => {
                if (item.incluirNaSoma === false) return;
                const unidade = (item.tipo_medida || 'un').toLowerCase();
                const qtd = parseFloat(item.quantidade) || 0;
                somaPorUnidade[unidade] = (somaPorUnidade[unidade] || 0) + qtd;
            });

            const unidades = Object.keys(somaPorUnidade);

            if (unidades.length === 0) {
                resumoEl.innerHTML = `<span class="text-slate-400 italic">Nenhum item selecionado para soma.</span>`;
                return;
            }

            const badges = unidades.map(un => `
                <span class="bg-indigo-100 text-indigo-800 font-black px-2.5 py-1 rounded-lg border border-indigo-200">
                    ${formatarNumeroSoma(somaPorUnidade[un])}${un}
                </span>
            `).join('');

            resumoEl.innerHTML = `<span class="text-slate-600 font-bold mr-1">Soma selecionada:</span>${badges}`;
        }

        function mudarSetor(setor) {
            setorAtual = setor;
            const btnMani = document.getElementById('btnManicure'); 
            const btnCabelo = document.getElementById('btnCabeleireiro');
            const fluxoMani = document.getElementById('fluxoManicure');
            const fluxoCabelo = document.getElementById('fluxoCabeleireiro');
            const blocoServico = document.getElementById('blocoServicoCabelo');

            // Troca de setor invalida a luva padrão que estava aplicada (era da
            // profissional do outro setor) — volta a mostrar todos os tamanhos.
            mostrarTodasOpcoesLuva();
            // Serviço selecionado também não faz sentido para o outro setor.
            limparServicoSelecionado();

            if (setor === 'manicure') {
                btnMani.className = "py-3 text-center font-bold rounded-xl border-2 border-indigo-600 text-indigo-600 bg-indigo-50 shadow-sm";
                btnCabelo.className = "py-3 text-center font-bold rounded-xl border-2 border-slate-200 text-slate-600 hover:bg-slate-50 shadow-sm";
                fluxoMani.classList.remove('hidden');
                fluxoCabelo.classList.add('hidden');
                if (blocoServico) blocoServico.classList.add('hidden');
            } else {
                btnCabelo.className = "py-3 text-center font-bold rounded-xl border-2 border-red-600 text-red-600 bg-red-50 shadow-sm";
                btnMani.className = "py-3 text-center font-bold rounded-xl border-2 border-slate-200 text-slate-600 hover:bg-slate-50 shadow-sm";
                fluxoCabelo.classList.remove('hidden');
                fluxoMani.classList.add('hidden');
                if (blocoServico) blocoServico.classList.remove('hidden');
            }
        }

        // =====================================================
        // SERVIÇO (Cabeleireiro): Corte, Escova, Coloração, Hidratação...
        // Marca o próximo item adicionado à lista com o serviço selecionado,
        // para permitir separar os lançamentos por serviço na comanda e na
        // Graces (ver historico_agrupado_pendente e lancarComandaNaGraces).
        // =====================================================
        let servicoAtualSelecionado = null;

        async function escutarBuscaServico(termo) {
            const lista = document.getElementById('listaSugestoesServico');
            if (!termo || termo.trim().length === 0) {
                lista.classList.add('hidden');
                lista.innerHTML = '';
                return;
            }
            try {
                const resposta = await fetch(`/api/buscar_servico?termo=${encodeURIComponent(termo)}`);
                const dados = await resposta.json();
                lista.innerHTML = "";
                if (dados.sucesso && dados.servicos.length > 0) {
                    lista.classList.remove('hidden');
                    dados.servicos.forEach(s => {
                        const item = document.createElement('button');
                        item.type = "button";
                        item.className = "w-full text-left p-2 hover:bg-indigo-600 hover:text-white text-xs font-bold block border-b last:border-0";
                        item.innerText = s.nome;
                        item.onclick = () => selecionarServico(s.nome);
                        lista.appendChild(item);
                    });
                } else {
                    lista.classList.add('hidden');
                }
            } catch (err) { console.error(err); }
        }

        function selecionarServico(nomeServico) {
            servicoAtualSelecionado = nomeServico;
            document.getElementById('campoBuscaServico').value = nomeServico;
            document.getElementById('listaSugestoesServico').classList.add('hidden');
            document.getElementById('feedbackServico').innerText = `✅ Próximos itens vão para o serviço: ${nomeServico}`;
            document.getElementById('feedbackServico').className = "text-xs mt-1 text-emerald-600 font-bold";
        }

        function limparServicoSelecionado() {
            servicoAtualSelecionado = null;
            const campo = document.getElementById('campoBuscaServico');
            if (campo) campo.value = "";
            const lista = document.getElementById('listaSugestoesServico');
            if (lista) { lista.classList.add('hidden'); lista.innerHTML = ''; }
            const feedback = document.getElementById('feedbackServico');
            if (feedback) {
                feedback.innerText = "Nenhum serviço selecionado — os próximos itens vão sem serviço definido.";
                feedback.className = "text-xs mt-1 text-slate-400 italic";
            }
        }

        function abrirModalNovoServico() {
            document.getElementById('novoNomeServico').value = "";
            abrirModal('modalNovoServico');
        }

        function salvarNovoServico() {
            const nome = document.getElementById('novoNomeServico').value.trim();
            if (!nome) { mostrarAlerta("Digite o nome do serviço!", 'aviso'); return; }

            fetch('/api/cadastrar_servico', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nome })
            }).then(async r => {
                if (!r.ok) throw new Error(`Servidor retornou erro ${r.status}`);
                return r.json();
            }).then(res => {
                if (res.sucesso) {
                    mostrarAlerta("✅ " + res.mensagem, 'sucesso');
                    fecharModal('modalNovoServico');
                    selecionarServico(res.servico ? res.servico.nome : nome);
                } else {
                    mostrarAlerta("⚠️ " + (res.mensagem || "Não foi possível salvar o serviço."), 'aviso');
                }
            }).catch(err => {
                console.error('Erro ao cadastrar serviço:', err);
                mostrarAlerta("❌ Ocorreu um erro ao salvar o serviço. Tente novamente.", 'erro');
            });
        }

        function abrirModal(id) { document.getElementById(id).classList.remove('hidden'); }
        function fecharModal(id) { document.getElementById(id).classList.add('hidden'); }

        function abrirModalNovoProfissional(funcao) {
            document.getElementById('novaFuncaoProfissional').value = funcao;
            abrirModal('modalNovoProfissional');
        }

        function abrirModalNovoProduto() { _origemModalNovoProduto = null; abrirModal('modalNovoProduto'); }

        // Abre o mesmo modal de cadastro de produto, mas a partir do fluxo de
        // vincular itens importados: ao salvar, o produto recém-criado é
        // automaticamente selecionado como o "produto oficial" daquela semana,
        // sem precisar buscar de novo.
        function abrirModalNovoProdutoParaVincular(index, nomeSugerido) {
            _origemModalNovoProduto = { tipo: 'vincular', index: index };
            document.getElementById('novoNomeProduto').value = nomeSugerido || '';
            document.getElementById('novoCodigoProduto').value = '';
            document.getElementById('novoTipoMedida').value = 'un';
            document.getElementById('novoTamanhoEmbalagem').value = '';
            document.getElementById('novoEstoqueAtual').value = '0';
            document.getElementById('grupoNovaEmbalagem').classList.add('hidden');

            const sugestoesEl = document.getElementById(`sugestoesProduto_${index}`);
            if (sugestoesEl) {
                sugestoesEl.classList.add('hidden');
                sugestoesEl.innerHTML = '';
            }

            abrirModal('modalNovoProduto');
        }

        function salvarNovoProfissional() {
            const nome = document.getElementById('novoNomeProfissional').value.trim();
            const funcao = document.getElementById('novaFuncaoProfissional').value;
            const luva_padrao = document.getElementById('novaLuvaPadraoProfissional').value;
            if (!nome) { mostrarAlerta("Digite o nome do profissional!", 'aviso'); return; }

            fetch('/api/cadastrar_profissional', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nome, funcao, luva_padrao })
            }).then(async r => {
                if (!r.ok) {
                    throw new Error(`Servidor retornou erro ${r.status}`);
                }
                return r.json();
            }).then(res => {
                if (res.sucesso) {
                    mostrarAlerta("✅ " + res.mensagem, 'sucesso');
                    fecharModal('modalNovoProfissional');
                    document.getElementById('novoNomeProfissional').value = "";
                    document.getElementById('novaLuvaPadraoProfissional').value = "";
                    const target = funcao === 'manicure' ? 'campoBuscaManicure' : 'campoBuscaCabeleireiro';
                    document.getElementById(target).value = nome;
                    aplicarLuvaPadraoProfissional(res.profissional ? res.profissional.luva_padrao : luva_padrao);
                } else {
                    mostrarAlerta("⚠️ " + (res.mensagem || "Não foi possível salvar o profissional."), 'aviso');
                }
            }).catch(err => {
                console.error('Erro ao cadastrar profissional:', err);
                mostrarAlerta("❌ Ocorreu um erro ao salvar o profissional. Tente novamente.", 'erro');
            });
        }

        function toggleCampoEmbalagem(contexto) {
            const medidaId = contexto === 'novo' ? 'novoTipoMedida' : 'editMedida';
            const grupoId  = contexto === 'novo' ? 'grupoNovaEmbalagem' : 'grupoEmbalagem';
            const medida = document.getElementById(medidaId).value;
            document.getElementById(grupoId).classList.toggle('hidden', medida === 'un');
        }

        function salvarNovoProduto() {
            const nome = document.getElementById('novoNomeProduto').value.trim();
            const codigo_barras = document.getElementById('novoCodigoProduto').value.trim();
            const tipo_medida = document.getElementById('novoTipoMedida').value;
            const tamanho_embalagem = document.getElementById('novoTamanhoEmbalagem').value || 1;
            const estoque_atual = document.getElementById('novoEstoqueAtual').value || 0;
            const checkboxControla = document.getElementById('novoControlaEstoque');
            const controla_estoque = checkboxControla ? checkboxControla.checked : true;
            if (!nome) { mostrarAlerta("Digite o nome do produto!", 'aviso'); return; }

            fetch('/api/cadastrar_produto', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nome, codigo_barras, tipo_medida, tamanho_embalagem, estoque_atual, controla_estoque })
            }).then(r => r.json()).then(res => {
                if (res.sucesso) {
                    mostrarAlerta("✅ " + res.mensagem, 'sucesso');
                    fecharModal('modalNovoProduto');
                    document.getElementById('novoNomeProduto').value = "";
                    document.getElementById('novoCodigoProduto').value = "";
                    document.getElementById('novoTamanhoEmbalagem').value = "";
                    document.getElementById('novoEstoqueAtual').value = "0";
                    if (checkboxControla) checkboxControla.checked = true;

                    if (_origemModalNovoProduto && _origemModalNovoProduto.tipo === 'vincular') {
                        // Veio do fluxo de vincular itens importados: seleciona
                        // o produto recém-criado direto na semana de origem.
                        const idx = _origemModalNovoProduto.index;
                        selecionarProdutoOficial(idx, res.produto.codigo_barras, res.produto.nome);
                        _origemModalNovoProduto = null;
                    } else {
                        selecionarProduto(res.produto);
                    }
                } else {
                    mostrarAlerta("❌ " + (res.mensagem || 'Não foi possível cadastrar o produto.'), 'erro');
                }
            });
        }

        function abrirModalHistorico() {
            abrirModal('modalHistorico');
            carregarHistorico();
        }

        function trocarAbaHistorico(modo) {
            modoAbaAtual = modo;
            const abaAtiva = "py-2 px-3 font-extrabold text-xs md:text-sm border-b-2 border-indigo-600 text-indigo-600 whitespace-nowrap";
            const abaInativa = "py-2 px-3 font-extrabold text-xs md:text-sm border-b-2 border-transparent text-slate-500 hover:text-indigo-600 whitespace-nowrap";
            document.getElementById('abaCron').className = modo === 'cronologica' ? abaAtiva : abaInativa;
            document.getElementById('abaMani').className = modo === 'manicures' ? abaAtiva : abaInativa;
            document.getElementById('abaManiInterno').className = modo === 'manicures_interno' ? abaAtiva : abaInativa;
            document.getElementById('abaCabelo').className = modo === 'cabeleireiros' ? abaAtiva : abaInativa;
            document.getElementById('abaCabeloInterno').className = modo === 'cabeleireiros_interno' ? abaAtiva : abaInativa;
            carregarHistorico();
        }

        function carregarHistorico() {
            const container = document.getElementById('conteudoHistorico');
            fetch('/api/historico_agrupado_pendente')
                .then(r => r.json())
                .then(dados => {
                    if (!dados.sucesso) return;
                    
                    if (modoAbaAtual === 'cronologica') {
                        if (dados.saidas_brutas.length === 0) {
                            container.innerHTML = `<p class="text-center text-slate-400 italic py-6">Nenhum lançamento pendente.</p>`;
                            return;
                        }
                        container.innerHTML = "";
                        dados.saidas_brutas.slice().reverse().forEach(s => {
                            const div = document.createElement('div');
                            div.className = "bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm";
                            
                            let itensHTML = s.itens.map(i => {
                                const cod = i.codigo_barras || i.codigo || 'S/COD';
                                const nomeItem = i.nome || i.nome_produto || 'PRODUTO';
                                return `
                                    <li class="text-xs text-slate-800 font-medium flex justify-between items-center py-1.5 border-b border-slate-100 last:border-0">
                                        <span>• <b>${nomeItem.toUpperCase()}</b> <span class="text-[10px] font-black text-indigo-900 bg-indigo-100 px-2 py-0.5 rounded ml-2 border border-indigo-200">COD: ${cod}</span></span>
                                        <b class="text-indigo-700 font-black">${i.quantidade}${i.tipo_medida || 'un'}</b>
                                    </li>
                                `;
                            }).join('');

                            div.innerHTML = `
                                <div class="flex justify-between items-center border-b pb-1.5 mb-2">
                                    <span class="text-[11px] font-bold text-slate-400">${s.data_hora}</span>
                                    <span class="text-xs font-black text-indigo-900 bg-indigo-50 px-2.5 py-0.5 rounded-lg border border-indigo-100">${s.profissional.toUpperCase()} (${s.setor.toUpperCase()})</span>
                                </div>
                                <ul class="space-y-1">${itensHTML}</ul>
                            `;
                            container.appendChild(div);
                        });
                    } 
                    else {
                        let listaFiltrada;
                        if (modoAbaAtual === 'manicures') {
                            // Aba normal de MANICURES: mostra as clientes de verdade, sem misturar
                            // com o bloco de uso interno (que tem sua própria aba, ver abaixo).
                            listaFiltrada = dados.agrupado.filter(a => a.setor === 'manicure' && a.cliente !== CLIENTE_USO_INTERNO);
                        } else if (modoAbaAtual === 'manicures_interno') {
                            // Só os blocos de uso interno da manicure (cliente fixa "USO INTERNO (SALÃO)")
                            listaFiltrada = dados.agrupado.filter(a => a.setor === 'manicure' && a.cliente === CLIENTE_USO_INTERNO);
                        } else if (modoAbaAtual === 'cabeleireiros_interno') {
                            // Só os blocos de uso interno do cabeleireiro (cliente fixa "USO INTERNO (SALÃO)")
                            listaFiltrada = dados.agrupado.filter(a => a.setor === 'cabeleireiro' && a.cliente === CLIENTE_USO_INTERNO);
                        } else {
                            // Aba normal de CABELEIREIROS: mostra as clientes de verdade, sem misturar
                            // com o bloco de uso interno (que tem sua própria aba, ver acima).
                            listaFiltrada = dados.agrupado.filter(a => a.setor === 'cabeleireiro' && a.cliente !== CLIENTE_USO_INTERNO);
                        }

                        if (listaFiltrada.length === 0) {
                            const rotulos = {
                                'manicures_interno': 'USO INTERNO (MANICURES)',
                                'cabeleireiros_interno': 'USO INTERNO (CABELEIREIROS)'
                            };
                            const rotulo = rotulos[modoAbaAtual] || modoAbaAtual.toUpperCase();
                            container.innerHTML = `<p class="text-center text-slate-400 italic py-6">Nenhum lançamento de ${rotulo} pendente.</p>`;
                            return;
                        }

                        container.innerHTML = "";
                        listaFiltrada.forEach((ag, idxBloco) => {
                            const div = document.createElement('div');
                            div.className = "bg-white p-4 rounded-xl border border-slate-200 shadow-sm relative";

                            // Monta a lista de itens de UM serviço (sub-bloco), reaproveitando
                            // o mesmo template de linha de sempre. 'servicoAttr' vai em cada
                            // botão de editar/excluir/trocar código, para que a ação atinja
                            // exatamente o item deste serviço (nunca o de outro serviço com o
                            // mesmo produto — ver _item_bate no backend).
                            function montarItensHTML(itensDoGrupo) {
                                return itensDoGrupo.map(i => {
                                    const cod = i.codigo_barras || i.codigo || 'S/COD';
                                    const nomeItem = i.nome_produto || i.nome || 'PRODUTO';
                                    const idsItemJSON = JSON.stringify(i.ids_lancamentos || []).replace(/'/g, "&#39;");
                                    const codAttr = cod.replace(/'/g, "&#39;");
                                    const nomeAttr = nomeItem.replace(/'/g, "&#39;");
                                    const servicoAttr = (i.servico || '').replace(/'/g, "&#39;");
                                    const unidade = i.tipo_medida || 'un';
                                    const qtdInput = formatarQtdParaInput(i.quantidade);
                                    return `
                                        <li class="linha-item-comanda text-xs text-slate-800 font-medium py-2 border-b-2 border-dashed border-slate-200 last:border-0">
                                            <div class="flex items-center gap-2 mb-1.5">
                                                <input type="checkbox" class="chk-item-bloco-${idxBloco} w-3.5 h-3.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer flex-shrink-0" data-ids='${idsItemJSON}' data-cod='${codAttr}' data-nome='${nomeAttr}' checked onchange="atualizarMasterBloco(${idxBloco})">
                                                <span class="min-w-0">• <b>${nomeItem.toUpperCase()}</b> <span class="text-[10px] font-black text-indigo-900 bg-indigo-100 px-2 py-0.5 rounded ml-2 border border-indigo-200">COD: ${cod}</span></span>
                                                <button type="button" onclick='abrirModalTrocarCodigoItemBloco(${idsItemJSON}, "${codAttr}", "${nomeAttr}", "${servicoAttr}")' class="w-5 h-5 bg-amber-50 hover:bg-amber-500 text-amber-600 hover:text-white rounded-md flex items-center justify-center font-black text-[11px] flex-shrink-0" title="Corrigir código de barras deste lançamento">✎</button>
                                            </div>
                                            <div class="flex items-center justify-end gap-1">
                                                <button type="button" onclick='alterarQuantidadeItemBloco(this, ${idsItemJSON}, "${codAttr}", "${nomeAttr}", -1, "${servicoAttr}")' class="w-6 h-6 bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-600 rounded-md flex items-center justify-center font-black text-sm leading-none" title="Diminuir 1">−</button>
                                                <input type="text" inputmode="decimal" class="input-qtd-item w-12 text-center text-xs font-black text-indigo-700 border border-slate-200 rounded-md py-0.5" value="${qtdInput}" onblur='salvarQuantidadeDigitadaItemBloco(this, ${idsItemJSON}, "${codAttr}", "${nomeAttr}", "${servicoAttr}")' onkeydown="if(event.key==='Enter'){this.blur();}">
                                                <span class="text-[10px] font-bold text-slate-400 mr-0.5">${unidade}</span>
                                                <button type="button" onclick='alterarQuantidadeItemBloco(this, ${idsItemJSON}, "${codAttr}", "${nomeAttr}", 1, "${servicoAttr}")' class="w-6 h-6 bg-slate-100 hover:bg-emerald-100 text-slate-600 hover:text-emerald-600 rounded-md flex items-center justify-center font-black text-sm leading-none" title="Aumentar 1">+</button>
                                                <button type="button" onclick='excluirItemComConfirmacao(${idsItemJSON}, "${codAttr}", "${nomeAttr}", "${servicoAttr}")' class="w-6 h-6 bg-rose-50 hover:bg-rose-600 text-rose-500 hover:text-white rounded-md flex items-center justify-center font-black text-xs ml-0.5" title="Excluir produto da comanda">✕</button>
                                            </div>
                                        </li>
                                    `;
                                }).join('');
                            }

                            // Sub-blocos por serviço: se a comanda só tem um "serviço" e ele é
                            // vazio (setor sem conceito de serviço, ex.: manicure), mantém o
                            // visual de sempre — um único bloco, botão 🚀 no cabeçalho da
                            // comanda. Só quando há serviço(s) de verdade é que a comanda
                            // aparece dividida em sub-blocos, cada um com seu próprio 🚀.
                            const grupos = ag.servicos && ag.servicos.length > 0 ? ag.servicos : [{ servico: null, itens: ag.itens }];
                            const usaSubBlocosServico = grupos.length > 1 || !!grupos[0].servico;

                            let corpoComandaHTML;
                            let botaoGracesTopoHTML = '';

                            if (!usaSubBlocosServico) {
                                corpoComandaHTML = `<ul class="space-y-0.5 bg-slate-50 p-2 rounded-lg border border-slate-100">${montarItensHTML(grupos[0].itens)}</ul>`;
                                botaoGracesTopoHTML = `
                                    <button onclick='lancarComandaNaGraces(this, ${JSON.stringify(ag.profissional)}, ${JSON.stringify(ag.cliente)}, ${JSON.stringify(ag.setor)}, ${JSON.stringify(grupos[0].itens)})' class="w-8 h-8 bg-indigo-50 border-2 border-indigo-500 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-lg flex items-center justify-center font-black transition-all shadow-sm" title="Lançar automaticamente na Graces">
                                        🚀
                                    </button>`;
                            } else {
                                corpoComandaHTML = grupos.map(grupo => {
                                    const nomeServico = grupo.servico || 'SEM SERVIÇO DEFINIDO';
                                    return `
                                        <div class="mb-3 last:mb-0">
                                            <div class="flex items-center justify-between gap-2 mb-1.5">
                                                <span class="text-[10px] font-black text-violet-700 bg-violet-100 px-2 py-0.5 rounded uppercase tracking-wider border border-violet-200">✂️ ${nomeServico}</span>
                                                <button onclick='lancarComandaNaGraces(this, ${JSON.stringify(ag.profissional)}, ${JSON.stringify(ag.cliente)}, ${JSON.stringify(ag.setor)}, ${JSON.stringify(grupo.itens)})' class="w-7 h-7 bg-indigo-50 border-2 border-indigo-500 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-lg flex items-center justify-center font-black text-xs transition-all shadow-sm flex-shrink-0" title="Lançar automaticamente na Graces (serviço: ${nomeServico})">
                                                    🚀
                                                </button>
                                            </div>
                                            <ul class="space-y-0.5 bg-slate-50 p-2 rounded-lg border border-slate-100">${montarItensHTML(grupo.itens)}</ul>
                                        </div>
                                    `;
                                }).join('');
                            }

                            let idsJSON = JSON.stringify(ag.ids_lancamentos);

                            div.innerHTML = `
                                <div class="flex justify-between items-start border-b border-slate-100 pb-3 mb-3">
                                    <div>
                                        <div class="flex items-center gap-2 mb-1">
                                            <input type="checkbox" id="masterBloco_${idxBloco}" class="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer" checked onchange="toggleTodosItensBloco(${idxBloco})" title="Selecionar Todos">
                                            <span class="text-[10px] font-black bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded uppercase tracking-wider">${ag.setor.toUpperCase()}</span>
                                            <span class="text-xs font-black text-indigo-950 uppercase">👤 ${ag.profissional}</span>
                                        </div>
                                        <p class="text-xs font-extrabold text-slate-500">CLIENTE: <span class="text-slate-900 uppercase font-black">${ag.cliente}</span></p>
                                    </div>

                                    <div class="flex items-center gap-2">
                                        <span class="text-[11px] font-extrabold text-slate-400 mr-1">${ag.total_lancamentos} Lançamento(s)</span>
                                        ${botaoGracesTopoHTML}
                                        <button onclick='confirmarSelecaoBloco(${idxBloco}, ${idsJSON})' class="w-8 h-8 bg-emerald-50 border-2 border-emerald-500 text-emerald-600 hover:bg-emerald-600 hover:text-white rounded-lg flex items-center justify-center font-black transition-all shadow-sm" title="Confirmar Selecionados">
                                            ✓
                                        </button>
                                        <button onclick='excluirBlocoProfissional(${idsJSON})' class="w-8 h-8 bg-rose-50 border-2 border-rose-500 text-rose-600 hover:bg-rose-600 hover:text-white rounded-lg flex items-center justify-center font-black transition-all shadow-sm" title="Excluir Bloco">
                                            ✕
                                        </button>
                                    </div>
                                </div>
                                ${corpoComandaHTML}
                            `;
                            container.appendChild(div);
                        });
                    }
                });
        }

        // Deixa "2.0" virar "2" no campo editável, mas preserva decimais reais
        // (ex: 1.5) — só cosmético, não interfere no valor enviado ao backend.
        function formatarQtdParaInput(qtd) {
            const n = Number(qtd);
            if (Number.isNaN(n)) return qtd;
            return (n % 1 === 0) ? String(n) : String(parseFloat(n.toFixed(2)));
        }

        // Botões (−)/(+) de um item dentro de uma comanda em Saídas Pendentes.
        // idsLancamentos vem do próprio item agregado (i.ids_lancamentos): pode
        // apontar para mais de um lançamento quando a profissional adicionou o
        // mesmo produto em momentos diferentes na mesma comanda.
        // 'servico' identifica de qual sub-bloco (serviço) este produto veio —
        // sem isso, o mesmo produto lançado em dois serviços diferentes da
        // mesma cliente (ex.: luva na Escova e luva na Coloração) seria ambíguo.
        function alterarQuantidadeItemBloco(botao, idsLancamentos, codigoBarras, nomeProduto, delta, servico) {
            const linha = botao.closest('.linha-item-comanda');
            const input = linha ? linha.querySelector('.input-qtd-item') : null;
            const atual = input ? (parseFloat(String(input.value).replace(',', '.')) || 0) : 0;
            const nova = atual + delta;

            if (nova <= 0) {
                excluirItemComConfirmacao(idsLancamentos, codigoBarras, nomeProduto, servico);
                return;
            }
            if (input) input.value = formatarQtdParaInput(nova);
            salvarNovaQuantidadeItemBloco(idsLancamentos, codigoBarras, nomeProduto, nova, servico);
        }

        // Campo de quantidade editável: dispara ao sair do campo (blur) ou Enter.
        function salvarQuantidadeDigitadaItemBloco(input, idsLancamentos, codigoBarras, nomeProduto, servico) {
            const nova = parseFloat(String(input.value).replace(',', '.'));

            if (Number.isNaN(nova) || nova < 0) {
                mostrarAlerta("⚠️ Quantidade inválida.", 'aviso');
                carregarHistorico();
                return;
            }
            if (nova === 0) {
                excluirItemComConfirmacao(idsLancamentos, codigoBarras, nomeProduto, servico);
                return;
            }
            salvarNovaQuantidadeItemBloco(idsLancamentos, codigoBarras, nomeProduto, nova, servico);
        }

        async function salvarNovaQuantidadeItemBloco(idsLancamentos, codigoBarras, nomeProduto, novaQuantidade, servico) {
            try {
                const res = await fetch('/api/editar_quantidade_item_pendente', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        ids_lancamentos: idsLancamentos,
                        codigo_barras: codigoBarras,
                        nome_produto: nomeProduto,
                        nova_quantidade: novaQuantidade,
                        servico: servico || ''
                    })
                });
                const r = await res.json();
                if (!r.sucesso) mostrarAlerta("❌ " + (r.mensagem || "Não foi possível atualizar a quantidade."), 'erro');
            } catch (e) {
                mostrarAlerta("❌ Erro de conexão ao atualizar a quantidade.", 'erro');
            } finally {
                carregarHistorico();
            }
        }

        function excluirItemComConfirmacao(idsLancamentos, codigoBarras, nomeProduto, servico) {
            if (!confirm(`Excluir "${nomeProduto}" desta comanda?`)) {
                carregarHistorico(); // reverte qualquer alteração visual não salva no input
                return;
            }
            excluirItemBloco(idsLancamentos, codigoBarras, nomeProduto, servico);
        }

        async function excluirItemBloco(idsLancamentos, codigoBarras, nomeProduto, servico) {
            try {
                const res = await fetch('/api/excluir_item_pendente', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        ids_lancamentos: idsLancamentos,
                        codigo_barras: codigoBarras,
                        nome_produto: nomeProduto,
                        servico: servico || ''
                    })
                });
                const r = await res.json();
                if (!r.sucesso) mostrarAlerta("❌ " + (r.mensagem || "Não foi possível excluir o produto."), 'erro');
            } catch (e) {
                mostrarAlerta("❌ Erro de conexão ao excluir o produto.", 'erro');
            } finally {
                carregarHistorico();
            }
        }

        // Corrigir código de barras de um item já lançado em Saídas Pendentes.
        // Diferente de alterarQuantidadeItemBloco: aqui a quantidade não muda,
        // só o codigo_barras "congelado" no lançamento — e o estoque é
        // realocado do produto errado para o produto correto (ver backend).
        let _trocarCodigoItemContexto = null;

        function abrirModalTrocarCodigoItemBloco(idsLancamentos, codigoBarras, nomeProduto, servico) {
            _trocarCodigoItemContexto = { idsLancamentos, codigoBarras, nomeProduto, servico };
            document.getElementById('trocarCodigoItemNome').textContent = nomeProduto;
            document.getElementById('trocarCodigoItemAtual').textContent = codigoBarras || 'S/COD';
            const input = document.getElementById('trocarCodigoItemNovo');
            input.value = '';
            abrirModal('modalTrocarCodigoItem');
            setTimeout(() => input.focus(), 50);
        }

        async function confirmarTrocaCodigoItemBloco() {
            if (!_trocarCodigoItemContexto) return;
            const novoCodigo = document.getElementById('trocarCodigoItemNovo').value.trim();
            if (!novoCodigo) {
                mostrarAlerta("⚠️ Informe o novo código de barras.", 'aviso');
                return;
            }
            const { idsLancamentos, codigoBarras, nomeProduto, servico } = _trocarCodigoItemContexto;
            try {
                const res = await fetch('/api/trocar_codigo_item_pendente', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        ids_lancamentos: idsLancamentos,
                        codigo_barras: codigoBarras,
                        nome_produto: nomeProduto,
                        novo_codigo_barras: novoCodigo,
                        servico: servico || ''
                    })
                });
                const r = await res.json();
                if (r.sucesso) {
                    mostrarAlerta("✅ Código corrigido!", 'sucesso');
                    fecharModal('modalTrocarCodigoItem');
                } else {
                    mostrarAlerta("❌ " + (r.mensagem || "Não foi possível trocar o código."), 'erro');
                }
            } catch (e) {
                mostrarAlerta("❌ Erro de conexão ao trocar o código.", 'erro');
            } finally {
                carregarHistorico();
            }
        }

        let abaGerenciamentoAtual = 'produtos';
        let dadosAtuaisGerenciamento = [];

        function abrirModalGerenciamento() {
            const modal = document.getElementById('modalGerenciamento');
            if (modal) {
                modal.classList.remove('hidden');
                modal.classList.add('flex');
                mudarAbaGerenciamento('produtos'); // Abre direto na aba de produtos por padrão
            }
        }

        function fecharModalGerenciamento() {
            const modal = document.getElementById('modalGerenciamento');
            if (modal) {
                modal.classList.remove('flex');
                modal.classList.add('hidden');
            }
        }

        // Controla a troca de abas no topo do modal
        function mudarAbaGerenciamento(aba) {
            abaGerenciamentoAtual = aba;
            
            // Reseta o estilo das 3 abas
            ['produtos', 'manicure', 'cabeleireiro'].forEach(item => {
                const btn = document.getElementById(`abaGer${item.charAt(0).toUpperCase() + item.slice(1)}`);
                if (btn) {
                    if (item === aba) {
                        btn.className = "px-5 py-2.5 text-xs font-bold transition-all border-b-2 text-indigo-600 border-indigo-600 cursor-pointer";
                    } else {
                        btn.className = "px-5 py-2.5 text-xs font-bold transition-all border-b-2 text-slate-400 border-transparent hover:text-slate-600 cursor-pointer";
                    }
                }
            });

            const inputBusca = document.getElementById('inputBuscaGerenciamento');
            if (inputBusca) inputBusca.value = '';
            
            carregarDadosGerenciamento();
        }

        async function carregarDadosGerenciamento() {
            const container = document.getElementById('containerListaGerenciamento');
            container.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Carregando dados do servidor...</div>`;

            try {
                if (abaGerenciamentoAtual === 'produtos') {
                    const res = await fetch('/api/buscar_produto_editar?termo=');
                    const dados = await res.json();
                    dadosAtuaisGerenciamento = dados.produtos || [];
                } else {
                    // ALTERE AQUI para a rota correta do seu backend Flask que retorna os profissionais
                    // Exemplo comum: '/api/listar_profissionais' ou '/api/buscar_profissionais'
                    const res = await fetch('/api/listar_profissionais'); 
                    const dados = await res.json();
                    
                    //console.log("Dados brutos dos profissionais:", dados);

                    // Pega a lista considerando diferentes nomes possíveis que o JSON possa ter
                    const listaBruta = dados.profissionais || dados.equipe || dados.funcionarios || dados || [];
                    
                    // Garante que é um array antes de filtrar
                    const arraySeguro = Array.isArray(listaBruta) ? listaBruta : [];

                    // Filtra os profissionais com base na aba atual (manicure ou cabeleireiro)
                    dadosAtuaisGerenciamento = arraySeguro.filter(p => {
                        const funcaoProf = (p.funcao || p.setor || p.cargo || '').toLowerCase();
                        return funcaoProf === abaGerenciamentoAtual.toLowerCase();
                    });
                }
                
                renderizarListaGerenciamento(dadosAtuaisGerenciamento);
            } catch (e) {
                console.error(e);
                container.innerHTML = `<div class="p-8 text-center text-rose-500 text-xs">Erro ao carregar dados do servidor.</div>`;
            }
        }

        // Substitua o seu método renderizarListaGerenciamento por este completo com o botão de excluir:
        function renderizarListaGerenciamento(lista) {
            const container = document.getElementById('containerListaGerenciamento');
            container.innerHTML = '';

            if (!lista || lista.length === 0) {
                container.innerHTML = `<div class="p-12 text-center text-slate-400 text-xs italic">Nenhum registro encontrado nesta categoria.</div>`;
                return;
            }

            container.innerHTML = lista.map((item) => {
                const subInfo = abaGerenciamentoAtual === 'produtos' 
                    ? `Cód: <span class="font-mono text-slate-600">${item.codigo_barras || 'N/A'}</span> • Medida: <span class="uppercase text-slate-600 font-semibold">${item.tipo_medida || 'un'}</span>`
                    : `Setor: <span class="capitalize text-slate-600 font-semibold">${item.funcao || item.setor || abaGerenciamentoAtual}</span>${item.luva_padrao ? ` • Luva padrão: <span class="font-black text-indigo-600">${item.luva_padrao}</span>` : ''}`;

                return `
                    <div class="flex items-center justify-between px-4 py-3 bg-white hover:bg-slate-50/80 rounded-xl border border-slate-200/70 transition-all text-xs shadow-xs">
                        <div class="flex flex-col">
                            <span class="font-bold text-slate-800 text-sm">${item.nome}</span>
                            <span class="text-[11px] text-slate-400 mt-0.5">${subInfo}</span>
                        </div>
                        
                        <div class="flex items-center gap-1.5">
                            <button type="button" onclick='abrirSubmodalEdicao(${JSON.stringify(item)})' class="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 text-xs font-bold rounded-lg transition-colors flex items-center gap-1 shadow-xs cursor-pointer" title="Editar">
                                ✏️ Editar
                            </button>
                            <button type="button" onclick='excluirItemGerenciamento(${JSON.stringify(item)})' class="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-bold rounded-lg transition-colors flex items-center gap-1 shadow-xs cursor-pointer" title="Excluir">
                                🗑️ Excluir
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Função que executa a exclusão via API
        async function excluirItemGerenciamento(item) {
            const nomeItem = item.nome || 'este item';
            if (!confirm(`Tem certeza que deseja excluir "${nomeItem}"?`)) {
                return;
            }

            let urlApi = '';
            let dadosEnvio = {};

            // Se estiver na aba de produtos, chama a rota de produtos
            if (abaGerenciamentoAtual === 'produtos') {
                urlApi = '/api/excluir_produto';
                dadosEnvio = { codigo_barras: item.codigo_barras };
            } 
            // Se estiver nas abas de manicure ou cabeleireiro, chama a rota de profissionais
            else {
                urlApi = '/api/excluir_profissional';
                dadosEnvio = { 
                    setor: item.funcao || item.setor || abaGerenciamentoAtual, 
                    nome: item.nome 
                };
            }

            try {
                const res = await fetch(urlApi, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(dadosEnvio)
                });
                const resposta = await res.json();

                if (resposta.sucesso) {
                    carregarDadosGerenciamento(); // Atualiza a lista na tela instantaneamente
                } else {
                    mostrarAlerta("Erro ao excluir: " + (resposta.mensagem || 'Erro desconhecido'), 'erro');
                }
            } catch (e) {
                console.error(e);
                mostrarAlerta("Erro de conexão ao tentar excluir o item.", 'erro');
            }
        }

        // Filtro da busca inteligente dentro do modal
        function filtrarItensGerenciamento(termo) {
            const termoLower = termo.toLowerCase();
            const filtrados = dadosAtuaisGerenciamento.filter(item => {
                const nome = (item.nome || '').toLowerCase();
                const codigo = (item.codigo_barras || '').toLowerCase();
                return nome.includes(termoLower) || codigo.includes(termoLower);
            });
            renderizarListaGerenciamento(filtrados);
        }

        // Ação do botão (+) para criar novo item na categoria selecionada
        function abrirFormularioNovoItem() {
            if (abaGerenciamentoAtual === 'produtos') {
                if (typeof abrirModalNovoProduto === 'function') abrirModalNovoProduto();
            } else {
                if (typeof abrirModalNovoProfissional === 'function') {
                    abrirModalNovoProfissional(abaGerenciamentoAtual);
                }
            }
        }

        // Abre o submodal flutuante preenchendo os campos corretos para edição completa
        function abrirSubmodalEdicao(item) {
            _origemModalEdicao = null;
            const submodal = document.getElementById('submodalEdicao');
            if (!submodal) return;

            submodal.classList.remove('hidden');
            submodal.classList.add('flex');

            // Preenche nome comum
            document.getElementById('editNome').value = item.nome || '';
            
            if (abaGerenciamentoAtual === 'produtos') {
                document.getElementById('editTipoItem').value = 'produto';
                document.getElementById('editCodigo').value = item.codigo_barras || '';
                document.getElementById('editMedida').value = item.tipo_medida || 'un';
                document.getElementById('editId').value = item.codigo_barras || '';
                document.getElementById('editEmbalagem').value = item.tamanho_embalagem || '';
                toggleCampoEmbalagem('edit');
                const checkboxEditControla = document.getElementById('editControlaEstoque');
                if (checkboxEditControla) checkboxEditControla.checked = item.controla_estoque !== false;

                // Mostra campos exclusivos de produto e esconde de profissional
                document.getElementById('grupoCodigoBarras').classList.remove('hidden');
                document.getElementById('grupoTipoMedida').classList.remove('hidden');
                document.getElementById('grupoControlaEstoque').classList.remove('hidden');
                document.getElementById('grupoSetor').classList.add('hidden');
                document.getElementById('grupoLuvaPadrao').classList.add('hidden');
                document.getElementById('tituloSubmodal').innerText = 'Editar Produto';
            } else {
                document.getElementById('editTipoItem').value = 'profissional';
                document.getElementById('editSetor').value = item.funcao || abaGerenciamentoAtual;
                document.getElementById('editId').value = item.id || item.nome;
                document.getElementById('editLuvaPadrao').value = item.luva_padrao || '';

                // Mostra campos exclusivos de profissional e esconde de produto
                document.getElementById('grupoCodigoBarras').classList.add('hidden');
                document.getElementById('grupoTipoMedida').classList.add('hidden');
                document.getElementById('grupoEmbalagem').classList.add('hidden');
                document.getElementById('grupoControlaEstoque').classList.add('hidden');
                document.getElementById('grupoSetor').classList.remove('hidden');
                document.getElementById('grupoLuvaPadrao').classList.remove('hidden');
                document.getElementById('tituloSubmodal').innerText = 'Editar Profissional';
            }
        }

        function fecharSubmodalEdicao() {
            const submodal = document.getElementById('submodalEdicao');
            if (submodal) {
                submodal.classList.add('hidden');
                submodal.classList.remove('flex');
            }
        }

        // Salva as alterações via API no banco.json
        async function salvarEdicaoItem() {
            const tipo = document.getElementById('editTipoItem').value;
            const idOriginal = document.getElementById('editId').value;
            const novoNome = document.getElementById('editNome').value;

            if (!novoNome.trim()) {
                mostrarAlerta("O nome não pode ficar vazio.", 'aviso');
                return;
            }

            let dadosEnvio = { tipo, id_original: idOriginal, nome: novoNome };

            if (tipo === 'produto') {
                dadosEnvio.codigo_barras = document.getElementById('editCodigo').value;
                dadosEnvio.tipo_medida = document.getElementById('editMedida').value;
                dadosEnvio.tamanho_embalagem = document.getElementById('editEmbalagem').value || 1;
            } else {
                dadosEnvio.setor = document.getElementById('editSetor').value;
                dadosEnvio.luva_padrao = document.getElementById('editLuvaPadrao').value;
            }

            try {
                const res = await fetch('/api/atualizar_item', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(dadosEnvio)
                });
                const resposta = await res.json();

                if (resposta.sucesso) {
                    fecharSubmodalEdicao();

                    if (_origemModalEdicao && _origemModalEdicao.tipo === 'vincular') {
                        // Veio do botão de editar dentro do fluxo de vincular: atualiza
                        // a seleção da semana com os dados (possivelmente corrigidos).
                        const idx = _origemModalEdicao.index;
                        const codigoFinal = (tipo === 'produto') ? dadosEnvio.codigo_barras : idOriginal;
                        selecionarProdutoOficial(idx, codigoFinal, novoNome);
                        _origemModalEdicao = null;
                    } else {
                        carregarDadosGerenciamento(); // Recarrega a listagem fixa atualizada
                    }
                } else {
                    mostrarAlerta("Erro ao salvar alterações: " + (resposta.mensagem || 'Erro desconhecido'), 'erro');
                }
            } catch (e) {
                console.error(e);
                mostrarAlerta("Erro de conexão ao tentar salvar alterações.", 'erro');
            }
        }

        function abrirSubmodalPDF() {
            abrirModal('submodalPDF');
            const area = document.getElementById('areaImpressaoPDF');
            
            // Adiciona o campo de seleção de data no topo da área do PDF se ainda não existir
            if (!document.getElementById('dataFiltroPDFContainer')) {
                const containerControle = document.createElement('div');
                containerControle.id = 'dataFiltroPDFContainer';
                containerControle.className = "mb-4 flex items-center justify-between bg-slate-100 p-2.5 rounded-xl border border-slate-200";
                containerControle.innerHTML = `
                    <label class="text-xs font-black text-slate-700 uppercase">📅 Selecionar Data do Relatório:</label>
                    <input type="date" id="inputDataPDF" value="${dataSelecionadaGlobal}" class="bg-white border border-slate-300 text-slate-800 text-xs rounded-lg px-3 py-1.5 font-bold shadow-sm focus:ring-2 focus:ring-indigo-500" onchange="carregarPreviewPDF(this.value)">
                `;
                area.parentNode.insertBefore(containerControle, area);
            } else {
                document.getElementById('inputDataPDF').value = dataSelecionadaGlobal;
            }

            carregarPreviewPDF(dataSelecionadaGlobal);
        }
        
        function carregarPreviewPDF(dataDesejada) {
            dataSelecionadaGlobal = dataDesejada;
            const area = document.getElementById('areaImpressaoPDF');
            area.innerHTML = "<p class='text-center text-slate-400 italic py-4'>Carregando dados consolidados...</p>";

            // Aqui você pode ajustar a rota do histórico para filtrar também pela data selecionada se necessário
            fetch('/api/historico_confirmado_pdf?data=' + dataDesejada)
                .then(r => r.json())
                .then(dados => {
                    if (!dados.sucesso || dados.confirmados.length === 0) {
                        area.innerHTML = `<p class='text-center text-slate-400 italic py-6'>Nenhum lançamento validado para a data ${dataDesejada.split('-').reverse().join('/')}.</p>`;
                        return;
                    }

                    let partesData = dataDesejada.split('-');
                    let dataFormatadaBR = `${partesData[2]}/${partesData[1]}/${partesData[0]}`;
                    
                    let htmlFormatado = `
                        <div id="pdfConteudo" class="p-2">
                            <div class="border-b-2 border-slate-800 pb-3 mb-4 text-center">
                                <h2 class="text-xl font-black uppercase tracking-wide text-slate-800">Relatório de Saídas do Estoque</h2>
                                <p class="text-xs font-bold text-slate-500 mt-1">Data: ${dataFormatadaBR} | Gerado em: ${new Date().toLocaleTimeString('pt-BR')}</p>
                            </div>
                            <div class="space-y-4">
                    `;

                    dados.confirmados.forEach((c) => {
                        let itensList = c.itens.map(i => {
                            const cod = i.codigo_barras || i.codigo || i.cod || 'S/COD';
                            const nomeProd = i.nome || i.nome_produto || 'PRODUTO';
                            
                            return `
                                <li class="text-xs text-slate-800 flex justify-between border-b border-slate-100 py-1">
                                    <span>• ${nomeProd.toUpperCase()} <span class="text-indigo-900 font-extrabold ml-2">COD: ${cod}</span></span>
                                    <b>${i.quantidade}${i.tipo_medida || 'un'}</b>
                                </li>
                            `;
                        }).join('');

                        htmlFormatado += `
                            <div class="border border-slate-300 rounded-xl p-3.5 bg-slate-50/50">
                                <div class="flex justify-between items-center border-b pb-1.5 mb-2">
                                    <span class="text-xs font-black text-slate-900 uppercase">👤 Profissional: ${c.profissional} (${c.setor.toUpperCase()})</span>
                                    <span class="text-xs font-bold text-slate-500 uppercase">Cliente: ${c.cliente}</span>
                                </div>
                                <ul class="space-y-0.5">${itensList}</ul>
                            </div>
                        `;
                    });

                    htmlFormatado += `</div></div>`;
                    area.innerHTML = htmlFormatado;
                });
        }

        async function exportarPDF() {
            let dataParaEnviar = '';

            // 1. Pega o valor direto do input na tela
            const inputDataElement = document.getElementById('inputDataPDF');
            if (inputDataElement && inputDataElement.value) {
                dataParaEnviar = inputDataElement.value; // Ex: "2026-08-04"
            } 
            // 2. Fallback para a variável global
            else if (typeof dataSelecionadaGlobal !== 'undefined' && dataSelecionadaGlobal) {
                dataParaEnviar = dataSelecionadaGlobal; 
            } 
            // 3. Fallback final para a data de hoje
            else {
                const hoje = new Date();
                const ano = hoje.getFullYear();
                const mes = String(hoje.getMonth() + 1).padStart(2, '0');
                const dia = String(hoje.getDate()).padStart(2, '0');
                dataParaEnviar = `${ano}-${mes}-${dia}`;
            }

            // Guarda a data limpa para usar no nome do arquivo (ex: 04-08-2026)
            let dataParaNomeArquivo = dataParaEnviar;
            if (dataParaEnviar.includes('-') && dataParaEnviar.split('-')[0].length === 4) {
                const partes = dataParaEnviar.split('-'); // [Ano, Mês, Dia]
                dataParaNomeArquivo = `${partes[2]}-${partes[1]}-${partes[0]}`; 
            }

            const nomeArquivo = `Relatorio_Estoque_${dataParaNomeArquivo}.pdf`;

            // Dentro do app desktop (pywebview/.exe) não existe um gerenciador
            // de downloads como num navegador — por isso usamos a ponte
            // Python (window.pywebview.api) para abrir o diálogo nativo
            // "Salvar como" e gravar o PDF direto em disco.
            if (window.pywebview && window.pywebview.api && window.pywebview.api.salvar_pdf) {
                try {
                    const resultado = await window.pywebview.api.salvar_pdf(nomeArquivo, dataParaNomeArquivo);
                    if (resultado.ok) {
                        // PDF salvo com sucesso em resultado.caminho
                    } else if (!resultado.cancelado) {
                        mostrarAlerta("Erro ao tentar salvar o relatório em PDF: " + (resultado.erro || 'motivo desconhecido.'), 'erro');
                    }
                } catch (e) {
                    console.error(e);
                    mostrarAlerta("Erro ao tentar salvar o relatório em PDF.", 'erro');
                }
                return;
            }

            // Fallback: rodando num navegador comum (ex: durante o
            // desenvolvimento com "python app.py"), usa o download normal.
            const url = `/api/gerar_pdf_servidor?data=${dataParaNomeArquivo}`;
            try {
                const response = await fetch(url);
                if (!response.ok) throw new Error('Erro ao gerar o PDF no servidor.');

                const blob = await response.blob();
                const blobUrl = window.URL.createObjectURL(blob);

                const link = document.createElement('a');
                link.href = blobUrl;
                link.download = nomeArquivo;
                document.body.appendChild(link);
                link.click();

                link.remove();
                window.URL.revokeObjectURL(blobUrl);

            } catch (e) {
                console.error(e);
                mostrarAlerta("Erro ao tentar baixar o relatório em PDF.", 'erro');
            }
        }

        function resetarNovoDia() {
            if (confirm("⚠️ Tem certeza que deseja resetar todo o histórico para um NOVO DIA?")) {
                fetch('/api/resetar_historico', { method: 'POST' })
                    .then(r => r.json())
                    .then(res => {
                        mostrarAlerta("🚀 " + res.mensagem, 'sucesso');
                        carregarHistorico();
                        limparFormulario();
                    });
            }
        }

        function limparFormulario() {
            listaItensParaSaida = [];
            limparCamposBuscaProduto();
            document.getElementById('campoBuscaManicure').value = "";
            document.getElementById('campoClienteMani').value = "";
            document.getElementById('campoBuscaCabeleireiro').value = "";
            document.getElementById('campoClienteCabelo').value = "";
            const listaSugCliente = document.getElementById('listaSugestoesClienteCabelo');
            if (listaSugCliente) { listaSugCliente.classList.add('hidden'); listaSugCliente.innerHTML = ''; }
            mostrarTodasOpcoesLuva();
            // Corrigido em 05/09/2026: faltava limpar o serviço selecionado aqui.
            // Sem isso, depois de "Confirmar Retirada" o serviço (Corte/Escova/...)
            // continuava marcado como atual, e os próximos itens de uma cliente
            // diferente entravam por engano no mesmo serviço da retirada anterior.
            limparServicoSelecionado();
            renderizarTabela();
        }

        function confirmarSaida() {
            const nomeMani = document.getElementById('campoBuscaManicure').value.trim();
            const clienteMani = document.getElementById('campoClienteMani').value.trim();
            const nomeCab = document.getElementById('campoBuscaCabeleireiro').value.trim();
            const clienteCab = document.getElementById('campoClienteCabelo').value.trim();

            let profissional = setorAtual === 'manicure' ? nomeMani : nomeCab;
            let cliente = setorAtual === 'manicure' ? clienteMani : clienteCab;

            if (!profissional) { mostrarAlerta("🚨 Digite ou selecione o profissional responsável.", 'aviso'); return; }
            if (listaItensParaSaida.length === 0) { mostrarAlerta("A lista de itens está vazia!", 'aviso'); return; }

            // Separa os itens marcados como "uso interno" (🧷) dos itens normais da cliente
            // (👤). Assim dá pra lançar os dois num único clique, sem digitar o nome da
            // profissional de novo: os itens de uso interno sempre vão para o bloco fixo
            // CLIENTE_USO_INTERNO (que se agrupa com os lançamentos de uso interno
            // anteriores/posteriores da mesma profissional), e os itens da cliente vão
            // normalmente para a comanda dela.
            const itensCliente = listaItensParaSaida.filter(i => !i.usoInterno);
            const itensInterno = listaItensParaSaida.filter(i => i.usoInterno);

            // No Cabeleireiro a cliente só é obrigatória se houver algum item destinado a ela.
            if (setorAtual === 'cabeleireiro' && itensCliente.length > 0 && !cliente) {
                mostrarAlerta("🚨 Informe o nome da cliente. No setor Cabeleireiro esse campo é obrigatório para os itens marcados como \"Da cliente\".", 'aviso');
                return;
            }

            const envios = [];
            if (itensCliente.length > 0) {
                envios.push({ itens: itensCliente, profissional: profissional, setor: setorAtual, cliente: cliente });
            }
            if (itensInterno.length > 0) {
                envios.push({ itens: itensInterno, profissional: profissional, setor: setorAtual, cliente: CLIENTE_USO_INTERNO });
            }

            Promise.all(envios.map(corpo => fetch('/api/confirmar_saida', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(corpo)
            }).then(r => r.json())))
                .then(respostas => {
                    const falhas = respostas.filter(r => !r.sucesso);
                    if (falhas.length === 0) {
                        mostrarAlerta("🚀 Lançamento adicionado à fila do dia!", 'sucesso');
                        limparFormulario();
                    } else {
                        mostrarAlerta("❌ Erro: " + falhas.map(f => f.mensagem).join(' | '), 'erro');
                    }
                })
                .catch(e => {
                    console.error(e);
                    mostrarAlerta("❌ Erro de conexão ao lançar a saída.", 'erro');
                });
        }

        // Variável global para guardar os dados que vieram do servidor
        let dadosMediaCache = [];
        // Guarda os registros brutos de consumo_geral.json, usados no submodal de detalhes
        let registrosConsumoCache = [];
        let detalheLinhasCache = []; // guarda as linhas cruas do submodal de detalhe (para reagrupar/filtrar sem refazer fetch)
        let detalheGruposCache = []; // guarda os grupos (por nome) atualmente exibidos, já filtrados se houver busca
        let detalhePessoaLinhasCache = []; // lançamentos da pessoa aberta no submodal de nível 3 (para filtrar por data sem refazer fetch)

        // ===== Modal "Controle de Estoque" (lista geral de produtos) =====
        let controleEstoqueProdutosCache = []; // todos os produtos, já ordenados por nome
        let controleEstoqueListaAtual = []; // subconjunto atualmente exibido (após filtro de busca), p/ o "marcar todos filtrados"
        let controleEstoqueRegistrosCache = []; // registros crus de saída (mesma fonte do histórico de consumo)
        let controleEstoqueSelecionados = new Set(); // códigos de barras marcados p/ resumo do dia
        let produtoControleAtual = null; // produto aberto no submodal-menu (ver saídas / editar estoque)
        let produtoEmEdicaoEstoque = null; // produto sendo editado no modal "Informar Estoque Atual" (pode vir do fluxo de saída OU do Controle de Estoque)

        // Remove acentos e normaliza para minúsculo, pra busca "inteligente" (ex: "jose" acha "José")
        function normalizarBusca(texto) {
            return String(texto || '')
                .toLowerCase()
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '');
        }

        // Abre o modal e carrega os dados
        function abrirModalMediaSaida() {
            abrirModal('modalMediaSaida');
            document.getElementById('inputBuscaMedia').value = ''; // Limpa a busca ao abrir
            carregarMediaSaida();
        }

        // Busca os dados no backend e guarda no cache
        // Normaliza qualquer data para o formato ISO AAAA-MM-DD, não importa se veio como
        // DD/MM/AAAA (dos registros diários) ou já como AAAA-MM-DD (dos registros importados).
        // Sem isso, o mesmo dia real em formatos diferentes é contado como 2 dias distintos no Set.
        function normalizarDataISO(str) {
            if (!str) return null;
            const s = String(str).trim();
            if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
                return s; // já está em AAAA-MM-DD
            }
            const partes = s.split('/');
            if (partes.length === 3) {
                const [d, m, a] = partes;
                return `${a}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
            }
            return s; // formato desconhecido, devolve como veio (melhor que perder o dado)
        }

        async function carregarMediaSaida() {
            const tbody = document.getElementById('tabelaMediaSaidaCorpo');
            tbody.innerHTML = `<tr><td colspan="4" class="text-center py-6 text-slate-400 italic">Calculando médias de consumo...</td></tr>`;

            try {
                const [resConsumo, resProdutos] = await Promise.all([
                    fetch('/api/historico_consumo_geral'),
                    fetch('/api/buscar_produto_editar?termo=')
                ]);
                const dados = await resConsumo.json();
                const produtosCad = await resProdutos.json();

                // guarda os registros brutos para a listagem de saídas do submodal de detalhes
                registrosConsumoCache = dados.registros || [];

                // mapa código -> tamanho_embalagem, pra consulta O(1) mais abaixo
                const mapaEmbalagens = {};
                (produtosCad.produtos || []).forEach(p => {
                    mapaEmbalagens[p.codigo_barras] = parseFloat(p.tamanho_embalagem) || 1;
                });

                if (!dados.sucesso || !dados.registros || dados.registros.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="4" class="text-center py-6 text-slate-400 italic">Nenhum dado acumulado para cálculo ainda.</td></tr>`;
                    dadosMediaCache = [];
                    return;
                }

                let produtosControle = {};
                let totalDiasUnicos = new Set();

                dados.registros.forEach(registro => {
                    // Registros importados (consolidados de xlsx) trazem os dias reais que representam.
                    // Sem isso, uma semana inteira de consumo contaria como 1 dia só e distorceria a média.
                    if (registro.dias_periodo && Array.isArray(registro.dias_periodo) && registro.dias_periodo.length > 0) {
                        registro.dias_periodo.forEach(d => {
                            const iso = normalizarDataISO(d);
                            if (iso) totalDiasUnicos.add(iso);
                        });
                    } else if (registro.data_hora) {
                        // Campo real gravado pelo backend (bug antigo procurava 'registro.data', que não existe)
                        const dataSomente = String(registro.data_hora).split(' ')[0];
                        const iso = normalizarDataISO(dataSomente);
                        if (iso) totalDiasUnicos.add(iso);
                    } else if (registro.data) {
                        const iso = normalizarDataISO(registro.data);
                        if (iso) totalDiasUnicos.add(iso);
                    }

                    if (registro.itens && Array.isArray(registro.itens)) {
                        registro.itens.forEach(item => {
                            const cod = item.codigo_barras || item.codigo || 'S/COD';
                            const nome = item.nome || item.nome_produto || 'Produto sem nome';
                            const qtd = parseFloat(item.quantidade) || 0;
                            const medida = item.tipo_medida || 'un';

                            if (!produtosControle[cod]) {
                                produtosControle[cod] = {
                                    nome: nome,
                                    codigo: cod,
                                    totalSaido: 0,
                                    medida: medida
                                };
                            }
                            produtosControle[cod].totalSaido += qtd;
                        });
                    }
                });

                let numDias = totalDiasUnicos.size > 0 ? totalDiasUnicos.size : 1;
                let numSemanas = Math.max(1, numDias / 5);

                // Transforma o objeto em um array e guarda na variável global
                dadosMediaCache = Object.values(produtosControle).map(p => {
                    let mediaSemanal = parseFloat((p.totalSaido / numSemanas).toFixed(1));
                    const embalagem = mapaEmbalagens[p.codigo] || 1;

                    let pacotesSugeridos, totalCobertura;
                    if ((p.medida === 'ml' || p.medida === 'g') && embalagem > 1) {
                        pacotesSugeridos = Math.ceil(mediaSemanal / embalagem);
                        totalCobertura = pacotesSugeridos * embalagem;
                    } else {
                        pacotesSugeridos = Math.ceil(mediaSemanal);
                        totalCobertura = pacotesSugeridos;
                    }

                    return {
                        ...p,
                        mediaSemanal: mediaSemanal,
                        tamanhoEmbalagem: embalagem,
                        sugestaoCompra: pacotesSugeridos, // mantido por compatibilidade
                        pacotesSugeridos: pacotesSugeridos,
                        totalCobertura: totalCobertura
                    };
                });

                // Renderiza a tabela completa inicialmente
                renderizarTabelaMedia(dadosMediaCache);

            } catch (e) {
                console.error(e);
                tbody.innerHTML = `<tr><td colspan="4" class="text-center py-6 text-red-500 italic">Erro ao carregar os dados de consumo.</td></tr>`;
            }
        }

        // Exporta a tela de "Controle e Média de Saída Semanal" (a mesma lista mostrada
        // no modal, sem os detalhes de cada lançamento) para um arquivo Excel formatado.
        // Sempre exporta TODOS os produtos calculados (dadosMediaCache), não só o que
        // estiver filtrado na busca, pra servir de lista completa de compras.
        async function exportarMediaExcel() {
            if (!dadosMediaCache || dadosMediaCache.length === 0) {
                mostrarAlerta("Não há dados de consumo carregados para exportar. Clique em 'Atualizar Dados' primeiro.", 'aviso');
                return;
            }

            const nomeArquivo = `Media_Saida_Semanal_${new Date().toISOString().split('T')[0]}.xlsx`;
            const payload = { itens: dadosMediaCache };

            // Dentro do app desktop (pywebview/.exe) usa o diálogo nativo "Salvar como",
            // mesmo esquema já usado para o PDF (ver exportarPDF).
            if (window.pywebview && window.pywebview.api && window.pywebview.api.salvar_excel_media) {
                try {
                    const resultado = await window.pywebview.api.salvar_excel_media(nomeArquivo, payload);
                    if (!resultado.ok && !resultado.cancelado) {
                        mostrarAlerta("Erro ao tentar salvar o Excel: " + (resultado.erro || 'motivo desconhecido.'), 'erro');
                    }
                } catch (e) {
                    console.error(e);
                    mostrarAlerta("Erro ao tentar salvar o Excel.", 'erro');
                }
                return;
            }

            // Fallback: navegador comum (ex: "python app.py" em desenvolvimento).
            try {
                const resposta = await fetch('/api/exportar_media_excel', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                if (!resposta.ok) throw new Error('Erro ao gerar o Excel no servidor.');

                const blob = await resposta.blob();
                const blobUrl = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = blobUrl;
                link.download = nomeArquivo;
                document.body.appendChild(link);
                link.click();
                link.remove();
                window.URL.revokeObjectURL(blobUrl);
            } catch (e) {
                console.error(e);
                mostrarAlerta("Erro ao tentar baixar o Excel.", 'erro');
            }
        }

        // ============================================================
        // Alerta de estoque abaixo da média semanal de consumo (tela inicial)
        // ============================================================

        // Calcula a média semanal por produto (mesma lógica de carregarMediaSaida)
        // e devolve só os produtos cujo estoque_atual está abaixo dessa média.
        async function calcularProdutosEstoqueBaixo() {
            const [resConsumo, resProdutos] = await Promise.all([
                fetch('/api/historico_consumo_geral'),
                fetch('/api/buscar_produto_editar?termo=')
            ]);
            const dadosConsumo = await resConsumo.json();
            const dadosProdutos = await resProdutos.json();

            const listaProdutos = dadosProdutos.produtos || [];
            const mapaProdutos = {};
            listaProdutos.forEach(p => { mapaProdutos[p.codigo_barras] = p; });

            if (!dadosConsumo.sucesso || !dadosConsumo.registros || dadosConsumo.registros.length === 0) {
                return [];
            }

            let produtosControle = {};
            let totalDiasUnicos = new Set();

            dadosConsumo.registros.forEach(registro => {
                if (registro.dias_periodo && Array.isArray(registro.dias_periodo) && registro.dias_periodo.length > 0) {
                    registro.dias_periodo.forEach(d => {
                        const iso = normalizarDataISO(d);
                        if (iso) totalDiasUnicos.add(iso);
                    });
                } else if (registro.data_hora) {
                    const dataSomente = String(registro.data_hora).split(' ')[0];
                    const iso = normalizarDataISO(dataSomente);
                    if (iso) totalDiasUnicos.add(iso);
                } else if (registro.data) {
                    const iso = normalizarDataISO(registro.data);
                    if (iso) totalDiasUnicos.add(iso);
                }

                if (registro.itens && Array.isArray(registro.itens)) {
                    registro.itens.forEach(item => {
                        const cod = item.codigo_barras || item.codigo || 'S/COD';
                        const nome = item.nome || item.nome_produto || 'Produto sem nome';
                        const qtd = parseFloat(item.quantidade) || 0;
                        const medida = item.tipo_medida || 'un';

                        if (!produtosControle[cod]) {
                            produtosControle[cod] = { nome, codigo: cod, totalSaido: 0, medida };
                        }
                        produtosControle[cod].totalSaido += qtd;
                    });
                }
            });

            let numDias = totalDiasUnicos.size > 0 ? totalDiasUnicos.size : 1;
            let numSemanas = Math.max(1, numDias / 5);

            const abaixoDoMinimo = [];
            Object.values(produtosControle).forEach(p => {
                const mediaSemanal = parseFloat((p.totalSaido / numSemanas).toFixed(1));
                if (mediaSemanal <= 0) return;

                const produtoCad = mapaProdutos[p.codigo];

                // Produtos marcados como "não controla estoque" (ex.: itens de outra
                // área importados só para acompanhar o consumo mensal) nunca entram
                // no alerta de estoque baixo, mesmo tendo consumo registrado.
                if (produtoCad && produtoCad.controla_estoque === false) return;

                const estoqueAtual = produtoCad ? (parseFloat(produtoCad.estoque_atual) || 0) : 0;

                if (estoqueAtual < mediaSemanal) {
                    // Calcula quanto comprar: o que falta para cobrir a média semanal,
                    // já convertido em pacotes/embalagens quando o produto tiver
                    // tamanho_embalagem cadastrado (mesma lógica usada no modal de médias).
                    const faltante = mediaSemanal - estoqueAtual;
                    const embalagem = produtoCad ? (parseFloat(produtoCad.tamanho_embalagem) || 1) : 1;

                    let pacotesComprar, totalCobertura;
                    if ((p.medida === 'ml' || p.medida === 'g') && embalagem > 1) {
                        pacotesComprar = Math.ceil(faltante / embalagem);
                        totalCobertura = pacotesComprar * embalagem;
                    } else {
                        pacotesComprar = Math.ceil(faltante);
                        totalCobertura = pacotesComprar;
                    }

                    abaixoDoMinimo.push({
                        codigo: p.codigo,
                        nome: p.nome,
                        medida: p.medida,
                        mediaSemanal,
                        estoqueAtual,
                        tamanhoEmbalagem: embalagem,
                        pacotesComprar,
                        totalCobertura
                    });
                }
            });

            abaixoDoMinimo.sort((a, b) => (a.estoqueAtual - a.mediaSemanal) - (b.estoqueAtual - b.mediaSemanal));
            return abaixoDoMinimo;
        }

        let produtosEstoqueBaixoCache = [];

        // Carrega e exibe a faixa de aviso na tela principal. Chamada automaticamente ao abrir a página.
        async function carregarAlertaEstoque() {
            const faixa = document.getElementById('faixaAlertaEstoque');
            if (!faixa) return;

            try {
                produtosEstoqueBaixoCache = await calcularProdutosEstoqueBaixo();

                if (produtosEstoqueBaixoCache.length === 0) {
                    faixa.classList.add('hidden');
                    return;
                }

                const texto = produtosEstoqueBaixoCache.length === 1
                    ? `1 produto está com estoque abaixo da média semanal de consumo.`
                    : `${produtosEstoqueBaixoCache.length} produtos estão com estoque abaixo da média semanal de consumo.`;
                document.getElementById('faixaAlertaEstoqueTexto').innerText = texto;
                faixa.classList.remove('hidden');
            } catch (e) {
                console.error(e);
                faixa.classList.add('hidden');
            }
        }

        function abrirModalAlertaEstoque() {
            const corpo = document.getElementById('listaAlertaEstoqueCorpo');
            if (produtosEstoqueBaixoCache.length === 0) {
                corpo.innerHTML = `<p class="text-center py-6 text-slate-400 italic">Nenhum produto abaixo do mínimo no momento.</p>`;
            } else {
                corpo.innerHTML = produtosEstoqueBaixoCache.map(p => {
                    const infoEmbalagem = (p.medida === 'ml' || p.medida === 'g') && p.tamanhoEmbalagem > 1
                        ? `${p.pacotesComprar}x ${p.tamanhoEmbalagem}${p.medida} (${p.totalCobertura}${p.medida})`
                        : `${p.pacotesComprar} ${p.medida}`;
                    return `
                    <div class="flex items-center justify-between p-2.5 rounded-lg border border-amber-300 bg-amber-50">
                        <div>
                            <span class="font-black text-amber-950 block">${p.nome.toUpperCase()}</span>
                            <span class="text-[10px] text-amber-700 font-bold">COD: ${p.codigo}</span>
                            <span class="block text-[10px] text-amber-800">estoque atual: ${p.estoqueAtual} ${p.medida} · mín. semanal: ${p.mediaSemanal} ${p.medida}</span>
                        </div>
                        <div class="text-right">
                            <span class="block text-[9px] uppercase font-bold text-green-700 tracking-wide">Comprar</span>
                            <span class="block font-extrabold text-green-800">${infoEmbalagem}</span>
                        </div>
                    </div>
                `;
                }).join('');
            }
            abrirModal('modalAlertaEstoque');
        }

        document.addEventListener('DOMContentLoaded', function () {
            if (typeof carregarAlertaEstoque === 'function') carregarAlertaEstoque();
        });

        // Função que desenha os dados na tabela do HTML
        function renderizarTabelaMedia(lista) {
            const tbody = document.getElementById('tabelaMediaSaidaCorpo');

            if (lista.length === 0) {
                tbody.innerHTML = `<tr><td colspan="4" class="text-center py-6 text-slate-400 italic">Nenhum produto encontrado.</td></tr>`;
                return;
            }

            let htmlTabela = '';

            lista.forEach(p => {
                htmlTabela += `
                    <tr class="hover:bg-slate-50/80 transition">
                        <td class="p-3">
                            <span class="font-bold text-slate-900 block">${p.nome.toUpperCase()}</span>
                            <span class="text-[10px] text-indigo-700 font-extrabold">COD: ${p.codigo}</span>
                        </td>
                        <td class="p-3 text-center font-bold text-slate-700">${p.totalSaido} ${p.medida}</td>
                        <td class="p-3 text-center font-extrabold text-indigo-600">${p.mediaSemanal} ${p.medida}/sem</td>
                        <td class="p-3 text-center">
                            <button onclick="abrirSubmodalDetalheProduto('${String(p.codigo).replace(/'/g, "\\'")}')"
                                class="bg-emerald-100 hover:bg-emerald-200 text-emerald-800 font-black px-3 py-1.5 rounded-full text-[10px] transition cursor-pointer">
                                Comprar: ${p.pacotesSugeridos}un
                            </button>
                        </td>
                    </tr>
                `;
            });

            tbody.innerHTML = htmlTabela;
        }

        // Abre o submodal de detalhes de um produto (chamado ao clicar no botão "Comprar" da tabela)
        function abrirSubmodalDetalheProduto(codigo) {
            const p = dadosMediaCache.find(item => String(item.codigo) === String(codigo));
            if (!p) {
                mostrarAlerta('Não foi possível encontrar os detalhes deste produto.', 'erro');
                return;
            }

            document.getElementById('detalheProdutoNome').textContent = p.nome.toUpperCase();
            document.getElementById('detalheProdutoCod').textContent = `COD: ${p.codigo}`;
            document.getElementById('detalheValorExato').textContent = `${p.mediaSemanal} ${p.medida}/sem`;

            // Informações complementares de compra (embalagem, arredondamento e cobertura)
            const infoCompra = document.getElementById('detalheInfoCompra');
            if ((p.medida === 'ml' || p.medida === 'g') && p.tamanhoEmbalagem > 1) {
                infoCompra.innerHTML = `
                    Embalagem cadastrada: <strong>${p.tamanhoEmbalagem}${p.medida}</strong><br>
                    Sugestão: <strong>${p.pacotesSugeridos}x ${p.tamanhoEmbalagem}${p.medida}</strong>,
                    totalizando <strong>${p.totalCobertura}${p.medida}</strong>
                    (cobre a média de ${p.mediaSemanal}${p.medida}/sem)
                `;
            } else {
                infoCompra.innerHTML = `Sugestão de compra: <strong>${p.pacotesSugeridos} ${p.medida}</strong>`;
            }

            // Monta a listagem de todas as saídas desse produto a partir do JSON de registros
            const linhas = [];
            registrosConsumoCache.forEach(registro => {
                if (!registro.itens || !Array.isArray(registro.itens)) return;
                registro.itens.forEach(item => {
                    const cod = item.codigo_barras || item.codigo || 'S/COD';
                    if (String(cod) !== String(codigo)) return;

                    let dataLabel = '-';
                    if (registro.dias_periodo && Array.isArray(registro.dias_periodo) && registro.dias_periodo.length > 0) {
                        dataLabel = `Período: ${registro.dias_periodo[0]} a ${registro.dias_periodo[registro.dias_periodo.length - 1]}`;
                    } else if (registro.data_hora) {
                        dataLabel = registro.data_hora;
                    } else if (registro.data) {
                        dataLabel = registro.data;
                    }

                    linhas.push({
                        dataLabel,
                        dataOrdenacao: registro.data_hora || registro.data || '',
                        profissional: registro.profissional || registro.cliente || '-',
                        setor: registro.setor || '-',
                        quantidade: parseFloat(item.quantidade) || 0,
                        medida: item.tipo_medida || 'un'
                    });
                });
            });

            // Ordena do registro mais recente para o mais antigo
            linhas.sort((a, b) => (b.dataOrdenacao || '').localeCompare(a.dataOrdenacao || ''));

            // Guarda as linhas completas no cache e limpa a busca ao abrir
            detalheLinhasCache = linhas;
            const inputBusca = document.getElementById('inputBuscaDetalheNome');
            if (inputBusca) inputBusca.value = '';
            document.getElementById('btnLimparBuscaDetalhe').classList.add('hidden');

            renderizarDetalheGrupos(agruparLinhasPorNome(detalheLinhasCache));

            abrirModal('modalDetalheProduto');
        }

        // Agrupa as linhas de saída por nome (profissional/cliente), somando o total retirado por pessoa.
        // O agrupamento ocorre naturalmente sempre que o submodal é montado, sem precisar filtrar.
        function agruparLinhasPorNome(linhas) {
            const grupos = {};

            linhas.forEach(l => {
                const chave = normalizarBusca(l.profissional) || '-';
                if (!grupos[chave]) {
                    grupos[chave] = {
                        chave,
                        nomeExibicao: l.profissional, // usa o texto da ocorrência mais recente (linhas já vem ordenada desc)
                        totalPorMedida: {},
                        totalGeral: 0,
                        linhas: []
                    };
                }
                grupos[chave].linhas.push(l);
                grupos[chave].totalPorMedida[l.medida] = (grupos[chave].totalPorMedida[l.medida] || 0) + l.quantidade;
                grupos[chave].totalGeral += l.quantidade;
            });

            // Maior consumo primeiro
            return Object.values(grupos).sort((a, b) => b.totalGeral - a.totalGeral);
        }

        // Renderiza a tabela agrupada por nome. Cada linha de grupo é clicável e expande
        // mostrando os lançamentos individuais (data, setor, quantidade) daquela pessoa.
        function renderizarDetalheGrupos(grupos) {
            const tbody = document.getElementById('detalheListaSaidasCorpo');
            const contagem = document.getElementById('detalheFiltroContagem');

            detalheGruposCache = grupos; // guarda o conjunto atualmente exibido (já filtrado, se houver busca)

            if (grupos.length === 0) {
                tbody.innerHTML = `<tr><td colspan="3" class="text-center py-6 text-slate-400 italic">Nenhuma saída registrada${detalheLinhasCache.length > 0 ? ' para esse nome' : ' para este produto'}.</td></tr>`;
            } else {
                tbody.innerHTML = grupos.map(g => {
                    const totalTexto = Object.entries(g.totalPorMedida)
                        .map(([medida, total]) => `${parseFloat(total.toFixed(2))} ${medida}`)
                        .join(' + ');

                    return `
                        <tr class="hover:bg-slate-50/80 transition cursor-pointer select-none" onclick="abrirDetalhePessoa('${g.chave.replace(/'/g, "\\'")}')">
                            <td class="p-2.5 font-bold text-slate-800">
                                <span class="inline-block w-3 text-indigo-400">›</span>
                                ${g.nomeExibicao}
                            </td>
                            <td class="p-2.5 text-center text-slate-500">${g.linhas.length}</td>
                            <td class="p-2.5 text-right font-black text-indigo-600">${totalTexto}</td>
                        </tr>`;
                }).join('');
            }

            if (contagem) {
                const totalLancamentos = detalheLinhasCache.length;
                const lancamentosExibidos = grupos.reduce((soma, g) => soma + g.linhas.length, 0);
                contagem.textContent = totalLancamentos > 0
                    ? `${grupos.length} pessoa${grupos.length === 1 ? '' : 's'} • ${lancamentosExibidos} de ${totalLancamentos} lançamento${totalLancamentos === 1 ? '' : 's'}`
                    : '';
            }
        }

        // Busca inteligente por nome dentro do submodal de detalhe do produto.
        // Filtra os GRUPOS (não as linhas soltas), então buscar "mariah" mostra uma única
        // linha "MARIAH" com o total, e não uma linha repetida para cada lançamento.
        // Ignora acentos e maiúsculas/minúsculas. Funciona sobre o histórico completo,
        // que sobrevive ao "resetar o dia" (vem do consumo_geral.json).
        function filtrarDetalheProduto() {
            const inputEl = document.getElementById('inputBuscaDetalheNome');
            const termo = normalizarBusca(inputEl.value.trim());
            const btnLimpar = document.getElementById('btnLimparBuscaDetalhe');

            btnLimpar.classList.toggle('hidden', termo.length === 0);

            const todosOsGrupos = agruparLinhasPorNome(detalheLinhasCache);
            const filtrados = termo.length > 0
                ? todosOsGrupos.filter(g => normalizarBusca(g.nomeExibicao).includes(termo))
                : todosOsGrupos;

            renderizarDetalheGrupos(filtrados);
        }

        // --- Submodal nível 3: lançamentos detalhados de UMA pessoa, com filtro por data ---

        // Extrai a data (AAAA-MM-DD) de uma linha de lançamento, pra comparação no filtro de data.
        // dataOrdenacao pode vir como "DD/MM/AAAA HH:mm:ss" ou já em "AAAA-MM-DD".
        function extrairDataISO(linha) {
            const bruto = String(linha.dataOrdenacao || '').trim();
            const dataSomente = bruto.split(' ')[0];
            return normalizarDataISO(dataSomente);
        }

        // Abre o submodal de detalhes de uma pessoa (busca sempre no histórico COMPLETO do
        // produto, não no filtrado por nome, pra pessoa ver 100% dos lançamentos dela).
        function abrirDetalhePessoa(chave) {
            const grupo = agruparLinhasPorNome(detalheLinhasCache).find(g => g.chave === chave);
            if (!grupo) return;

            detalhePessoaLinhasCache = grupo.linhas;

            document.getElementById('detalhePessoaNome').textContent = grupo.nomeExibicao.toUpperCase();
            document.getElementById('detalhePessoaProduto').textContent = document.getElementById('detalheProdutoNome').textContent;
            document.getElementById('detalhePessoaDataDe').value = '';
            document.getElementById('detalhePessoaDataAte').value = '';

            renderizarDetalhePessoa(detalhePessoaLinhasCache);
            abrirModal('modalDetalhePessoa');
        }

        // Renderiza a lista de lançamentos da pessoa (já filtrada por data, ou completa)
        function renderizarDetalhePessoa(lista) {
            const tbody = document.getElementById('detalhePessoaListaCorpo');

            if (lista.length === 0) {
                tbody.innerHTML = `<tr><td colspan="3" class="text-center py-6 text-slate-400 italic">Nenhum lançamento nesse período.</td></tr>`;
            } else {
                tbody.innerHTML = lista.map(l => `
                    <tr class="hover:bg-slate-50/80 transition">
                        <td class="p-2.5 whitespace-nowrap">${l.dataLabel}</td>
                        <td class="p-2.5 text-center capitalize">${l.setor}</td>
                        <td class="p-2.5 text-right font-bold">${l.quantidade} ${l.medida}</td>
                    </tr>
                `).join('');
            }

            const totaisPorMedida = {};
            lista.forEach(l => {
                totaisPorMedida[l.medida] = (totaisPorMedida[l.medida] || 0) + l.quantidade;
            });
            const totalTexto = Object.entries(totaisPorMedida)
                .map(([medida, total]) => `${parseFloat(total.toFixed(2))} ${medida}`)
                .join(' + ') || '0';

            document.getElementById('detalhePessoaTotalValor').textContent = totalTexto;

            const de = document.getElementById('detalhePessoaDataDe').value;
            const ate = document.getElementById('detalhePessoaDataAte').value;
            document.getElementById('detalhePessoaTotalLabel').textContent =
                (de || ate) ? 'Total no período filtrado' : 'Total geral';
        }

        // Filtra os lançamentos da pessoa pelo intervalo de datas selecionado
        function filtrarDetalhePessoaPorData() {
            const de = document.getElementById('detalhePessoaDataDe').value; // AAAA-MM-DD ou ''
            const ate = document.getElementById('detalhePessoaDataAte').value; // AAAA-MM-DD ou ''

            const filtrados = detalhePessoaLinhasCache.filter(l => {
                const dataISO = extrairDataISO(l);
                if (!dataISO) return true; // não descarta registros sem data reconhecível
                if (de && dataISO < de) return false;
                if (ate && dataISO > ate) return false;
                return true;
            });

            renderizarDetalhePessoa(filtrados);
        }

        // Limpa o filtro de data e volta a mostrar todos os lançamentos da pessoa
        function limparFiltroDataPessoa() {
            document.getElementById('detalhePessoaDataDe').value = '';
            document.getElementById('detalhePessoaDataAte').value = '';
            renderizarDetalhePessoa(detalhePessoaLinhasCache);
        }


        // Filtra a lista com base no que é digitado no input de busca
        function filtrarTabelaMedia() {
            const termo = document.getElementById('inputBuscaMedia').value.toLowerCase().trim();

            const filtrados = dadosMediaCache.filter(p => {
                const nome = p.nome.toLowerCase();
                const codigo = p.codigo.toLowerCase();
                return nome.includes(termo) || codigo.includes(termo);
            });

            renderizarTabelaMedia(filtrados);
        }

        // ============================================================
        // Modal "Controle de Estoque" — lista geral de produtos, com
        // atalhos para Média de Saída, Importação, ver saídas de um
        // produto, editar seu estoque e montar o resumo do dia.
        // ============================================================

        function abrirModalControleEstoque() {
            abrirModal('modalControleEstoque');
            document.getElementById('inputBuscaControleEstoque').value = '';
            carregarControleEstoque();
        }

        async function carregarControleEstoque() {
            const tbody = document.getElementById('tabelaControleEstoqueCorpo');
            tbody.innerHTML = `<tr><td colspan="3" class="text-center py-6 text-slate-400 italic">Carregando produtos...</td></tr>`;

            try {
                const [resProdutos, resConsumo] = await Promise.all([
                    fetch('/api/buscar_produto_editar?termo='),
                    fetch('/api/historico_consumo_geral')
                ]);
                const dadosProdutos = await resProdutos.json();
                const dadosConsumo = await resConsumo.json();

                controleEstoqueRegistrosCache = dadosConsumo.registros || [];

                controleEstoqueProdutosCache = (dadosProdutos.produtos || [])
                    .slice()
                    .sort((a, b) => (a.nome || '').localeCompare(b.nome || '', 'pt-BR', { sensitivity: 'base' }));

                renderizarListaControleEstoque(controleEstoqueProdutosCache);
                renderizarResumoDiario();
            } catch (e) {
                console.error(e);
                tbody.innerHTML = `<tr><td colspan="3" class="text-center py-6 text-red-500 italic">Erro ao carregar os produtos.</td></tr>`;
            }
        }

        function filtrarListaControleEstoque() {
            const termo = normalizarBusca(document.getElementById('inputBuscaControleEstoque').value.trim());
            const filtrados = termo.length > 0
                ? controleEstoqueProdutosCache.filter(p =>
                    normalizarBusca(p.nome || '').includes(termo) ||
                    normalizarBusca(String(p.codigo_barras || '')).includes(termo))
                : controleEstoqueProdutosCache;
            renderizarListaControleEstoque(filtrados);
        }

        function renderizarListaControleEstoque(lista) {
            const tbody = document.getElementById('tabelaControleEstoqueCorpo');
            controleEstoqueListaAtual = lista; // guarda o que está visível agora (respeitando o filtro) p/ o "marcar todos"

            if (lista.length === 0) {
                tbody.innerHTML = `<tr><td colspan="3" class="text-center py-6 text-slate-400 italic">Nenhum produto encontrado.</td></tr>`;
                atualizarCheckboxMarcarTodos();
                return;
            }

            tbody.innerHTML = lista.map(p => {
                const cod = String(p.codigo_barras || '');
                const marcado = controleEstoqueSelecionados.has(cod);
                const estoque = (parseFloat(p.estoque_atual) || 0);
                const medida = p.tipo_medida || 'un';
                return `
                    <tr class="hover:bg-slate-50/80 transition">
                        <td class="p-3 text-center" onclick="event.stopPropagation()">
                            <input type="checkbox" ${marcado ? 'checked' : ''}
                                onchange="toggleSelecaoControleEstoque('${cod.replace(/'/g, "\\'")}', this.checked)"
                                class="w-4 h-4 accent-emerald-600 cursor-pointer">
                        </td>
                        <td class="p-3 cursor-pointer select-none" onclick="abrirSubmenuProdutoControle('${cod.replace(/'/g, "\\'")}')">
                            <span class="font-bold text-slate-900 block">${(p.nome || '').toUpperCase()}</span>
                            <span class="text-[10px] text-indigo-700 font-extrabold">COD: ${cod}</span>
                        </td>
                        <td class="p-3 text-center font-extrabold text-slate-700 cursor-pointer select-none" onclick="abrirSubmenuProdutoControle('${cod.replace(/'/g, "\\'")}')">
                            ${estoque} ${medida}
                        </td>
                    </tr>
                `;
            }).join('');

            atualizarCheckboxMarcarTodos();
        }

        // Marca (ou desmarca) todos os itens ATUALMENTE FILTRADOS de uma vez. A seleção
        // é guardada por código de produto, então limpar/trocar o filtro depois não afeta
        // quem já foi marcado — só some da lista quando o próprio checkbox é desmarcado.
        function toggleMarcarTodosFiltrados(marcarTodos) {
            controleEstoqueListaAtual.forEach(p => {
                const cod = String(p.codigo_barras || '');
                if (marcarTodos) {
                    controleEstoqueSelecionados.add(cod);
                } else {
                    controleEstoqueSelecionados.delete(cod);
                }
            });
            renderizarListaControleEstoque(controleEstoqueListaAtual);
            renderizarResumoDiario();
        }

        // Sincroniza o checkbox "marcar todos" com o que está selecionado dentro do filtro atual
        // (fica marcado só quando 100% dos itens visíveis já estão marcados).
        function atualizarCheckboxMarcarTodos() {
            const checkbox = document.getElementById('checkboxMarcarTodosFiltrados');
            const label = document.getElementById('labelMarcarTodosFiltrados');
            if (!checkbox) return;

            const total = controleEstoqueListaAtual.length;
            const marcados = controleEstoqueListaAtual.filter(p => controleEstoqueSelecionados.has(String(p.codigo_barras || ''))).length;

            checkbox.disabled = total === 0;
            checkbox.checked = total > 0 && marcados === total;
            checkbox.indeterminate = marcados > 0 && marcados < total;

            if (label) {
                label.textContent = total === 0
                    ? 'Marcar todos os itens filtrados'
                    : `Marcar todos os itens filtrados (${marcados}/${total})`;
            }
        }

        // Atualiza o estoque_atual de um produto já carregado na lista (evita refazer o fetch inteiro)
        function atualizarEstoqueNaListaControle(codigo, novoValor) {
            const p = controleEstoqueProdutosCache.find(item => String(item.codigo_barras) === String(codigo));
            if (!p) return;
            p.estoque_atual = novoValor;
            if (document.getElementById('modalControleEstoque') && !document.getElementById('modalControleEstoque').classList.contains('hidden')) {
                filtrarListaControleEstoque();
            }
        }

        // --- Submodal-menu: abre ao clicar em um produto na lista ---
        function abrirSubmenuProdutoControle(codigo) {
            const p = controleEstoqueProdutosCache.find(item => String(item.codigo_barras) === String(codigo));
            if (!p) return;
            produtoControleAtual = p;

            document.getElementById('submenuProdutoNome').textContent = (p.nome || '').toUpperCase();
            const estoque = (parseFloat(p.estoque_atual) || 0);
            document.getElementById('submenuProdutoInfo').textContent =
                `COD: ${p.codigo_barras} · estoque atual: ${estoque} ${p.tipo_medida || 'un'}`;

            abrirModal('submodalMenuProduto');
        }

        function editarEstoqueProdutoControle() {
            if (!produtoControleAtual) return;
            fecharModal('submodalMenuProduto');
            abrirModalEstoqueAtual(produtoControleAtual);
        }

        // --- Submodal: lista cronológica (sem agrupar) de todas as saídas do produto ---
        function abrirSaidasProdutoControle() {
            if (!produtoControleAtual) return;
            fecharModal('submodalMenuProduto');

            const codigo = produtoControleAtual.codigo_barras;
            document.getElementById('saidasProdutoNome').textContent = (produtoControleAtual.nome || '').toUpperCase();
            document.getElementById('saidasProdutoCod').textContent = `COD: ${codigo}`;

            const linhas = [];
            controleEstoqueRegistrosCache.forEach(registro => {
                if (!registro.itens || !Array.isArray(registro.itens)) return;
                registro.itens.forEach(item => {
                    const cod = item.codigo_barras || item.codigo || 'S/COD';
                    if (String(cod) !== String(codigo)) return;

                    let dataLabel = '-';
                    if (registro.dias_periodo && Array.isArray(registro.dias_periodo) && registro.dias_periodo.length > 0) {
                        dataLabel = `Período: ${registro.dias_periodo[0]} a ${registro.dias_periodo[registro.dias_periodo.length - 1]}`;
                    } else if (registro.data_hora) {
                        dataLabel = registro.data_hora;
                    } else if (registro.data) {
                        dataLabel = registro.data;
                    }

                    const clienteBruto = (registro.cliente || '').trim();
                    const clienteExibicao = (!clienteBruto || /^sem cliente/i.test(clienteBruto)) ? '-' : clienteBruto;

                    linhas.push({
                        dataLabel,
                        dataOrdenacao: registro.data_hora || registro.data || '',
                        profissional: registro.profissional || '-',
                        cliente: clienteExibicao,
                        setor: registro.setor || '-',
                        quantidade: parseFloat(item.quantidade) || 0,
                        medida: item.tipo_medida || 'un'
                    });
                });
            });

            // Ordem cronológica, mais recente primeiro
            linhas.sort((a, b) => (b.dataOrdenacao || '').localeCompare(a.dataOrdenacao || ''));

            const tbody = document.getElementById('saidasProdutoListaCorpo');
            if (linhas.length === 0) {
                tbody.innerHTML = `<tr><td colspan="5" class="text-center py-6 text-slate-400 italic">Nenhuma saída registrada para este produto.</td></tr>`;
            } else {
                tbody.innerHTML = linhas.map(l => `
                    <tr class="hover:bg-slate-50/80 transition">
                        <td class="p-2.5 whitespace-nowrap">${l.dataLabel}</td>
                        <td class="p-2.5 font-bold">${l.profissional}</td>
                        <td class="p-2.5">${l.cliente}</td>
                        <td class="p-2.5 text-center capitalize">${l.setor}</td>
                        <td class="p-2.5 text-right font-black text-indigo-600">${l.quantidade} ${l.medida}</td>
                    </tr>
                `).join('');
            }

            abrirModal('modalSaidasProduto');
        }

        // --- Resumo do dia (produtos marcados com checkbox na lista) ---

        function hojeISO() {
            const d = new Date();
            const yyyy = d.getFullYear();
            const mm = String(d.getMonth() + 1).padStart(2, '0');
            const dd = String(d.getDate()).padStart(2, '0');
            return `${yyyy}-${mm}-${dd}`;
        }

        function toggleSelecaoControleEstoque(codigo, marcado) {
            if (marcado) {
                controleEstoqueSelecionados.add(codigo);
            } else {
                controleEstoqueSelecionados.delete(codigo);
            }
            atualizarCheckboxMarcarTodos();
            renderizarResumoDiario();
        }

        function limparSelecaoResumoDiario() {
            controleEstoqueSelecionados.clear();
            renderizarResumoDiario();
            filtrarListaControleEstoque();
            fecharModal('modalResumoDiario');
        }

        // Devolve, por produto, cada lançamento de HOJE (data, hora, profissional, cliente),
        // ignorando registros de importação em lote (que representam um período/semana,
        // não um dia específico). codigo -> { medida, lancamentos: [...] }
        function calcularConsumoHojePorProduto() {
            const hoje = hojeISO();
            const mapa = {};

            controleEstoqueRegistrosCache.forEach(registro => {
                if (registro.dias_periodo && Array.isArray(registro.dias_periodo) && registro.dias_periodo.length > 0) return;

                const dataHoraBruta = registro.data_hora || registro.data || '';
                const dataBruta = String(dataHoraBruta).split(' ')[0];
                const iso = normalizarDataISO(dataBruta);
                if (iso !== hoje) return;

                const partesHora = String(dataHoraBruta).split(' ');
                const horario = partesHora.length > 1 ? partesHora[1].slice(0, 5) : '';

                const clienteBruto = (registro.cliente || '').trim();
                const clienteExibicao = (!clienteBruto || /^sem cliente/i.test(clienteBruto)) ? '' : clienteBruto;

                if (!registro.itens || !Array.isArray(registro.itens)) return;
                registro.itens.forEach(item => {
                    const cod = String(item.codigo_barras || item.codigo || 'S/COD');
                    const qtd = parseFloat(item.quantidade) || 0;
                    const medida = item.tipo_medida || 'un';
                    if (!mapa[cod]) mapa[cod] = { medida, lancamentos: [] };
                    mapa[cod].lancamentos.push({
                        horario,
                        profissional: registro.profissional || '-',
                        cliente: clienteExibicao,
                        quantidade: qtd
                    });
                });
            });

            // Lançamentos de cada produto em ordem cronológica (mais cedo primeiro)
            Object.values(mapa).forEach(info => {
                info.lancamentos.sort((a, b) => a.horario.localeCompare(b.horario));
            });

            return mapa;
        }

        // Só liga/desliga o botão de acesso ao resumo (o conteúdo é montado ao abrir o modal)
        function renderizarResumoDiario() {
            const botaoArea = document.getElementById('resumoDiarioBotaoArea');
            const contador = document.getElementById('resumoDiarioContador');
            if (!botaoArea) return;

            if (controleEstoqueSelecionados.size === 0) {
                botaoArea.classList.add('hidden');
                return;
            }

            if (contador) {
                contador.textContent = `${controleEstoqueSelecionados.size} marcado${controleEstoqueSelecionados.size === 1 ? '' : 's'}`;
            }
            botaoArea.classList.remove('hidden');
        }

        // Abre o modal do resumo: só mostra produtos marcados que TIVERAM saída hoje,
        // cada um com sua lista de lançamentos (horário, profissional, cliente).
        function abrirModalResumoDiario() {
            const corpo = document.getElementById('resumoDiarioModalCorpo');
            const consumoHoje = calcularConsumoHojePorProduto();
            const hoje = new Date();
            document.getElementById('resumoDiarioModalData').textContent =
                `Consumo de ${hoje.toLocaleDateString('pt-BR')}`;

            const selecionados = controleEstoqueProdutosCache.filter(p => controleEstoqueSelecionados.has(String(p.codigo_barras)));
            const comSaidaHoje = selecionados
                .map(p => ({ produto: p, info: consumoHoje[String(p.codigo_barras)] }))
                .filter(x => x.info && x.info.lancamentos.length > 0);

            if (comSaidaHoje.length === 0) {
                corpo.innerHTML = `<p class="text-center py-6 text-slate-400 italic text-xs">Nenhum dos produtos marcados teve saída hoje.</p>`;
            } else {
                corpo.innerHTML = comSaidaHoje.map(({ produto, info }) => {
                    const nomeProduto = (produto.nome || '').toUpperCase();

                    // Só 1 saída: mostra tudo numa linha só, sem repetir o total embaixo
                    if (info.lancamentos.length === 1) {
                        const l = info.lancamentos[0];
                        const quemTexto = l.cliente
                            ? `${l.profissional} <span class="text-slate-400">→</span> ${l.cliente}`
                            : l.profissional;
                        return `
                            <div class="bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-1.5 flex items-center justify-between gap-2">
                                <div class="min-w-0 leading-tight">
                                    <span class="font-black text-slate-900 text-[11px] uppercase block truncate">${nomeProduto}</span>
                                    <span class="text-[10px] text-slate-600"><span class="font-bold text-slate-700">${l.horario || '--:--'}</span> &middot; ${quemTexto}</span>
                                </div>
                                <span class="text-[11px] font-black text-emerald-800 whitespace-nowrap">${l.quantidade} ${info.medida}</span>
                            </div>
                        `;
                    }

                    // Mais de 1 saída: mostra o total no topo e cada lançamento embaixo
                    const totalProduto = info.lancamentos.reduce((soma, l) => soma + l.quantidade, 0);
                    const linhasHtml = info.lancamentos.map(l => {
                        const quemTexto = l.cliente
                            ? `${l.profissional} <span class="text-slate-400">→</span> ${l.cliente}`
                            : l.profissional;
                        return `
                            <div class="flex items-center justify-between py-0.5 border-t border-emerald-100 first:border-t-0 first:pt-1">
                                <span class="text-[10px] text-slate-600"><span class="font-bold text-slate-700">${l.horario || '--:--'}</span> &middot; ${quemTexto}</span>
                                <span class="text-[10px] font-bold text-emerald-700 whitespace-nowrap">${l.quantidade} ${info.medida}</span>
                            </div>
                        `;
                    }).join('');

                    return `
                        <div class="bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-1.5">
                            <div class="flex items-center justify-between leading-tight">
                                <span class="font-black text-slate-900 text-[11px] uppercase">${nomeProduto}</span>
                                <span class="font-black text-emerald-800 text-[11px]">${totalProduto} ${info.medida}</span>
                            </div>
                            <div>${linhasHtml}</div>
                        </div>
                    `;
                }).join('');
            }

            abrirModal('modalResumoDiario');
        }

        // Abre o modal de importação em lote
        function abrirModalNotasLote() {
            const modal = document.getElementById('modalNotasLote');
            if (modal) {
                modal.classList.remove('hidden');
                modal.classList.add('flex'); // Garante que exiba com flexbox do Tailwind
            } else {
                console.error("Elemento 'modalNotasLote' não foi encontrado no HTML.");
                return;
            }

            document.getElementById('containerBlocosSemanas').innerHTML = `
                <div class="text-center py-12 text-slate-400 italic text-xs">
                    Selecione os arquivos PDF dos últimos 3 meses acima e clique em "Ler Notas Selecionadas".
                </div>
            `;
        }

        // Fecha o modal de importação em lote
        function fecharModalNotasLote() {
            const modal = document.getElementById('modalNotasLote');
            if (modal) {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
            }
        }

        // Envia múltiplos arquivos PDF para o backend processar
        async function enviarNotasParaProcessar() {
            const inputFiles = document.getElementById('inputArquivosPDF');
            if (!inputFiles.files || inputFiles.files.length === 0) {
                mostrarAlerta("Selecione pelo menos um arquivo de planilha (.xlsx).", 'aviso');
                return;
            }

            const formData = new FormData();
            for (let i = 0; i < inputFiles.files.length; i++) {
                formData.append('pdfs', inputFiles.files[i]); // Mantém a chave 'pdfs' que o Flask já está escutando
            }

            const container = document.getElementById('containerBlocosSemanas');
            container.innerHTML = `<div class="text-center py-12 text-indigo-600 font-bold italic text-xs">Lendo e agrupando o arquivo... Aguarde.</div>`;

            try {
                const response = await fetch('/api/processar_notas_multiplas', {
                    method: 'POST',
                    body: formData
                });
                const resultado = await response.json();

                if (resultado.sucesso && resultado.itens && resultado.itens.length > 0) {
                    renderizarBlocosSemanais(resultado.itens);
                    if (resultado.erros && resultado.erros.length > 0) {
                        console.warn('Avisos ao importar:', resultado.erros);
                    }
                } else {
                    const listaErros = (resultado.erros && resultado.erros.length > 0)
                        ? `<ul class="text-left text-red-500 mt-2 list-disc pl-5">${resultado.erros.map(e => `<li>${e}</li>`).join('')}</ul>`
                        : '';
                    container.innerHTML = `<div class="text-center py-12 text-slate-400 italic text-xs">Nenhum item válido foi encontrado no arquivo enviado.${listaErros}</div>`;
                }
            } catch (e) {
                console.error(e);
                container.innerHTML = `<div class="text-center py-12 text-red-500 font-bold italic text-xs">Erro de conexão ao processar o arquivo.</div>`;
            }
        }

        // Função para agrupar os itens extraídos por semana
        function agruparItensPorSemana(itens) {
            const semanas = {};

            itens.forEach(item => {
                const dataObj = new Date(item.data + 'T00:00:00');
                const primeiroDiaDoAno = new Date(dataObj.getFullYear(), 0, 1);
                const diasPassados = Math.floor((dataObj - primeiroDiaDoAno) / (24 * 60 * 60 * 1000));
                const numeroSemana = Math.ceil((diasPassados + primeiroDiaDoAno.getDay() + 1) / 7);
                
                const chaveSemana = `Semana ${numeroSemana} (${dataObj.getFullYear()})`;

                if (!semanas[chaveSemana]) {
                    semanas[chaveSemana] = [];
                }
                semanas[chaveSemana].push(item);
            });

            return semanas;
        }

        // Desenha os blocos semanais isolados na tela
        function renderizarBlocosSemanais(itensDoBackend) {
            const container = document.getElementById('containerBlocosSemanas');
            container.innerHTML = '';

            const semanasAgrupadas = agruparItensPorSemana(itensDoBackend);

            Object.keys(semanasAgrupadas).forEach((nomeSemana, index) => {
                const itensDaSemana = semanasAgrupadas[nomeSemana];

                let htmlItens = '';
                itensDaSemana.forEach((item, itemIndex) => {
                    htmlItens += `
                        <tr class="hover:bg-slate-50 linha-item-semana-${index}" data-filtro-nome="${item.nome.toLowerCase()}">
                            <td class="p-2.5 text-center">
                                <input type="checkbox" class="checkbox-semana-${index}" value="${itemIndex}" data-nome="${item.nome}" data-data="${item.data}" data-item-id="${item.id || ''}" data-quantidade="${item.quantidade}" onchange="atualizarSomaQtdSemana(${index})">
                            </td>
                            <td class="p-2.5 text-slate-600 font-bold">${item.data.split('-').reverse().join('/')}</td>
                            <td class="p-2.5 text-slate-800 uppercase cursor-pointer hover:text-indigo-700 hover:underline" title="Clique para marcar este mesmo item em TODAS as semanas de uma vez" onclick="selecionarNomeEmTodasSemanas('${String(item.nome).replace(/'/g, "\\'")}')">🔗 ${item.nome}</td>
                            <td class="p-2.5 text-center font-bold">${item.quantidade}</td>
                        </tr>
                    `;
                });

                // Cria o card isolado para a semana
                const blocoHtml = `
                    <div class="border border-slate-200 rounded-xl overflow-hidden bg-slate-50/50 shadow-sm mb-4">
                        <div class="bg-slate-100 p-3 border-b border-slate-200 flex justify-between items-center">
                            <span class="text-xs font-black text-slate-800 uppercase">📅 ${nomeSemana}</span>
                            <span id="contadorSemana_${index}" class="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-1 rounded-lg">${itensDaSemana.length} itens encontrados</span>
                        </div>
                        
                        <div class="p-3">
                            <!-- Controles exclusivos desta semana (Garante o bloqueio entre semanas) -->
                            <div class="flex gap-2 items-center mb-3 bg-white p-2.5 rounded-lg border border-slate-200 relative">
                                <div class="relative flex-1">
                                    <input type="text"
                                           id="buscaProdutoOficial_${index}"
                                           placeholder="Buscar produto oficial do estoque (nome ou código)..."
                                           autocomplete="off"
                                           oninput="buscarProdutoOficial(${index}, this.value)"
                                           onfocus="buscarProdutoOficial(${index}, this.value)"
                                           class="text-xs border border-slate-300 rounded-lg p-1.5 bg-white font-bold w-full">
                                    <input type="hidden" id="hiddenProdutoOficial_${index}" value="">
                                    <div id="sugestoesProduto_${index}" class="hidden absolute z-20 left-0 right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-48 overflow-y-auto"></div>
                                </div>
                                <button type="button" onclick="editarProdutoSelecionadoParaVincular(${index})" title="Editar produto selecionado" class="text-sm border border-slate-300 rounded-lg px-2.5 py-1.5 bg-white hover:bg-slate-50 shadow-sm">✏️</button>
                                <div class="flex flex-col">
                                    <input type="number" id="inputQtdReal_${index}" placeholder="Qtd p/ Estoque" title="Soma automática dos itens marcados — pode editar se precisar ajustar" class="text-xs border border-slate-300 rounded-lg p-1.5 w-24 font-bold text-center">
                                    <span class="text-[9px] text-slate-400 font-bold text-center">soma automática</span>
                                </div>
                                <div class="flex flex-col">
                                    <select id="modoEnvio_${index}" onchange="atualizarLabelBotaoVincular(${index})" title="Rota de envio: gerar estoque ou só registrar no consumo mensal" class="text-xs border border-slate-300 rounded-lg p-1.5 bg-white font-bold">
                                        <option value="estoque">📦 Gerar estoque</option>
                                        <option value="consumo">🧾 Só consumo mensal</option>
                                    </select>
                                    <span class="text-[9px] text-slate-400 font-bold text-center">rota dos dados</span>
                                </div>
                                <button id="btnVincular_${index}" onclick="vincularItensSemana(${index})" class="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm whitespace-nowrap">Somar ao Estoque</button>
                            </div>

                            <!-- Filtro inteligente dos itens desta semana -->
                            <div class="mb-2">
                                <input type="text"
                                       placeholder="🔎 Filtrar itens desta semana por nome..."
                                       oninput="filtrarItensSemana(${index}, this.value)"
                                       class="text-xs border border-slate-200 rounded-lg p-1.5 w-full bg-slate-50">
                            </div>

                            <!-- Tabela isolada -->
                            <table class="w-full text-left border-collapse bg-white rounded-lg overflow-hidden border border-slate-200">
                                <thead class="bg-slate-50 text-[10px] font-black text-slate-500 uppercase">
                                    <tr>
                                        <th class="p-2.5 w-10 text-center"><input type="checkbox" onclick="toggleTodosSemana(this, ${index})"></th>
                                        <th class="p-2.5">Data da Nota</th>
                                        <th class="p-2.5">Nome Divergente na Nota</th>
                                        <th class="p-2.5 text-center">Qtd Nota</th>
                                    </tr>
                                </thead>
                                <tbody class="text-xs divide-y divide-slate-100" id="tbodySemana_${index}">
                                    ${htmlItens}
                                </tbody>
                            </table>
                        </div>
                    </div>
                `;

                container.insertAdjacentHTML('beforeend', blocoHtml);
            });
        }

        // Troca o texto do botão de acordo com a rota escolhida (estoque x consumo)
        function atualizarLabelBotaoVincular(index) {
            const select = document.getElementById(`modoEnvio_${index}`);
            const botao = document.getElementById(`btnVincular_${index}`);
            if (!select || !botao) return;
            botao.innerText = select.value === 'consumo' ? 'Registrar no Consumo' : 'Somar ao Estoque';
        }

        // Filtra visualmente as linhas de itens de uma semana pelo nome digitado
        function filtrarItensSemana(index, termo) {
            const termoNorm = termo.trim().toLowerCase();
            const linhas = document.querySelectorAll(`.linha-item-semana-${index}`);
            linhas.forEach(linha => {
                const nomeLinha = linha.getAttribute('data-filtro-nome') || '';
                linha.style.display = nomeLinha.includes(termoNorm) ? '' : 'none';
            });
        }

        // Busca inteligente de produtos oficiais do estoque (debounced), usando a API existente /api/buscar_produto
        const _timersBuscaProduto = {};
        function buscarProdutoOficial(index, termo) {
            clearTimeout(_timersBuscaProduto[index]);
            const sugestoesEl = document.getElementById(`sugestoesProduto_${index}`);

            // Limpa a seleção anterior se o usuário editar o texto manualmente
            const hiddenEl = document.getElementById(`hiddenProdutoOficial_${index}`);
            if (hiddenEl) hiddenEl.value = '';

            if (!termo || termo.trim().length < 1) {
                sugestoesEl.classList.add('hidden');
                sugestoesEl.innerHTML = '';
                return;
            }

            _timersBuscaProduto[index] = setTimeout(async () => {
                try {
                    const resp = await fetch(`/api/buscar_produto?termo=${encodeURIComponent(termo.trim())}`);
                    const resultado = await resp.json();
                    const produtos = (resultado.sucesso && resultado.produtos) ? resultado.produtos : [];
                    const termoDigitado = termo.trim();
                    const termoEscapado = termoDigitado.replace(/'/g, "\\'");

                    let html = '';
                    if (produtos.length === 0) {
                        html += `<div class="p-2 text-slate-400 italic text-xs">Nenhum produto encontrado.</div>`;
                    } else {
                        // Usa aspas simples pra "index" no HTML gerado, tanto pra índice
                        // numérico de semana quanto pra 'GLOBAL' (lote) — o atributo
                        // onclick já é delimitado com aspas duplas, então tem que ser
                        // aspas simples aqui dentro (JSON.stringify gera aspas duplas
                        // e quebrava o atributo).
                        html += produtos.map(p => `
                            <div class="p-2 text-xs hover:bg-indigo-50 cursor-pointer border-b border-slate-100 last:border-0"
                                 onclick="selecionarProdutoOficial('${index}', '${String(p.codigo_barras).replace(/'/g, "\\'")}', '${String(p.nome).replace(/'/g, "\\'")}')">
                                <span class="font-bold uppercase">${p.nome}</span>
                                <span class="text-slate-400"> — Cód: ${p.codigo_barras} (${p.tipo_medida || 'un'})</span>
                            </div>
                        `).join('');
                    }

                    // Sempre oferece a opção de cadastrar como produto novo — cobre o
                    // caso do código/nome nunca ter sido registrado antes.
                    html += `
                        <div class="p-2 text-xs text-indigo-600 font-bold hover:bg-indigo-50 cursor-pointer border-t border-slate-200"
                             onclick="abrirModalNovoProdutoParaVincular('${index}', '${termoEscapado}')">
                            ➕ Cadastrar "${termoDigitado}" como novo produto
                        </div>
                    `;

                    sugestoesEl.innerHTML = html;
                    sugestoesEl.classList.remove('hidden');
                } catch (e) {
                    console.error(e);
                    sugestoesEl.innerHTML = `<div class="p-2 text-red-500 text-xs">Erro ao buscar produtos.</div>`;
                    sugestoesEl.classList.remove('hidden');
                }
            }, 250);
        }

        // Confirma a seleção de um produto oficial vindo da lista de sugestões
        function selecionarProdutoOficial(index, codigoBarras, nome) {
            const inputBusca = document.getElementById(`buscaProdutoOficial_${index}`);
            const hiddenEl = document.getElementById(`hiddenProdutoOficial_${index}`);
            const sugestoesEl = document.getElementById(`sugestoesProduto_${index}`);

            if (inputBusca) inputBusca.value = nome;
            if (hiddenEl) hiddenEl.value = codigoBarras;
            if (sugestoesEl) {
                sugestoesEl.classList.add('hidden');
                sugestoesEl.innerHTML = '';
            }
        }

        // Botão de editar (✏️) ao lado da busca: puxa os dados completos do
        // produto já selecionado para esta semana e abre o modal de edição,
        // preenchido, sem precisar ir até a aba de Gerenciamento.
        async function editarProdutoSelecionadoParaVincular(index) {
            const hiddenEl = document.getElementById(`hiddenProdutoOficial_${index}`);
            const codigo = hiddenEl ? hiddenEl.value : '';

            if (!codigo) {
                mostrarAlerta("⚠️ Primeiro busque e selecione um produto oficial para poder editá-lo.", 'aviso');
                return;
            }

            try {
                const resp = await fetch(`/api/buscar_produto?termo=${encodeURIComponent(codigo)}`);
                const resultado = await resp.json();
                const produtos = (resultado.sucesso && resultado.produtos) ? resultado.produtos : [];
                const produto = produtos.find(p => String(p.codigo_barras) === String(codigo));

                if (!produto) {
                    mostrarAlerta("⚠️ Não encontrei os dados completos deste produto para editar.", 'aviso');
                    return;
                }

                _origemModalEdicao = { tipo: 'vincular', index: index };

                const submodal = document.getElementById('submodalEdicao');
                if (!submodal) return;
                submodal.classList.remove('hidden');
                submodal.classList.add('flex');

                document.getElementById('editNome').value = produto.nome || '';
                document.getElementById('editTipoItem').value = 'produto';
                document.getElementById('editCodigo').value = produto.codigo_barras || '';
                document.getElementById('editMedida').value = produto.tipo_medida || 'un';
                document.getElementById('editId').value = produto.codigo_barras || '';
                document.getElementById('editEmbalagem').value = produto.tamanho_embalagem || '';
                toggleCampoEmbalagem('edit');

                document.getElementById('grupoCodigoBarras').classList.remove('hidden');
                document.getElementById('grupoTipoMedida').classList.remove('hidden');
                document.getElementById('grupoSetor').classList.add('hidden');
                document.getElementById('tituloSubmodal').innerText = 'Editar Produto';
            } catch (e) {
                console.error(e);
                mostrarAlerta("Erro de conexão ao buscar dados do produto.", 'erro');
            }
        }

        // Fecha as sugestões ao clicar fora do campo de busca
        document.addEventListener('click', function(e) {
            document.querySelectorAll('[id^="sugestoesProduto_"]').forEach(el => {
                const index = el.id.replace('sugestoesProduto_', '');
                const inputBusca = document.getElementById(`buscaProdutoOficial_${index}`);
                if (e.target !== inputBusca && !el.contains(e.target)) {
                    el.classList.add('hidden');
                }
            });
        });

        // Selecionar/Deselecionar todos os checkboxes de uma semana específica
        function toggleTodosSemana(master, index) {
            const checkboxes = document.querySelectorAll(`.checkbox-semana-${index}`);
            checkboxes.forEach(cb => cb.checked = master.checked);
            atualizarSomaQtdSemana(index);
        }

        // Soma automaticamente a quantidade de todos os itens marcados (checkbox)
        // desta semana e joga o resultado no campo "Qtd Real" — assim não precisa
        // mais somar na mão pra saber o valor real a importar. O campo continua
        // editável manualmente, caso precise ajustar (ex: arredondar embalagem).
        function atualizarSomaQtdSemana(index) {
            const checkboxesMarcados = document.querySelectorAll(`.checkbox-semana-${index}:checked`);
            let soma = 0;
            checkboxesMarcados.forEach(cb => {
                soma += parseFloat(cb.getAttribute('data-quantidade')) || 0;
            });

            const inputQtd = document.getElementById(`inputQtdReal_${index}`);
            if (inputQtd) {
                // Evita mostrar "12.000000000000002" por causa de soma de floats,
                // mas preserva casas decimais reais (ex: 1.5kg, 250ml, etc).
                const somaArredondada = Math.round(soma * 1000) / 1000;
                inputQtd.value = somaArredondada > 0 ? somaArredondada : '';
            }
        }

        // --- VÍNCULO EM LOTE: mesmo produto repetido em várias semanas de uma vez ---
        // Guarda quais semanas foram marcadas pela última seleção "em lote", pra
        // saber quais delas devem ser enviadas quando o botão de lote for clicado.
        let _loteSemanasAfetadas = [];

        // Clicando no nome de um item (🔗) marca automaticamente todo item com esse
        // MESMO nome em TODAS as semanas visíveis, e abre o painel pra escolher o
        // produto oficial só uma vez. Cada semana continua sendo um lançamento
        // separado no histórico — só a busca do produto e o clique são feitos 1x.
        function selecionarNomeEmTodasSemanas(nome) {
            const nomeNorm = nome.trim().toLowerCase();
            const semanasAfetadas = new Set();
            let totalMarcados = 0;

            document.querySelectorAll('input[type="checkbox"][data-nome]').forEach(cb => {
                if ((cb.getAttribute('data-nome') || '').trim().toLowerCase() === nomeNorm) {
                    cb.checked = true;
                    totalMarcados++;
                    const m = cb.className.match(/checkbox-semana-(\d+)/);
                    if (m) semanasAfetadas.add(m[1]);
                }
            });

            // Recalcula a soma automática de cada semana afetada
            semanasAfetadas.forEach(idx => atualizarSomaQtdSemana(idx));

            _loteSemanasAfetadas = Array.from(semanasAfetadas);

            const painel = document.getElementById('painelLoteGlobal');
            const label = document.getElementById('loteNomeAtivoLabel');
            if (label) {
                label.textContent = `"${nome}" marcado em ${totalMarcados} ocorrência(s), em ${semanasAfetadas.size} semana(s). Agora busque o produto oficial abaixo e clique em vincular.`;
            }
            if (painel) {
                painel.classList.remove('hidden');
                painel.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }

        function fecharPainelLoteGlobal() {
            const painel = document.getElementById('painelLoteGlobal');
            if (painel) painel.classList.add('hidden');
            const inputBusca = document.getElementById('buscaProdutoOficial_GLOBAL');
            const hiddenEl = document.getElementById('hiddenProdutoOficial_GLOBAL');
            if (inputBusca) inputBusca.value = '';
            if (hiddenEl) hiddenEl.value = '';
            _loteSemanasAfetadas = [];
        }

        // Troca o texto do botão do lote de acordo com a rota escolhida (estoque x consumo)
        function atualizarLabelBotaoLote() {
            const select = document.getElementById('modoEnvio_GLOBAL');
            const botao = document.getElementById('btnVincularLote');
            if (!select || !botao) return;
            botao.innerText = select.value === 'consumo'
                ? '🚀 Registrar no consumo em todas as semanas marcadas'
                : '🚀 Somar ao estoque em todas as semanas marcadas';
        }

        // Envia, de uma vez só, um lançamento por semana afetada — o backend cria
        // um registro de histórico SEPARADO para cada semana (preservando os
        // "dias_periodo" de cada uma), então a lógica de média semanal continua
        // exatamente igual a fazer semana por semana na mão.
        async function vincularLoteEmTodasSemanas() {
            const hiddenProdGlobal = document.getElementById('hiddenProdutoOficial_GLOBAL');
            const produtoOficialId = hiddenProdGlobal ? hiddenProdGlobal.value : '';

            if (!produtoOficialId) {
                mostrarAlerta("⚠️ Busque e selecione o produto oficial do estoque no painel de vínculo em lote.", 'aviso');
                return;
            }

            if (_loteSemanasAfetadas.length === 0) {
                mostrarAlerta("⚠️ Nenhuma semana marcada. Clique no nome (🔗) de um item na tabela para marcar o mesmo item em todas as semanas.", 'aviso');
                return;
            }

            const selectModoGlobal = document.getElementById('modoEnvio_GLOBAL');
            const modo = selectModoGlobal ? selectModoGlobal.value : 'estoque';

            const vinculos = [];
            const semanasSemQuantidade = [];

            _loteSemanasAfetadas.forEach(index => {
                const checkboxesMarcados = document.querySelectorAll(`.checkbox-semana-${index}:checked`);
                if (checkboxesMarcados.length === 0) return; // já vinculado antes / linha removida

                const inputQtd = document.getElementById(`inputQtdReal_${index}`);
                const quantidadeReal = inputQtd ? parseFloat(inputQtd.value) : 0;

                if (!quantidadeReal || quantidadeReal <= 0) {
                    semanasSemQuantidade.push(index);
                    return;
                }

                const itensSelecionados = [];
                checkboxesMarcados.forEach(cb => {
                    itensSelecionados.push({
                        nomeDivergente: cb.getAttribute('data-nome'),
                        dataNota: cb.getAttribute('data-data'),
                        itemId: cb.getAttribute('data-item-id')
                    });
                });

                vinculos.push({
                    semanaIndex: index,
                    produtoOficialId: produtoOficialId,
                    quantidadeReal: quantidadeReal,
                    itens: itensSelecionados,
                    modo: modo
                });
            });

            if (semanasSemQuantidade.length > 0) {
                mostrarAlerta(`⚠️ Algumas semanas ficaram sem quantidade (campo "Qtd Real" vazio) e não serão enviadas agora — confira a soma automática dessas semanas antes de tentar de novo.`, 'aviso');
            }

            if (vinculos.length === 0) {
                mostrarAlerta("⚠️ Nenhuma semana com quantidade válida pra enviar.", 'aviso');
                return;
            }

            try {
                const response = await fetch('/api/injetar_historico_media_lote', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ vinculos: vinculos.map(({ semanaIndex, ...resto }) => resto) })
                });

                const resultado = await response.json();

                if (resultado.sucesso) {
                    // Remove da tela as linhas vinculadas em cada semana afetada
                    vinculos.forEach(v => {
                        const index = v.semanaIndex;
                        document.querySelectorAll(`.checkbox-semana-${index}:checked`).forEach(cb => {
                            const linha = cb.closest('tr');
                            if (linha) linha.remove();
                        });

                        const tbody = document.getElementById(`tbodySemana_${index}`);
                        const restantes = tbody ? tbody.querySelectorAll('tr').length : 0;
                        const contador = document.getElementById(`contadorSemana_${index}`);
                        if (contador) contador.innerText = `${restantes} itens restantes`;

                        if (restantes === 0) {
                            const cardBloco = tbody ? tbody.closest('.border') : null;
                            if (cardBloco) {
                                cardBloco.innerHTML = `<div class="p-4 text-center text-emerald-700 font-bold text-xs">✔ Semana totalmente somada ao estoque!</div>`;
                            }
                        } else {
                            const inputQtd = document.getElementById(`inputQtdReal_${index}`);
                            if (inputQtd) inputQtd.value = '';
                        }
                    });

                    const totalProcessadoLote = resultado.total_processado || vinculos.length;
                    const mensagemLote = modo === 'consumo'
                        ? `✅ ${totalProcessadoLote} semana(s) registrada(s) no consumo mensal (sem alterar estoque)!`
                        : `✅ ${totalProcessadoLote} semana(s) somada(s) ao estoque de uma vez!`;
                    mostrarAlerta(mensagemLote, 'sucesso');
                    fecharPainelLoteGlobal();
                    if (typeof carregarAlertaEstoque === 'function') carregarAlertaEstoque();
                } else {
                    mostrarAlerta("❌ Erro ao processar o vínculo em lote: " + (resultado.mensagem || 'Erro desconhecido.'), 'erro');
                }
            } catch (e) {
                console.error(e);
                mostrarAlerta("Erro de conexão ao enviar o lote para o servidor.", 'erro');
            }
        }

        // 2. Função que valida os checkboxes da semana, pega a quantidade real e envia para o backend injetar na média
        async function vincularItensSemana(index) {
            const hiddenProd = document.getElementById(`hiddenProdutoOficial_${index}`);
            const inputBusca = document.getElementById(`buscaProdutoOficial_${index}`);
            const inputQtd = document.getElementById(`inputQtdReal_${index}`);
            
            const produtoOficialId = hiddenProd ? hiddenProd.value : '';
            const quantidadeReal = inputQtd ? parseFloat(inputQtd.value) : 0;
            const selectModo = document.getElementById(`modoEnvio_${index}`);
            const modo = selectModo ? selectModo.value : 'estoque';

            if (!produtoOficialId) {
                mostrarAlerta("⚠️ Busque e selecione qual é o produto oficial do estoque para esta semana (clique em uma sugestão da lista).", 'aviso');
                if (inputBusca) inputBusca.focus();
                return;
            }

            if (!quantidadeReal || quantidadeReal <= 0) {
                mostrarAlerta("⚠️ Informe a quantidade a somar no estoque para estes itens.", 'aviso');
                return;
            }

            // Coleta todos os checkboxes marcados nesta semana específica
            const checkboxesMarcados = document.querySelectorAll(`.checkbox-semana-${index}:checked`);
            if (checkboxesMarcados.length === 0) {
                mostrarAlerta("⚠️ Marque pelo menos um item divergente na tabela desta semana para vincular.", 'aviso');
                return;
            }

            // Pega as informações dos itens selecionados (incluindo a data original da nota)
            const itensSelecionados = [];
            checkboxesMarcados.forEach(cb => {
                itensSelecionados.push({
                    nomeDivergente: cb.getAttribute('data-nome'),
                    dataNota: cb.getAttribute('data-data'), // Data real da nota (ex: 2026-07-07)
                    itemId: cb.getAttribute('data-item-id') // Identifica a linha de forma estável entre importações
                });
            });

            const payload = {
                produtoOficialId: produtoOficialId,
                quantidadeReal: quantidadeReal,
                itens: itensSelecionados,
                modo: modo
            };

            try {
                // Envia para o backend — 'modo' decide se soma no estoque_atual
                // também, ou se fica só registrado no consumo mensal
                const response = await fetch('/api/injetar_historico_media', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                const resultado = await response.json();

                if (resultado.sucesso) {
                    // Remove da tela só as linhas que acabaram de ser vinculadas — o
                    // resto da semana continua ali pra você seguir de onde parou,
                    // mesmo numa planilha grande feita aos poucos.
                    checkboxesMarcados.forEach(cb => {
                        const linha = cb.closest('tr');
                        if (linha) linha.remove();
                    });

                    const tbody = document.getElementById(`tbodySemana_${index}`);
                    const restantes = tbody ? tbody.querySelectorAll('tr').length : 0;
                    const contador = document.getElementById(`contadorSemana_${index}`);
                    if (contador) contador.innerText = `${restantes} itens restantes`;

                    if (restantes === 0) {
                        const cardBloco = tbody ? tbody.closest('.border') : null;
                        if (cardBloco) {
                            cardBloco.innerHTML = `<div class="p-4 text-center text-emerald-700 font-bold text-xs">✔ Semana totalmente somada ao estoque!</div>`;
                        }
                    } else {
                        // Limpa a seleção de produto/quantidade pra continuar vinculando o restante desta semana
                        if (inputBusca) inputBusca.value = '';
                        if (hiddenProd) hiddenProd.value = '';
                        if (inputQtd) inputQtd.value = '';
                    }
                    if (typeof carregarAlertaEstoque === 'function') carregarAlertaEstoque();
                } else {
                    mostrarAlerta("❌ Erro ao processar o vínculo: " + (resultado.mensagem || 'Erro desconhecido.'), 'erro');
                }

            } catch (e) {
                console.error(e);
                mostrarAlerta("Erro de conexão ao enviar os dados para o servidor.", 'erro');
            }
        }
