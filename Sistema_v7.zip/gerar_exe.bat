@echo off
REM Coloque este .bat na RAIZ do projeto (ao lado de desktop.py) e so' da dois cliques.
cd /d "%~dp0"

echo ============================================
echo  Instalando dependencias (requirements.txt)...
echo ============================================
echo.

python -m pip install -r requirements.txt

if errorlevel 1 (
    echo.
    echo ============================================
    echo  ERRO ao instalar as dependencias. Veja a mensagem acima.
    echo ============================================
    pause
    exit /b 1
)

REM O PyInstaller nao esta no requirements.txt (ele e' uma ferramenta de
REM build, nao uma dependencia do app em si) - garante que esta instalado.
python -m pip install pyinstaller

if errorlevel 1 (
    echo.
    echo ============================================
    echo  ERRO ao instalar o PyInstaller. Veja a mensagem acima.
    echo ============================================
    pause
    exit /b 1
)

if not exist "logo\logo-sytem.ico" (
    echo.
    echo ============================================
    echo  ERRO: nao encontrei "logo\logo-sytem.ico" na raiz do projeto.
    echo  Confira se a pasta "logo" esta do lado deste .bat e do
    echo  desktop.py, com o arquivo logo-sytem.ico dentro dela.
    echo ============================================
    pause
    exit /b 1
)

echo.
echo ============================================
echo  Gerando o .exe do Sistema de Saida Rapida...
echo ============================================
echo.

python -m PyInstaller ^
    --noconfirm ^
    --onefile ^
    --windowed ^
    --name "SistemaSaidaRapida" ^
    --icon "logo\logo-sytem.ico" ^
    --add-data "templates;templates" ^
    --add-data "static;static" ^
    desktop.py

REM Se o icone mudar de nome/lugar, ajuste o caminho na linha --icon acima.

if errorlevel 1 (
    echo.
    echo ============================================
    echo  ERRO ao gerar o .exe. Veja a mensagem acima.
    echo ============================================
    pause
    exit /b 1
)

echo.
echo ============================================
echo  Pronto! O .exe esta em: dist\SistemaSaidaRapida.exe
echo  Lembrete: a pasta "data" (com o banco.sqlite) e' criada
echo  automaticamente do LADO do .exe na primeira vez que ele roda.
echo ============================================
pause
