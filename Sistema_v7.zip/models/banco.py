import json
import os
import sqlite3
import hashlib
from contextlib import contextmanager

from config import caminho_dados

BANCO_DB = caminho_dados('banco.db')

# Caminhos dos JSONs antigos — usados apenas para a migração automática
# na primeira execução após a atualização (depois disso não são mais tocados).
_JSON_BANCO_ANTIGO = caminho_dados('banco.json')
_JSON_CONSUMO_ANTIGO = caminho_dados('consumo_geral.json')
_JSON_ITENS_PROC_ANTIGO = caminho_dados('itens_importacao_processados.json')


# ============================================================
# Conexão e criação das tabelas
# ============================================================

@contextmanager
def _conectar():
    conn = sqlite3.connect(BANCO_DB)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def _criar_tabelas(conn):
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS produtos (
            codigo_barras TEXT PRIMARY KEY,
            nome TEXT NOT NULL,
            tipo_medida TEXT DEFAULT 'un',
            tamanho_embalagem REAL,
            estoque_atual REAL DEFAULT 0,
            controla_estoque INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS profissionais (
            id INTEGER PRIMARY KEY,
            nome TEXT NOT NULL,
            funcao TEXT
        );

        CREATE TABLE IF NOT EXISTS saidas (
            id INTEGER PRIMARY KEY,
            status TEXT NOT NULL CHECK (status IN ('pendente', 'confirmada')),
            data_hora TEXT,
            profissional TEXT,
            setor TEXT,
            cliente TEXT
        );

        CREATE TABLE IF NOT EXISTS saida_itens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            saida_id INTEGER NOT NULL REFERENCES saidas(id) ON DELETE CASCADE,
            codigo_barras TEXT,
            nome TEXT,
            tipo_medida TEXT,
            quantidade REAL,
            servico TEXT
        );

        CREATE TABLE IF NOT EXISTS servicos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL UNIQUE
        );

        CREATE TABLE IF NOT EXISTS consumo (
            id INTEGER PRIMARY KEY,
            data TEXT,
            data_hora TEXT,
            profissional TEXT,
            setor TEXT,
            cliente TEXT,
            dias_periodo TEXT,
            id_saida INTEGER
        );

        CREATE TABLE IF NOT EXISTS consumo_itens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            consumo_id INTEGER NOT NULL REFERENCES consumo(id) ON DELETE CASCADE,
            codigo_barras TEXT,
            nome TEXT,
            tipo_medida TEXT,
            quantidade REAL,
            servico TEXT
        );

        CREATE TABLE IF NOT EXISTS itens_importados (
            chave TEXT PRIMARY KEY
        );

        CREATE INDEX IF NOT EXISTS idx_saida_itens_saida_id ON saida_itens(saida_id);
        CREATE INDEX IF NOT EXISTS idx_consumo_itens_consumo_id ON consumo_itens(consumo_id);
    ''')


def _migrar_colunas_novas(conn):
    """
    Migração incremental para bancos já existentes (criados antes da coluna
    'estoque_atual' existir). CREATE TABLE IF NOT EXISTS não adiciona colunas
    em tabelas que já existem, então precisamos checar e adicionar manualmente,
    sem apagar nenhum dado já cadastrado.
    """
    colunas = [c['name'] for c in conn.execute('PRAGMA table_info(produtos)').fetchall()]
    if 'estoque_atual' not in colunas:
        conn.execute('ALTER TABLE produtos ADD COLUMN estoque_atual REAL DEFAULT 0')
    if 'controla_estoque' not in colunas:
        # Produtos existentes continuam controlando estoque normalmente (valor
        # padrão 1) — só passam a não controlar quando o usuário desmarcar
        # explicitamente no cadastro/edição (ex.: itens de outra área, usados
        # só para acompanhar o consumo mensal, sem entrar no alerta de estoque baixo).
        conn.execute('ALTER TABLE produtos ADD COLUMN controla_estoque INTEGER DEFAULT 1')

    colunas_consumo = [c['name'] for c in conn.execute('PRAGMA table_info(consumo)').fetchall()]
    if 'id_saida' not in colunas_consumo:
        # Permite ligar um registro de consumo ao lançamento (saída) que o
        # gerou, para que a exclusão de um lançamento pendente também remova
        # o registro de consumo correspondente (ver excluir_bloco_profissional).
        conn.execute('ALTER TABLE consumo ADD COLUMN id_saida INTEGER')

    colunas_profissionais = [c['name'] for c in conn.execute('PRAGMA table_info(profissionais)').fetchall()]
    if 'luva_padrao' not in colunas_profissionais:
        # Tamanho de luva padrão da profissional (PP/P/M/G), opcional. Quando
        # definido, o lançamento rápido de luva mostra só o tamanho dela em
        # vez de todas as opções (ver /api/buscar_profissional).
        conn.execute('ALTER TABLE profissionais ADD COLUMN luva_padrao TEXT')

    colunas_saida_itens = [c['name'] for c in conn.execute('PRAGMA table_info(saida_itens)').fetchall()]
    if 'servico' not in colunas_saida_itens:
        # Separa os itens de uma mesma comanda (Cabeleireiro) por serviço
        # (Corte, Escova, Coloração, etc.) — ver tabela 'servicos' e
        # /api/buscar_servico. Fica NULL para lançamentos antigos e para
        # setores que não usam o conceito de serviço (ex.: manicure).
        conn.execute('ALTER TABLE saida_itens ADD COLUMN servico TEXT')

    colunas_consumo_itens = [c['name'] for c in conn.execute('PRAGMA table_info(consumo_itens)').fetchall()]
    if 'servico' not in colunas_consumo_itens:
        conn.execute('ALTER TABLE consumo_itens ADD COLUMN servico TEXT')


def _banco_esta_vazio(conn):
    total = conn.execute(
        'SELECT (SELECT COUNT(*) FROM produtos) + (SELECT COUNT(*) FROM profissionais) '
        '+ (SELECT COUNT(*) FROM saidas) + (SELECT COUNT(*) FROM consumo) AS total'
    ).fetchone()['total']
    return total == 0


def _migrar_json_antigo(conn):
    """
    Migração automática, executada uma única vez: se o banco.db acabou de ser
    criado (está vazio) e ainda existem os arquivos .json do sistema antigo,
    importa tudo para dentro do SQLite. Depois disso o banco.db passa a ser a
    única fonte de dados — os .json antigos não são mais lidos nem apagados
    (ficam guardados na pasta data/ como backup).
    """
    if not _banco_esta_vazio(conn):
        return

    if os.path.exists(_JSON_BANCO_ANTIGO):
        with open(_JSON_BANCO_ANTIGO, 'r', encoding='utf-8') as f:
            dados = json.load(f)

        for p in dados.get('produtos', []):
            conn.execute(
                'INSERT OR IGNORE INTO produtos (codigo_barras, nome, tipo_medida, tamanho_embalagem) '
                'VALUES (?, ?, ?, ?)',
                (p.get('codigo_barras'), p.get('nome'), p.get('tipo_medida', 'un'), p.get('tamanho_embalagem'))
            )

        for p in dados.get('profissionais', []):
            conn.execute(
                'INSERT OR IGNORE INTO profissionais (id, nome, funcao) VALUES (?, ?, ?)',
                (p.get('id'), p.get('nome'), p.get('funcao'))
            )

        for status, chave_lista in (('pendente', 'saidas_pendentes'), ('confirmada', 'saidas_confirmadas')):
            for s in dados.get(chave_lista, []):
                conn.execute(
                    'INSERT OR IGNORE INTO saidas (id, status, data_hora, profissional, setor, cliente) '
                    'VALUES (?, ?, ?, ?, ?, ?)',
                    (s.get('id'), status, s.get('data_hora'), s.get('profissional'), s.get('setor'), s.get('cliente'))
                )
                for item in s.get('itens', []):
                    conn.execute(
                        'INSERT INTO saida_itens (saida_id, codigo_barras, nome, tipo_medida, quantidade) '
                        'VALUES (?, ?, ?, ?, ?)',
                        (s.get('id'), item.get('codigo_barras'), item.get('nome'),
                         item.get('tipo_medida', 'un'), item.get('quantidade'))
                    )

    if os.path.exists(_JSON_CONSUMO_ANTIGO):
        with open(_JSON_CONSUMO_ANTIGO, 'r', encoding='utf-8') as f:
            historico = json.load(f)

        for h in historico:
            # Muitos registros antigos (os gerados por confirmar_saida) nunca tiveram
            # 'id' no JSON — só os criados pela importação de planilha tinham, e às
            # vezes colidiam com os que ficariam sem id. Como o id do histórico não
            # é usado em nenhum lugar do front-end, deixamos o SQLite atribuir um id
            # novo e sequencial pra cada registro, sempre.
            dias_periodo = h.get('dias_periodo')
            cursor = conn.execute(
                'INSERT INTO consumo (data, data_hora, profissional, setor, cliente, dias_periodo) '
                'VALUES (?, ?, ?, ?, ?, ?)',
                (h.get('data'), h.get('data_hora'), h.get('profissional'), h.get('setor'),
                 h.get('cliente'), json.dumps(dias_periodo, ensure_ascii=False) if dias_periodo else None)
            )
            consumo_id = cursor.lastrowid
            for item in h.get('itens', []):
                conn.execute(
                    'INSERT INTO consumo_itens (consumo_id, codigo_barras, nome, tipo_medida, quantidade) '
                    'VALUES (?, ?, ?, ?, ?)',
                    (consumo_id, item.get('codigo_barras'), item.get('nome'),
                     item.get('tipo_medida', 'un'), item.get('quantidade'))
                )

    if os.path.exists(_JSON_ITENS_PROC_ANTIGO):
        with open(_JSON_ITENS_PROC_ANTIGO, 'r', encoding='utf-8') as f:
            chaves = json.load(f)
        for chave in chaves:
            conn.execute('INSERT OR IGNORE INTO itens_importados (chave) VALUES (?)', (chave,))


def _garantir_banco_pronto():
    with _conectar() as conn:
        _criar_tabelas(conn)
        _migrar_colunas_novas(conn)
        _migrar_json_antigo(conn)


_garantir_banco_pronto()


# ============================================================
# Produtos / profissionais / saídas (banco principal)
# ============================================================

def _linha_saida_para_dict(conn, linha):
    itens = conn.execute(
        'SELECT codigo_barras, nome, tipo_medida, quantidade, servico FROM saida_itens WHERE saida_id = ?',
        (linha['id'],)
    ).fetchall()
    return {
        "id": linha['id'],
        "data_hora": linha['data_hora'],
        "profissional": linha['profissional'],
        "setor": linha['setor'],
        "cliente": linha['cliente'],
        "itens": [dict(i) for i in itens]
    }


def ler_banco():
    with _conectar() as conn:
        produtos = [dict(p) for p in conn.execute(
            'SELECT codigo_barras, nome, tipo_medida, tamanho_embalagem, estoque_atual, '
            'COALESCE(controla_estoque, 1) AS controla_estoque FROM produtos'
        ).fetchall()]
        for p in produtos:
            p['controla_estoque'] = bool(p['controla_estoque'])

        profissionais = [dict(p) for p in conn.execute(
            'SELECT id, nome, funcao, luva_padrao FROM profissionais'
        ).fetchall()]

        pendentes = [
            _linha_saida_para_dict(conn, s)
            for s in conn.execute("SELECT * FROM saidas WHERE status = 'pendente' ORDER BY id").fetchall()
        ]
        confirmadas = [
            _linha_saida_para_dict(conn, s)
            for s in conn.execute("SELECT * FROM saidas WHERE status = 'confirmada' ORDER BY id").fetchall()
        ]

        return {
            "produtos": produtos,
            "profissionais": profissionais,
            "saidas_pendentes": pendentes,
            "saidas_confirmadas": confirmadas,
        }


_CHAVES_OBRIGATORIAS_BANCO = ('produtos', 'profissionais', 'saidas_pendentes', 'saidas_confirmadas')


def salvar_banco(dados):
    """
    Regrava o estado inteiro (produtos, profissionais e saídas) no SQLite,
    substituindo o conteúdo das tabelas — mesmo comportamento de "sobrescrever
    tudo" que existia com o banco.json, só que agora em tabelas relacionais.

    Por isso exige que 'dados' tenha as 4 chaves principais (mesmo que
    alguma venha com lista vazia): esta função sempre espera o dict COMPLETO
    devolvido por ler_banco() e modificado em memória — nunca um dict parcial
    montado à mão. Sem essa checagem, passar por engano um dict sem
    'produtos' (por ex.) apagaria silenciosamente todo o cadastro de
    produtos, já que a rotina abaixo faz DELETE + reinsere do zero.
    """
    faltando = [c for c in _CHAVES_OBRIGATORIAS_BANCO if c not in dados]
    if faltando:
        raise ValueError(
            "salvar_banco recebeu um dicionário incompleto (faltando: "
            f"{', '.join(faltando)}). Ele espera sempre o dict completo de "
            "ler_banco() modificado em memória, nunca um dict parcial — "
            "abortado para não apagar dados existentes."
        )

    with _conectar() as conn:
        conn.execute('DELETE FROM produtos')
        for p in dados.get('produtos', []):
            controla_estoque = p.get('controla_estoque', True)
            conn.execute(
                'INSERT INTO produtos (codigo_barras, nome, tipo_medida, tamanho_embalagem, estoque_atual, controla_estoque) '
                'VALUES (?, ?, ?, ?, ?, ?)',
                (p.get('codigo_barras'), p.get('nome'), p.get('tipo_medida', 'un'),
                 p.get('tamanho_embalagem'), p.get('estoque_atual', 0) or 0,
                 1 if controla_estoque or controla_estoque is None else 0)
            )

        conn.execute('DELETE FROM profissionais')
        for p in dados.get('profissionais', []):
            conn.execute(
                'INSERT INTO profissionais (id, nome, funcao, luva_padrao) VALUES (?, ?, ?, ?)',
                (p.get('id'), p.get('nome'), p.get('funcao'), p.get('luva_padrao'))
            )

        # saida_itens é apagado em cascata (ON DELETE CASCADE) junto com saidas
        conn.execute('DELETE FROM saidas')
        for status, chave_lista in (('pendente', 'saidas_pendentes'), ('confirmada', 'saidas_confirmadas')):
            for s in dados.get(chave_lista, []):
                conn.execute(
                    'INSERT INTO saidas (id, status, data_hora, profissional, setor, cliente) VALUES (?, ?, ?, ?, ?, ?)',
                    (s.get('id'), status, s.get('data_hora'), s.get('profissional'), s.get('setor'), s.get('cliente'))
                )
                for item in s.get('itens', []):
                    conn.execute(
                        'INSERT INTO saida_itens (saida_id, codigo_barras, nome, tipo_medida, quantidade, servico) '
                        'VALUES (?, ?, ?, ?, ?, ?)',
                        (s.get('id'), item.get('codigo_barras'), item.get('nome'),
                         item.get('tipo_medida', 'un'), item.get('quantidade'),
                         (item.get('servico') or '').strip() or None)
                    )


# ============================================================
# Estoque atual dos produtos
# ============================================================

def ajustar_estoque_produto(codigo_barras, delta):
    """
    Soma (ou subtrai, se delta for negativo) 'delta' ao estoque_atual do
    produto. Usado tanto na baixa automática ao lançar uma saída quanto na
    devolução do estoque quando um lançamento pendente é excluído, e também
    na importação de planilha de reposição (delta positivo).
    """
    if not codigo_barras or not delta:
        return
    with _conectar() as conn:
        conn.execute(
            'UPDATE produtos SET estoque_atual = COALESCE(estoque_atual, 0) + ? WHERE codigo_barras = ?',
            (delta, codigo_barras)
        )


def definir_estoque_produto(codigo_barras, valor):
    """Define (sobrescreve) o estoque_atual de um produto para um valor absoluto."""
    with _conectar() as conn:
        conn.execute(
            'UPDATE produtos SET estoque_atual = ? WHERE codigo_barras = ?',
            (valor, codigo_barras)
        )


def definir_controla_estoque_produto(codigo_barras, controla_estoque):
    """
    Liga/desliga o controle de estoque de um produto (True/False). Produtos
    com controla_estoque=False nunca têm o estoque_atual alterado por uma
    importação de planilha (mesmo que o modo escolhido seja 'estoque') e são
    ignorados pelo alerta de estoque baixo — mas continuam entrando
    normalmente no histórico de consumo/média semanal.
    """
    with _conectar() as conn:
        conn.execute(
            'UPDATE produtos SET controla_estoque = ? WHERE codigo_barras = ?',
            (1 if controla_estoque else 0, codigo_barras)
        )


# ============================================================
# Histórico de consumo geral
# ============================================================

def ler_historico_consumo():
    with _conectar() as conn:
        registros = []
        for h in conn.execute('SELECT * FROM consumo ORDER BY id').fetchall():
            itens = conn.execute(
                'SELECT codigo_barras, nome, tipo_medida, quantidade, servico FROM consumo_itens WHERE consumo_id = ?',
                (h['id'],)
            ).fetchall()
            registro = {
                "id": h['id'],
                "data": h['data'],
                "data_hora": h['data_hora'],
                "profissional": h['profissional'],
                "setor": h['setor'],
                "cliente": h['cliente'],
                "itens": [dict(i) for i in itens],
            }
            if h['dias_periodo']:
                registro['dias_periodo'] = json.loads(h['dias_periodo'])
            if h['id_saida'] is not None:
                registro['id_saida'] = h['id_saida']
            registros.append(registro)
        return registros


def salvar_historico_consumo(historico):
    with _conectar() as conn:
        conn.execute('DELETE FROM consumo')
        for h in historico:
            # Mesmo cuidado de _migrar_json_antigo: nem todo registro tem 'id',
            # e o id do histórico não é usado no front-end — deixamos o SQLite
            # atribuir um id novo e sequencial sempre, evitando colisões.
            dias_periodo = h.get('dias_periodo')
            cursor = conn.execute(
                'INSERT INTO consumo (data, data_hora, profissional, setor, cliente, dias_periodo, id_saida) '
                'VALUES (?, ?, ?, ?, ?, ?, ?)',
                (h.get('data'), h.get('data_hora'), h.get('profissional'), h.get('setor'),
                 h.get('cliente'), json.dumps(dias_periodo, ensure_ascii=False) if dias_periodo else None,
                 h.get('id_saida'))
            )
            consumo_id = cursor.lastrowid
            for item in h.get('itens', []):
                conn.execute(
                    'INSERT INTO consumo_itens (consumo_id, codigo_barras, nome, tipo_medida, quantidade, servico) '
                    'VALUES (?, ?, ?, ?, ?, ?)',
                    (consumo_id, item.get('codigo_barras'), item.get('nome'),
                     item.get('tipo_medida', 'un'), item.get('quantidade'),
                     (item.get('servico') or '').strip() or None)
                )


# ============================================================
# Serviços (Cabeleireiro): Corte, Escova, Coloração, Hidratação, etc.
# Cadastro simples e independente do "dump" de ler_banco/salvar_banco —
# não faz parte do dict que salvar_banco sobrescreve por inteiro, então
# cadastrar/excluir um serviço nunca corre o risco de apagar produtos,
# profissionais ou saídas por engano.
# ============================================================

def listar_servicos(termo=None):
    with _conectar() as conn:
        if termo:
            linhas = conn.execute(
                'SELECT id, nome FROM servicos WHERE nome LIKE ? ORDER BY nome',
                (f'%{termo}%',)
            ).fetchall()
        else:
            linhas = conn.execute('SELECT id, nome FROM servicos ORDER BY nome').fetchall()
        return [dict(l) for l in linhas]


def criar_servico(nome):
    nome = (nome or '').strip()
    if not nome:
        return None, "Nome do serviço é obrigatório."
    with _conectar() as conn:
        existente = conn.execute(
            'SELECT id, nome FROM servicos WHERE nome = ? COLLATE NOCASE', (nome,)
        ).fetchone()
        if existente:
            return dict(existente), None
        cursor = conn.execute('INSERT INTO servicos (nome) VALUES (?)', (nome,))
        return {"id": cursor.lastrowid, "nome": nome}, None


def excluir_servico(nome):
    nome = (nome or '').strip()
    if not nome:
        return False
    with _conectar() as conn:
        cursor = conn.execute('DELETE FROM servicos WHERE nome = ? COLLATE NOCASE', (nome,))
        return cursor.rowcount > 0


# ============================================================
# Controle de itens do xlsx já vinculados (persiste entre sessões)
# ============================================================

def ler_itens_processados():
    with _conectar() as conn:
        linhas = conn.execute('SELECT chave FROM itens_importados').fetchall()
        return {linha['chave'] for linha in linhas}


def marcar_itens_processados(chaves):
    chaves = [c for c in chaves if c]
    if not chaves:
        return
    with _conectar() as conn:
        conn.executemany(
            'INSERT OR IGNORE INTO itens_importados (chave) VALUES (?)',
            [(c,) for c in chaves]
        )


def gerar_chave_item_importado(data_str, nome, quantidade, unidade):
    """Gera um identificador estável para uma linha da planilha importada,
    baseado no conteúdo dela — não depende de posição/índice, então continua
    valendo mesmo se a planilha for reimportada ou reordenada."""
    base = f"{data_str}|{str(nome).strip().lower()}|{quantidade}|{str(unidade).strip().lower()}"
    return hashlib.sha256(base.encode('utf-8')).hexdigest()[:16]
